library(tidyverse)
library(dplyr)
library(readxl)
library(data.table)
library(Biobase)
library(genefilter)
library(Rtsne)
library(ggplot2)
library(gridExtra)
library(pheatmap)
library(gplots)
library(limma)
library(RColorBrewer)
library(reshape)
library(GSVA)
library(quantiseqr)
library(ComplexHeatmap)
library(lessR)

#1. tpm tcga

meta3 <- fread('/projects/grc/onc/data/tcga/Omicsoft/TCGA_B38_GC33_MetadataClinical_20240507.txt') 

meta3 <- meta3 %>% select(ID,`HPV[Status]`,`HPV[Type]`,`DNASeqSomaticMutationStatus[TP53]`,
                          `DNASeqSomaticMutationStatus[PIK3CA]`,
                          `DNASeqSomaticMutationStatus[HRAS]`,
                          `DNASeqSomaticMutationStatus[CDKN2A]`,
                          `DNASeqSomaticMutationStatus[TERT]`,
                          `DNASeqSomaticMutationStatus[EGFR]`,
                          `DNASeqSomaticMutationStatus[PTEN]`,
                          `DNASeqSomaticMutationStatus[NOTCH1]`) 

meta2 <- fread('/projects/grc/onc/data/tcga/Omicsoft/TCGA_B38_GC33_Metadata_20240507.txt')

meta2 <- meta2 %>% 
  dplyr::select(SampleID,'Disease[TCGA]','DiseaseLocation[PrimarySite]',
         DiseaseCategory,DiseaseState,'OverallSurvival[OS][days]','OverallSurvival[OS][event]',
         ProjectName,SampleIntegrationID,Tissue,'TreatmentHistory[NeoadjuvantTreatment]',
         TumorOrNormal,SampleType,ProteinChange,ClinVar_ClinicalSignificance)


#1) combine mutation and HPV status

masterdf <- meta3 %>% left_join(meta2 %>% mutate(ID = SampleID)) %>% 
  filter(TumorOrNormal == 'Tumor') %>% 
  #filter(`HPV[Status]` %in% c('Positive','Negative')) %>% 
  filter(DiseaseState %in% c(#'lung adenocarcinoma (LUAD)',
                             'lung squamous cell carcinoma (LUSC)')) %>%
  mutate(sample_id = ID) %>% 
  separate(sample_id, into = 'sample_id',sep = '-01A|-06A',extra = 'drop') %>%
  mutate(Type = `HPV[Type]`) %>% 
  separate(Type, into = 'Type',sep = ';', extra = 'drop') %>% 
  mutate(Type = ifelse(Type %in% c('HPV16','HPV18','HPV33','HPV45','HPV35','HPV58','HPV52','HPV39','HPV31'),
                       Type, 'Other'),
         TP53 = `DNASeqSomaticMutationStatus[TP53]`,
         HPV = `HPV[Status]`)

write.csv(masterdf, '~/HPV_E6/masterdf_LUSC_cases.csv',row.names = F)
### omicsoft lung adeno/squamous doesn't have HPV positivity data

##option2  maftools to incorporate TMB, https://bioconductor.org/packages/release/bioc/vignettes/maftools/inst/doc/maftools.html
library(maftools)

##Analysis of TCGA cohorts with maftools is as easy as it can get. This is made possible by processing TCGA MAF files from Broad firehose and TCGA MC3 project. Every cohort is stored as an MAF object containing somatic mutations (no CNVs) along with the relevant clinical information. There are two functions
##1) available cohorts
tcga_avail = tcgaAvailable()
tcga_avail

##2)Loading a TCGA cohort
# By default MAF from MC3 project will be loaded

#LUAD = tcgaLoad(study = "LUAD")
LUSC = tcgaLoad(study = "LUSC")

## maftools hpv composition 20241028
LUSC_clinical <- LUSC@clinical.data %>% as.data.frame
#LUAD_clinical <- LUAD@clinical.data %>% as.data.frame

##oncoplot
pathways = data.frame(
  Genes = c(
    "TP53",
    "CDKN2A",
    "PTEN",
    "PIK3CA"),
  Pathway = rep(c(
    "Hot spot mutation"
  ), c(4)),
  stringsAsFactors = FALSE
)

head(pathways)
oncoplot(
  maf = LUSC,
  top = 10,
  clinicalFeatures = 'human_papillomavirus_type',
  sortByAnnotation = TRUE
)
oncoplot(maf = LUSC, top = 10)

## P53 mutation and HPV data not available

#####################variant.classification.summary#######################################################################
### HPV positivity and P53 status
#######################################################################
##########################################################################
# TCGA TPM read

tcga_exp <- read_rds('/projects/grc/onc/data/tcga/biolink/alltcga_expressionset_tpm_2020-07-17.RDS')

masterdf <- fread('~/HPV_E6/masterdf_LUSC_cases.csv')

masterdf <- masterdf[order(masterdf$DiseaseState,masterdf$`HPV[Status]`,masterdf$`HPV[Type]`),]

sample_order <- match(masterdf$sample_id,tcga_exp$sample_id) %>% na.omit()

test <- tcga_exp[,sample_order]

exp_meta <- pData(test) %>% left_join(masterdf) %>% column_to_rownames('sample_name')

pData(test) <- exp_meta  

## PDL1 expression

##1) log2(+1) converting expression data for TPMs
tumorTPM <- test

exprs(tumorTPM) <- log2(exprs(tumorTPM) + 1)

#2 QC plots
#Plotting some QC plots prior to differential expression analysis. 

hist(rowMeans(exprs(tumorTPM)))

##Histogram of row vars
hist(rowVars(exprs(tumorTPM)))

#Potentially an outlier. Checking which genes are over 15. 

intGenes <- which(rowVars(exprs(tumorTPM)) > 1)
intGS <- fData(tumorTPM)$SYMBOL[which(featureNames(tumorTPM) %in% names(intGenes))]

print(intGS)

####3. Subsetting to variable and expressed genes
rnaTUSE <- exprs(tumorTPM)[ which(rowMeans(exprs(tumorTPM)) > .15 & 
                                    rowVars(exprs(tumorTPM)) > 0.15), ]

##Getting tsne together
set.seed(777)
tstTSNE <- Rtsne(t(rnaTUSE),
                 check_duplicates=FALSE,
                 pca=TRUE,
                 perplexity=2,
                 theta=0.5,
                 dims=2)

##Making a dataframe for plotting
tstTSNEDF <- as.data.frame(tstTSNE$Y)
tstTSNEDF <- cbind(tstTSNEDF,pData(tumorTPM))

##4. Plotting
ggplot(data = tstTSNEDF, aes(x = V1, y = V2,colour = TP53)) +
  #geom_label(size = 4) + 
  #ggrepel::geom_label_repel(size = 3#, aes(y = V2 - 5, label = Diagnosis)
  #) + 
  geom_point(size = 2)+
  scale_x_continuous("tSNE X") +
  scale_y_continuous("tSNE Y") +
  scale_color_manual(values = c("MUT" = "red","WT" = "navy")) + 
  theme_classic(base_size = 10) +
  theme(plot.title = element_text(hjust = 0.5)) +
  facet_wrap(~project,nrow = 2)

##5. ## Heatmap of key genes

pData(tumorTPM) <- pData(tumorTPM) %>%  mutate(
         TP53 = tumorTPM$'DNASeqSomaticMutationStatus[TP53]',
         HPV = tumorTPM$'HPV[Status]')

##Plotting some relevant genes
intGenes <- c(#"E6",'E7',
              'CDKN2A','CDKN1A','E2F1','RB1','CDK2','CDK4',
              'CDK6','CCND1')

##Subsetting to only these genes

rnaLINT <- tumorTPM[match(intGenes,fData(tumorTPM)$SYMBOL), ]

##Peeling off, subsetting annotation data
annoSS <- pData(rnaLINT) %>% dplyr::select(
  "Tissue",
  'TP53')

sample_order <- pData(rnaLINT)[order(rnaLINT$Tissue,rnaLINT$`DNASeqSomaticMutationStatus[TP53]`),]

##Heatmap
draw(ComplexHeatmap::pheatmap(exprs(rnaLINT),
                         labels_row = fData(rnaLINT)$SYMBOL,
                         #labels_col = pData(rnaLINT)$sample_label,
                         show_colnames = F, 
                         show_rownames = TRUE,
                         annotation_colors = list(
                            "TP53" = c("WT" = "grey30",
                                     "MUT" = "#4DAC26"),
                           "Tissue" = c("lung" = '#2986cc')
                         ),
                         
                         color = circlize::colorRamp2(c(-2, 0, 2), c("blue", "white", "red")),
                         scale = "row",
                         #clustering_distance_rows = "euclidean",
                         #clustering_method = "ward.D2",
                         cluster_rows = F,
                         cluster_cols = F,
                         annotation_col = annoSS,
                         column_order = rownames(sample_order)),
     merge_legend = TRUE)

### gene expression by subgroups

test <- exprs(rnaLINT) %>% t %>% as.data.frame
colnames(test) <- paste(fData(rnaLINT)$SYMBOL,'exp',sep='_')

test <- pData(rnaLINT) %>% select('TP53') %>% cbind(test) %>% 
  pivot_longer(cols = 2:9) %>% 
  mutate(TP53 = ifelse(TP53 == '','NA',TP53))

ggplot(test, aes(factor(TP53,levels = c('NA','MUT','WT')),value,color=name)) +
  geom_jitter(size=1,alpha = .9,shape=1) +
  geom_boxplot(alpha = .1) +
  facet_wrap(~Tissue,nrow=1,scales = 'free_x') +
  labs(x='', y = 'expression log2(TPM+1)') +
  theme_classic() +
  theme(axis.text.x = element_text(angle=90),
        legend.position = 'none') +
  facet_wrap(~name, ncol = 8) +
  ggpubr::stat_compare_means(comparisons = list(c('MUT','WT')), method = 'wilcox.test',
                     label = 'p.signif')

##########################################################################
### HPV positivity and P53 status in Caris nsclc
#######################################################################
# CARSI lung TPM read /projects/grc/onc/data/caris/Q12024/seq/exp/concatenated_net/nsclc/nsclc_pt_tpm.rds

meta1 <- fread('/projects/grc/onc/data/caris/subtype/caris_pt360_q424_nsclc_subtype_annotation.csv') %>% 
  filter(studyCode == 'LUSC') %>% dplyr::rename('SAMPLE_ID'='case_id')

meta2 <- fread('/projects/grc/onc/data/caris/cbioportal/Q42024/cbioportal/pt360/nsclc_pt360_abbvie/data_clinical_sample.txt',skip = 4) %>% 
  filter(SAMPLE_ID %in% meta1$SAMPLE_ID) %>% 
  left_join(.,meta1 %>% select(SAMPLE_ID, studyCode))

meta3 <- fread('/projects/grc/onc/data/caris/cbioportal/Q42024/cbioportal/pt360/nsclc_pt360_abbvie/data_mutation.txt') %>% 
  filter(Hugo_Symbol == 'TP53') %>% group_by(Tumor_Sample_Barcode, Hugo_Symbol) %>% 
  reframe(Variant_Classification = sort(unique(Variant_Classification))) %>%
  select(1,3) %>% dplyr::rename('SAMPLE_ID' = 'Tumor_Sample_Barcode', 'TP53_Mutation' = 'Variant_Classification') %>% 
  right_join(., meta2) %>% filter(!duplicated(SAMPLE_ID)) %>% 
  mutate(name = SAMPLE_ID) %>% column_to_rownames('name') %>% 
  mutate(TP53_Mutation = ifelse(is.na(TP53_Mutation) | TP53_Mutation == 'Silent', 'WT', 'MUT'))

caris_exp <- fread('/projects/grc/onc/data/caris/cbioportal/Q42024/cbioportal/pt360/nsclc_pt360_abbvie/data_harmonized_expression.txt') %>% 
  select(1,meta3$SAMPLE_ID)

tumorTPM <- ExpressionSet(assayData = caris_exp %>% 
                            column_to_rownames('Hugo_Symbol') %>% 
                            dplyr::select(rownames(meta3)) %>% as.matrix,
                          phenoData = AnnotatedDataFrame(meta3),
                          featureData = AnnotatedDataFrame(
                            data.frame(symbol = caris_exp$`Hugo_Symbol`, row.names = caris_exp$`Hugo_Symbol`))
)

##log2(+1) converting expression data for TPMs
exprs(tumorTPM) <- log2(exprs(tumorTPM) + 1)
hist(rowMeans(exprs(tumorTPM)))
hist(rowVars(exprs(tumorTPM)))

##Subsetting to variable and expressed genes
rnaTUSE <- exprs(tumorTPM)[ which(rowMeans(exprs(tumorTPM)) > 2.5 & 
                                    rowVars(exprs(tumorTPM)) > 0.15), ]

##Getting tsne together
set.seed(777)
tstTSNE <- Rtsne(t(rnaTUSE),
                 check_duplicates=FALSE,
                 pca=TRUE,
                 perplexity=2,
                 theta=0.5,
                 dims=2)

##Making a dataframe for plotting
tstTSNEDF <- as.data.frame(tstTSNE$Y)
tstTSNEDF$Patient_ID <- factor(tumorTPM$PATIENT_ID)
tstTSNEDF$TP53 <- factor(tumorTPM$TP53_Mutation)
tstTSNEDF$Diagnosis <- factor(tumorTPM$studyCode)
tstTSNEDF$TMB <- factor(tumorTPM$TMB_RESULT)

##Plotting
ggplot(data = tstTSNEDF, aes(x = V1, y = V2, col = TP53, shape = TMB #,label = Diagnosis
                             )) +
  #ggrepel::geom_label_repel(size = 3) + 
  geom_point(size = 3)+
  scale_x_continuous("tSNE X") +
  scale_y_continuous("tSNE Y") +
  theme_classic(base_size = 10) +
  theme(plot.title = element_text(hjust = 0.5)) 

##Plotting some relevant genes
intGenes <- c(#"E6",'E7',
  'CDKN2A','CDKN1A','E2F1','RB1','CDK2','CDK4',
  'CDK6','CCND1')

##Subsetting to only these genes
rnaLINT <- tumorTPM[match(intGenes,fData(tumorTPM)$symbol), ]

##Peeling off, subsetting annotation data
annoSS <- pData(rnaLINT) %>% dplyr::select(
  "studyCode",'TMB_RESULT',
  'TP53_Mutation')

sample_order <- pData(rnaLINT)[order(rnaLINT$TP53_Mutation,rnaLINT$TMB_RESULT),]

##Heatmap
draw(ComplexHeatmap::pheatmap(exprs(rnaLINT),
                              #labels_row = fData(rnaLINT)$SYMBOL,
                              #labels_col = pData(rnaLINT)$sample_label,
                              show_colnames = F, 
                              show_rownames = TRUE,
                              annotation_colors = list(
                                "TP53_Mutation" = c("WT" = "grey30",
                                           "MUT" = "#4DAC26"),
                                "studyCode" = c("LUSC" = '#2986cc'),
                                'TMB_RESULT' =c('Low' = 'purple',
                                                'Indeterminate' = 'black',
                                                'High' = 'orange')
                              ),
                              color = circlize::colorRamp2(c(-2, 0, 2), c("blue", "white", "red")),
                              scale = "row",
                              #clustering_distance_rows = "euclidean",
                              #clustering_method = "ward.D2",
                              cluster_rows = F,
                              cluster_cols = F,
                              annotation_col = annoSS,
                              column_order = rownames(sample_order)),
     merge_legend = TRUE)

### gene expression by subgroups

test <- exprs(rnaLINT) %>% t %>% as.data.frame
colnames(test) <- paste(fData(rnaLINT)$symbol,'exp',sep='_')

test <- pData(rnaLINT) %>% select('TP53_Mutation') %>% cbind(test) %>% 
  pivot_longer(cols = 2:9) 

ggplot(test, aes(factor(TP53_Mutation,levels = c('MUT','WT')),value,color=name)) +
  geom_jitter(size=1,alpha = .9,shape=1) +
  geom_boxplot(alpha = .1) +
  facet_wrap(~Tissue,nrow=1,scales = 'free_x') +
  labs(x='', y = 'expression log2(TPM+1)') +
  theme_classic() +
  theme(axis.text.x = element_text(angle=90),
        legend.position = 'none') +
  facet_wrap(~name, ncol = 8) +
  ggpubr::stat_compare_means(comparisons = list(c('MUT','WT')), method = 'wilcox.test',
                             label = 'p.signif')
