library(tidyverse)
library(dplyr)
library(readxl)
library(data.table)
library(Biobase)
library(genefilter)
library(Rtsne)
library(ggplot2)
library(gridExtra)
library(pheatmap)
library(gplots)
library(limma)
library(RColorBrewer)
library(reshape)
library(GSVA)
library(ComplexHeatmap)

#1. tpm tcga

meta3 <- fread('/projects/grc/onc/data/tcga/Omicsoft/TCGA_B38_GC33_MetadataClinical_20240507.txt') 

meta3 <- meta3 %>% select(ID,`HPV[Status]`,`HPV[Type]`,`DNASeqSomaticMutationStatus[TP53]`,
                          `DNASeqSomaticMutationStatus[PIK3CA]`,
                          `DNASeqSomaticMutationStatus[HRAS]`,
                          `DNASeqSomaticMutationStatus[CDKN2A]`,
                          `DNASeqSomaticMutationStatus[TERT]`,
                          `DNASeqSomaticMutationStatus[EGFR]`,
                          `DNASeqSomaticMutationStatus[PTEN]`,
                          `DNASeqSomaticMutationStatus[NOTCH1]`) 

meta2 <- fread('/projects/grc/onc/data/tcga/Omicsoft/TCGA_B38_GC33_Metadata_20240507.txt')

meta2 <- meta2 %>% 
  dplyr::select(SampleID,'Disease[TCGA]','DiseaseLocation[PrimarySite]',
         DiseaseCategory,DiseaseState,'OverallSurvival[OS][days]','OverallSurvival[OS][event]',
         ProjectName,SampleIntegrationID,Tissue,'TreatmentHistory[NeoadjuvantTreatment]',
         TumorOrNormal,SampleType,ProteinChange,ClinVar_ClinicalSignificance)

### oncoplot

#1) combine mutation and HPV status

masterdf <- meta3 %>% left_join(meta2 %>% mutate(ID = SampleID)) %>% 
  filter(TumorOrNormal == 'Tumor') %>% 
  filter(`HPV[Status]` %in% c('Positive','Negative')) %>% 
  #filter(Tissue %in% c('cervix','head and neck')) %>%
  mutate(sample_id = ID) %>% 
  separate(sample_id, into = 'sample_id',sep = '-01A|-06A',extra = 'drop') %>%
  mutate(Type = `HPV[Type]`) %>% 
  separate(Type, into = 'Type',sep = ';', extra = 'drop') %>% 
  mutate(Type = ifelse(Type %in% c('HPV16','HPV18','HPV33','HPV45','HPV35','HPV58','HPV52','HPV39','HPV31'),
                       Type, 'Other'),
         TP53 = `DNASeqSomaticMutationStatus[TP53]`,
         HPV = `HPV[Status]`) %>%
  filter(Tissue %in% c('cervix','head and neck'))


write.csv(masterdf,'~/HPV_E6/masterdf_HPV_cases.csv',row.names = F)

masterdf  %>% ggplot(aes(x = Tissue,
                        fill = Tissue)) +
  geom_bar(stat = 'count',color = 'black') +
  labs(x='',fill='') + theme_classic()+
  theme(legend.position = 'none') +
  scale_fill_manual(values = c('orange','#2986cc'))

#pc(Tissue, data = masterdf, main = NULL)


masterdf %>% 
  ggplot(aes(x = DiseaseState,
                        fill = `HPV[Status]`)) +
  geom_bar(stat = 'count',position = 'fill',color = 'black') +
  labs(x='',y= 'Percentage') + theme_classic()+
  guides(fill = guide_legend(
    nrow = 4 ))+ 
  theme(axis.text.x = element_blank())+
  facet_wrap(~Tissue,nrow=1,scales = 'free_x') +
  scale_fill_manual(values = c('black','#e50000')) 

masterdf %>% filter(`HPV[Status]` == 'Positive') %>% 
  group_by(Tissue,Type) %>% 
  reframe(counts = n())  %>% 
  group_by(Tissue) %>%
  mutate(frequency = counts / sum(counts)) %>%
  ggplot(aes(x = Type, y = frequency, fill = Type, label = Type)) +
  geom_col(color = 'black', position = 'dodge') +
  geom_text(size = 3, aes(y = frequency + 0.02), angle = 90, hjust = 0) +
  labs(x = '', y = 'Frequency') +
  theme_classic() +
  guides(fill = guide_legend(nrow = 4)) + 
  theme(axis.text.x = element_blank(), legend.position = 'none') +
  facet_wrap(~Tissue, nrow = 1, scales = 'free_x') +
  ylim(c(0,1)) 


##### oncoplot

top50genes <- colnames(masterdf)[c(21,2:4,5:11)]
top50genes

masterdf <- masterdf[order(masterdf$Tissue,masterdf$`HPV[Status]`, masterdf$`HPV[Type]`),]

## HPV16 AND 18
mat <- masterdf %>% #sample_n(150) %>%
  filter(is.na(`HPV[Type]`) | `HPV[Type]` %in% c('HPV18','HPV16')) %>%
  select(top50genes,ID) %>%
  tibble::column_to_rownames('ID') %>% t %>% as.matrix

rownames(mat) <- c('Tissue','HPV_Status','HPV_Type','TP53','PIK3CA','HRAS','CDKN2A','TERT',
                   'EGFR','PTEN','NOTCH1')

## draw oncoplot

alter_fun = list(
  background = function(x, y, w, h) 
    grid.roundrect(x, y, w*.6, h*0.9, gp = gpar(fill = "#CCCCCC", col = NA)),
  #
  MUT = function(x, y, w, h) 
    grid.roundrect(x, y, w*0.6, h*0.4, gp = gpar(fill = "#4DAC26", col = NA)),
  WT = function(x, y, w, h) 
    grid.roundrect(x, y, w*0.6, h*0.9, gp = gpar(fill = "#CCCCCC", col = NA)),
  Positive = function(x, y, w, h) 
    grid.roundrect(x, y, w*0.6, h*0.9, gp = gpar(fill = "#e50000", col = NA)),
  Negative = function(x, y, w, h) 
    grid.roundrect(x, y, w*0.6, h*0.9, gp = gpar(fill = "black", col = NA)),
  cervix = function(x, y, w, h) 
    grid.roundrect(x, y, w*0.6, h*0.9, gp = gpar(fill = "orange", col = NA)),
  `head and neck` = function(x, y, w, h) 
    grid.roundrect(x, y, w*0.6, h*0.9, gp = gpar(fill = "#2986cc", col = NA)),
  HPV16 = function(x, y, w, h) 
    grid.roundrect(x, y, w*0.6, h*0.9, gp = gpar(fill = "#6cb8a6", col = NA)),
  HPV18 = function(x, y, w, h) 
    grid.roundrect(x, y, w*0.6, h*0.9, gp = gpar(fill = "#f27596", col = NA))
   )

test_alter_fun(alter_fun)

#column_title = paste("Top ",n," hotspot Mutation heatmap for M20-431 tumors",sep = '')
heatmap_legend_param = list(title = "", 
                            at = c("MUT",'WT','Positive','Negative','cervix','head and neck',
                                   'HPV16','HPV18'), 
                            labels = c("MUT",'WT','Positive','Negative','cervix','head and neck',
                                       'HPV16','HPV18'),
                            legend_direction = 'horizontal')

##match second vector to first vector
col = c("MUT" = "#4DAC26",'WT' = '#cccccc',
        'Positive' = '#e50000','Negative' = 'black',
        'cervix' = 'orange','head and neck' = '#2986cc',
        'HPV16' = '#6cb8a6','HPV18' = '#f27596')

sample_order <- data.frame(mat %>% t,ID = colnames(mat))
sample_order <- sample_order[order(sample_order$Tissue,sample_order$HPV_Status,sample_order$HPV_Type,sample_order$TP53,
                                   sample_order$PIK3CA,sample_order$CDKN2A,sample_order$HRAS,sample_order$NOTCH1,
                                   sample_order$TERT,sample_order$EGFR,sample_order$PTEN),]

row_order <- data.frame(mat %>% t) %>% pivot_longer(cols = 4:11) %>% group_by(name,value) %>% reframe(counts = n()) %>% 
  filter(value =='MUT') %>% arrange(-counts)

TMB <- read.csv('~/HPV_E6/TMB.csv')
TMB <- TMB[match(sample_order$ID,TMB$ID),]
identical(TMB$ID,sample_order$ID)

oncoPrint(mat,
          alter_fun = alter_fun, col = col, 
          remove_empty_columns = F, remove_empty_rows = F,
          heatmap_legend_param = heatmap_legend_param,
          top_annotation = HeatmapAnnotation(
            TMB = anno_points(TMB$total_perMB),
            annotation_name_gp= gpar(fontsize = 8)
            ),
          right_annotation = NULL,
          pct_side = "none", row_names_side = "left",
          row_order = c(rownames(mat)[1:3],row_order$name), 
          column_order = sample_order$ID)
    # ,heatmap_legend_side="bottom"

## TP53 vs HPV16,18

test <- mat %>% t %>% as.data.frame %>% #filter(TP53 != '') %>% 
  mutate(TP53_edit = TP53, Type = HPV_Type ) %>% 
  mutate(TP53_edit = ifelse(TP53_edit == '','Not report',TP53)) %>% 
  mutate(Type = ifelse(is.na(HPV_Type),'HPV_Negative',Type))

ggplot(test, aes(Type, fill=TP53_edit)) +
  geom_bar(stat = 'count',color = 'black',position = 'fill') +
  theme_classic()+ labs(x='',y = 'Percentage',fill='TP53 Mutation') +
  guides(fill = guide_legend(
    nrow = 4 ))+ 
  theme(axis.text.x = element_text(size=8))+
  facet_wrap(~Tissue,nrow=1,scales = 'free_x') +
  scale_fill_manual(values = c('#4DAC26','#cccccc','grey30'))

## maftools to incorporate TMB, https://bioconductor.org/packages/release/bioc/vignettes/maftools/inst/doc/maftools.html
library(maftools)

##Analysis of TCGA cohorts with maftools is as easy as it can get. This is made possible by processing TCGA MAF files from Broad firehose and TCGA MC3 project. Every cohort is stored as an MAF object containing somatic mutations (no CNVs) along with the relevant clinical information. There are two functions
##1) available cohorts
tcga_avail = tcgaAvailable()
tcga_avail

##2)Loading a TCGA cohort
# By default MAF from MC3 project will be loaded

CESC_mc3 = tcgaLoad(study = "CESC")
HNSC_mc3 = tcgaLoad(study = "HNSC")

TMB <- tmb(CESC_mc3) %>% rbind(tmb(HNSC_mc3)) %>% 
  mutate(sample_id = Tumor_Sample_Barcode ) %>% 
  separate(sample_id, 'sample_id',sep = '-01A|-06A',extra = 'drop')

test <- masterdf %>% filter(masterdf$ID %in% colnames(mat)) %>% 
  left_join(TMB)
  
write.csv(test, '~/HPV_E6/TMB.csv',row.names = F)

pdf('~/HPV_E6/oncoplot_cesc.pdf',width = 8,height = 5)
oncoplot(
  maf = CESC_mc3,
  genes = intGenes[1:5],
  clinicalFeatures = 'human_papillomavirus_type',
  sortByAnnotation = TRUE
)
dev.off()


pdf('~/HPV_E6/oncoplot_hnsc.pdf',width = 10,height = 5)
oncoplot(
  maf = HNSC_mc3,
  genes = intGenes[1:5],
  clinicalFeatures = 'hpv_status_by_ish_testing',
  sortByAnnotation = TRUE
)
dev.off()

## maftools hpv composition 20241028
test <- CESC_mc3@clinical.data %>% as.data.frame

test %>% ggplot(aes(x = test$p53_gene_analysis,
                        fill = test$human_papillomavirus_type)) +
  geom_bar(stat = 'count',position = 'fill',color = 'black') +
  labs(x='',y= 'Count', fill = '', title = 'CESC') + theme_classic()+
  guides(fill = guide_legend(
    nrow = 4 ))+ 
  theme(axis.text.x = element_blank()) 


### maf from tumor_portal

meta4 <- fread('/projects/grc/onc/data/tcga/tumor_portal/PanCan.maf') 
#Issues 1) Patient_id doesn’t match BR-0001 BR-0002 BR-0003 BR-0004 BR-0005. VS  TCGA-2W-A8YY-01A-11D-A37N-09
#2) cancer type nomenclature doesn’t match AML BLCA CARC CLL CRC DLBCL ESO.   VS  COAD LAML LCML

### extract P53 mutational data from Maftools

lollipopPlot(
  maf = CESC_mc3,
  gene = 'TP53',
  AACol = 'HGVSp_Short',
  showMutationRate = TRUE
)

lollipopPlot(
  maf = HNSC_mc3,
  gene = 'TP53',
  AACol = 'HGVSp_Short',
  showMutationRate = TRUE
)

cesc_mut <- CESC_mc3@data %>% select(-21 )%>% filter(Hugo_Symbol == 'TP53')

hnsc_muc <- HNSC_mc3@data %>% select(-21 )%>% filter(Hugo_Symbol == 'TP53')

TMB <- read.csv('~/HPV_E6/TMB.csv')

TP53_maftools <- rbind(cesc_mut,hnsc_muc) %>% 
  group_by(Tumor_Sample_Barcode,Hugo_Symbol, Variant_Classification) %>% 
  reframe(counts=n())


################################################################################
## clinical metadata from https://gdc.cancer.gov/about-data/publications/pancanatlas
## national cancer institute genomic data commons
################################################################################

gdc_meta <- fread('~/HPV_E6/clinical_PANCAN_patient_with_followup.tsv') 

table(gdc_meta$human_papillomavirus_type)
## confused

################################################################################
## clinical metadata from https://xena.ucsc.edu/download-data/
## ucsd xena https://cran.r-project.org/web/packages/UCSCXenaTools/vignettes/USCSXenaTools.html#data-hub-list
################################################################################

install.packages("UCSCXenaTools")
library(UCSCXenaTools)

data(XenaData)

XenaGenerate(subset = XenaHostNames=="tcgaHub") %>% 
  XenaFilter(filterDatasets = "clinical") %>% 
  XenaFilter(filterDatasets = "CESC|HNSC") -> df_todo


XenaQuery(df_todo) %>%
  XenaDownload() -> xe_download

cli = XenaPrepare(xe_download)
class(cli)
#> [1] "list"
names(cli)

cli$CESC_clinicalMatrix -> xena_cesc

cli$HNSC_clinicalMatrix -> xena_hnsc

## hpv status not working
########################################### 




#####################variant.classification.summary#######################################################################
### HPV positivity and P53 status
#######################################################################

masterdf %>% filter(`DNASeqSomaticMutationStatus[TP53]` %in% c('MUT','WT') &
                      `HPV[Type]` %in% c('HPV16','HPV18') |
                      `DNASeqSomaticMutationStatus[TP53]` %in% c('MUT','WT') &
                      is.na(`HPV[Type]`)) %>%
  ggplot(aes(x = `DNASeqSomaticMutationStatus[TP53]`,
                        fill = `HPV[Type]`)) +
  geom_bar(stat = 'count',position = 'fill',color = 'black') +
  labs(x='TP53 Mutation') + theme_classic()+
  guides(fill = guide_legend(
    nrow = 4 ))+ 
  theme(axis.text.x = element_text(size=8))+
  facet_wrap(~Tissue,nrow=1,scales = 'free_x')


##########################################################################
# PDL1 TPM read

tcga_exp <- read_rds('/projects/grc/onc/data/tcga/biolink/alltcga_expressionset_tpm_2020-07-17.RDS')
#tcga_exp_HPV <- tcga_exp[,tcga_exp$project %in% c('TCGA-CESC','TCGA-HNSC')]

masterdf <- read.csv('~/HPV_E6/masterdf_HPV_cases.csv')

masterdf <- masterdf[order(masterdf$Tissue,masterdf$HPV.Status.,masterdf$HPV.Type.),]

sample_order <- match(masterdf$sample_id,tcga_exp$sample_id) %>% na.omit()

test <- tcga_exp[,sample_order]

exp_meta <- pData(test) %>% left_join(masterdf) %>% column_to_rownames('sample_name')

pData(test) <- exp_meta  

## PDL1 expression

##1) log2(+1) converting expression data for TPMs
tumorTPM <- test

exprs(tumorTPM) <- log2(exprs(tumorTPM) + 1)

#2 QC plots
#Plotting some QC plots prior to differential expression analysis. 

hist(rowMeans(exprs(tumorTPM)))

##Histogram of row vars
hist(rowVars(exprs(tumorTPM)))

#Potentially an outlier. Checking which genes are over 15. 

intGenes <- which(rowVars(exprs(tumorTPM)) > 1)
intGS <- fData(tumorTPM)$SYMBOL[which(featureNames(tumorTPM) %in% names(intGenes))]

print(intGS)

####3. Subsetting to variable and expressed genes
rnaTUSE <- exprs(tumorTPM)[ which(rowMeans(exprs(tumorTPM)) > .15 & 
                                    rowVars(exprs(tumorTPM)) > 0.15), ]

##Getting tsne together
set.seed(777)
tstTSNE <- Rtsne(t(rnaTUSE),
                 check_duplicates=FALSE,
                 pca=TRUE,
                 perplexity=2,
                 theta=0.5,
                 dims=2)

##Making a dataframe for plotting
tstTSNEDF <- as.data.frame(tstTSNE$Y)
tstTSNEDF <- cbind(tstTSNEDF,pData(tumorTPM))

##4. Plotting
ggplot(data = tstTSNEDF, aes(x = V1, y = V2, col =  HPV.Type.)) +
  #geom_label(size = 4) + 
  #ggrepel::geom_label_repel(size = 3,# aes(y = V2 - 5, label = Diagnosis)
  #) + 
  geom_point(size = 2)+
  scale_x_continuous("tSNE X") +
  scale_y_continuous("tSNE Y") +
 # scale_color_manual(values = c("Archival Pre" = "navy","Fresh Pre" = 'black', 
#                                "On-Treatment" = "red")) + 
  theme_classic(base_size = 10) +
  theme(plot.title = element_text(hjust = 0.5)) +
  facet_wrap(~project,nrow = 2)

##5. ## Heatmap of key genes

pData(tumorTPM) <- pData(tumorTPM) %>% mutate(Type = HPV.Type.) %>% 
  separate(Type, into = 'Type',sep = ';', extra = 'drop') %>% 
  mutate(Type = ifelse(Type %in% c('HPV16','HPV18','HPV33','HPV45','HPV35','HPV58','HPV52','HPV39','HPV31'),
                                Type, 'Other'),
         TP53 = DNASeqSomaticMutationStatus.TP53.,
         HPV = tumorTPM$HPV.Status.)

##Plotting some relevant genes
intGenes <- c("CD274",'TP53','PIK3CA','CDKN2A','NOTCH1','HRAS','TERT','PTEN','FAT1'
              #, "CXCL9", "CXCL10", "IFNG", "GZMB", "PRF1", "CD3E", "CD4",
            #  "CD8A", "NKG7",'NKG2D','TRGV4','TRDV1', "KLRC1", "ARG1", "CLEC9A", "CD68", "CD163",
             # "FOXP3", "CTLA4", "ICOS", "HAVCR2", "MKI67", "CENPA"
            )

##Subsetting to only these genes

rnaLINT <- tumorTPM[match(intGenes,fData(tumorTPM)$SYMBOL), 
                    tumorTPM$DNASeqSomaticMutationStatus.TP53. != "" ]

##Peeling off, subsetting annotation data
annoSS <- pData(rnaLINT) %>% dplyr::select(#"Patient_ID", #"Mosaic_ID", 
  "Tissue", "HPV", 
  # "Months on Treatment",
  'Type','TP53'
  #,'sample_label' 
)

sample_order <- pData(rnaLINT)[order(rnaLINT$Tissue,rnaLINT$HPV,rnaLINT$TP53,rnaLINT$Type),]

##Heatmap
draw(ComplexHeatmap::pheatmap(exprs(rnaLINT),
                         labels_row = fData(rnaLINT)$SYMBOL,
                         #labels_col = pData(rnaLINT)$sample_label,
                         show_colnames = F, 
                         show_rownames = TRUE,
                         annotation_colors = list(
                            "TP53" = c("WT" = "grey30",
                                     "MUT" = "#4DAC26"),
                           "Tissue" = c("cervix" = "orange",
                                        "head and neck" = '#2986cc'),
                           "HPV" = c("Negative" = "black",
                                            "Positive" = "#e50000"),
                           "Type" = c("HPV16" = "#6cb8a6",
                                          "HPV18" = '#f27596',
                                          "HPV31" = "#c19280",
                                          "HPV33" = '#fbd266',
                                          "HPV35" = "#c8a2c8",
                                          "HPV39" = '#d76735',
                                          "HPV45" = "#b2d2dc",
                                          "HPV52" = '#c59d64',
                                          "HPV58" = "#235789",
                                          "Other" = '#cccccc')
                         ),
                         
                         color = circlize::colorRamp2(c(-2, 0, 2), c("blue", "white", "red")),
                         scale = "row",
                         #clustering_distance_rows = "euclidean",
                         #clustering_method = "ward.D2",
                         cluster_rows = F,
                         cluster_cols = F,
                         annotation_col = annoSS,
                         column_order = rownames(sample_order)),
     merge_legend = TRUE)

### gene expression by subgroups

test <- exprs(rnaLINT) %>% t %>% as.data.frame
colnames(test) <- paste(fData(rnaLINT)$SYMBOL,'exp',sep='_')

test <- pData(rnaLINT) %>% cbind(test)

ggplot(test, aes(Type,CD274_exp,color=Type)) +
  geom_boxplot() +
  geom_jitter(shape=1,alpha=.6,size=1) +
  facet_wrap(~Tissue,nrow=1,scales = 'free_x') +
  labs(x='', y = 'CD274 expression log2(TPM+1)') +
  theme_classic() +
  theme(axis.text.x = element_text(angle=90))







