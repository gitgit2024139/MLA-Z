library(tidyverse)
library(dplyr)
library(readxl)
library(data.table)
library(Biobase)
library(genefilter)
library(Rtsne)
library(ggplot2)
library(gridExtra)
library(pheatmap)
library(gplots)
library(limma)
library(RColorBrewer)
library(reshape)
library(GSVA)
library(quantiseqr)
library(ComplexHeatmap)
library(lessR)

#1. tpm tcga

meta1 <- fread('~/HPV_E6/DepMapQ225/Model.csv') 

meta2 <- fread('~/HPV_E6/DepMapQ225/OmicsSomaticMutationsMatrixHotspot.csv') %>% select(1,grep('^TP53',colnames(.))) %>% 
  dplyr::rename('TP53_HotspotMutation' = 'TP53 (7157)')

meta3 <- fread('~/HPV_E6/DepMapQ225/OmicsSomaticMutationsMatrixDamaging.csv') %>% select(1, 'TP53 (7157)') %>% 
  dplyr::rename('TP53_DamagingMutation' = 'TP53 (7157)')

meta4 <- meta2 %>% left_join(meta3) %>% 
  mutate(TP53_HotspotMutation = as.numeric(TP53_HotspotMutation),
         TP53_DamagingMutation = as.numeric(TP53_DamagingMutation)) %>% 
  rowwise() %>% mutate(TP53_status = sum(c(TP53_HotspotMutation,TP53_DamagingMutation))) %>% 
  mutate(TP53_status = ifelse(TP53_status > 0, 'Mutant','Wild-Type'))

exp_CRISPR <- fread('~/HPV_E6/DepMapQ225/CRISPRGeneEffect.csv') %>% select(1,grep('^UBE3A',colnames(.))) %>% 
  dplyr::rename('UBE3A' = 'UBE3A (7337)')

exp_HPV <- fread('~/HPV_E6/DepMapQ225/OmicsExpressionTPMLogp1Virus.csv') %>% 
  select(1,grep(paste(c('HpV16gp1','HpV18gp1'),collapse = '|'),colnames(.))) %>% 
  dplyr::rename('HPV16E6' = 'NC_001526.4@HpV16gp1@1489078', 'HPV18E6' = 'NC_001357.1@HpV18gp1@P06463') %>% 
  rowwise()%>%
  mutate(HPV16_18_E6_mean = mean(c(HPV16E6, HPV18E6)))

#1) combine mutation and HPV status

masterdf <- meta4 %>% 
  left_join(exp_HPV) %>% 
  left_join(exp_CRISPR) %>% 
  left_join(meta1 %>% select(1,OncotreeLineage) %>% dplyr::rename('V1' = 'ModelID')) %>% 
  replace_na(list(HPV16_18_E6_mean = 0, UBE3A = 0)) %>% 
  mutate(OncotreeLineage = ifelse(OncotreeLineage %in% c('Cervix','Head and Neck','Prostate'), OncotreeLineage,'Other cancers'))
  
  
write.csv(masterdf, '~/HPV_E6/DepMapQ225/HPV16_18_E6AP_Q225_DEPMAP.csv',row.names = F)
 ### visualization

ggplot(masterdf, aes(UBE3A, HPV16_18_E6_mean)) +
  geom_point(size=4,alpha = .9,
             aes(shape = TP53_status, 
                 color = factor(OncotreeLineage,
                                levels = c('Cervix','Head and Neck','Prostate','Other cancers')))) +
  labs(x='E6AP Gene Effect', y = 'HPV16/18 expression log2(TPM+1)',color='OncotreeLineage') +
  theme_classic() +
  scale_color_manual(values = c('#1B9E77','#D95F02','#E7298A','grey30'))


brewer.pal(n = 8, name = "Dark2")
