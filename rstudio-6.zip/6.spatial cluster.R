library(data.table)
library(Matrix)
library(dplyr)
library(stringr)
library(tidyr)
library(ggplot2)
library(tibble)

setwd("~/PTPN2_ST/PTPN2_ST_R/")

outdir <- './Spatial_cluster_hieratype/'

library(mclust)
library(irlba)
library(spatstat)
library(spatstat.geom)
library(spatstat.explore)

source("utils/spatial functions.R")

#Adjust globals option to avoid an error exceeding max allowed size. We’ve found this is necessary even with relatively small CosMx SMI datasets (30 - 40 FOVs).
options(future.globals.maxSize = 8000 * 1024^2)

#################################################################################
#ONE. to study how cells change in response to their spatial context
#distance to nearest tumor cell, number of tumor cells in neighborhood, neighborhood expression level of a given cytokine
##1. # load data:
# note these files are for convenience during analysis, and are not a NanoString-supported format

masterdf <- rbind(data.frame(fullpath = list.files('~/PTPN2_ST/PTPN2_ST_R/data_processing_CosMxref',
                                         pattern = "norm.RDS",full.names = T )) %>% 
  mutate(filename = basename(fullpath),
         sample = str_split(filename,pattern = 'processed_data',simplify = T)[,1],
         filetype = "norm"
  ),
  data.frame(fullpath = list.files('~/PTPN2_ST/PTPN2_ST_R/data_processing_CosMxref',
                                   pattern = "metadata.RDS",full.names = T )) %>% 
    mutate(filename = basename(fullpath),
           sample = str_split(filename,pattern = 'processed_data',simplify = T)[,1],
           filetype = "metadata"
    ),
  data.frame(fullpath = list.files('~/PTPN2_ST/PTPN2_ST_R/data_processing_CosMxref',
                                   pattern = "insitutype_initial_results.RDS",full.names = T )) %>%
    mutate(filename = basename(fullpath),
           sample = str_split(filename,pattern = 'insitutype_initial_results',simplify = T)[,1],
           filetype = "celltype"
    ),
  data.frame(fullpath = list.files('~/PTPN2_ST/PTPN2_ST_R/data_processing_CosMxref',
                                   pattern = "xy.RDS",full.names = T )) %>% 
    mutate(filename = basename(fullpath),
           sample = str_split(filename,pattern = 'processed_data',simplify = T)[,1],
           filetype = "xy"
    )
) %>% dplyr::select(-filename) %>%
  pivot_wider(names_from = filetype, values_from = fullpath)
  
## 1.2 read in Hieratype cell type read out

T_sub_df <- read.csv('~/PTPN2_ST/PTPN2_ST_R/HieraType/HieraTypebindlist_T_subtype.csv')


## 2.  Spatial clustering,  we record the mean expression in each cell’s neighborhood, and we cluster cells based on these values
spatial_df <- data.frame()

for (i in seq_along(masterdf$sample)) {
  
  #norm <- readRDS(masterdf$norm[i])
  metadata <- readRDS(masterdf$metadata[i]) 
  #celltype <- readRDS(masterdf$celltype[i])
  xy <- readRDS(masterdf$xy[i])
  
  #get celltype from hieratype csv
  celltype <- T_sub_df %>% mutate(sample = gsub('[- ]','', Run_Tissue_name)) %>%
    filter(sample == masterdf$sample[i]) %>% 
    dplyr::select(cell_ID,celltype_comprehensive,tissue_portion,Response) %>% 
    filter(cell_ID %in% metadata$cell_id) %>%
    tibble::column_to_rownames('cell_ID')
  
  #cluster cells based on the cell type composition of their neighborhoods:
  ## get neighborhood cell type abundance:
  # create a point process object:
  pp <- spatstat.geom::ppp(xy[, 1], xy[, 2], xrange = range(xy[, 1]), 
                           yrange = range(xy[, 2]))
  marks(pp) <- celltype$celltype_comprehensive
  spatstat.geom::marks(pp) <- as.factor(spatstat.geom::marks(pp))
  # count neighbors of each db cluster:
  neighbormarks <- spatstat.explore::marktable(X = pp, R = NULL, N = 50, exclude=TRUE, collapse=FALSE)
  neighbormarks <- as.matrix(neighbormarks)
  rownames(neighbormarks) <- rownames(xy)
  head(neighbormarks)
  
  ## cluster it: 
  spatialclust <- mclust::Mclust(neighbormarks, #sweep(neighbormarks, 1, rowSums(neighbormarks), "/"),
                                 G = 8, # 8 clusters
                                 modelNames = c("EEI"))$classification
  ## plot the results:
  # subset for faster plotting:
  sub <- sample(1:nrow(xy), round(nrow(xy) / 20), replace = FALSE)
  # color palette:
  cols <- c("#616161","#4285f4","#db4437","#f4b400","#0f9d58","#ab47bc","#00acc1",
            "#ff7043","#9e9d24","#5c6bc0","#f06292","#00796b","#c2185b","#7e57c2",
            "#03a9f4","#8bc34a","#fdd835","#fb8c00","#8d6e63","#9e9e9e","#607d8b")
  
  filename <- paste(outdir, "plot_xy_",masterdf$sample[i],"_spatial_context",".png",sep = '')
  png(filename)
  
  # plot:
  plot(xy[sub, ], pch = 16, cex = 0.5, 
       asp = 1, 
       col = cols[as.numeric(as.factor(spatialclust[sub])) %% length(cols) + 1])
   
  dev.off()
  
  # add to metadata:
  celltype$spatialclust <- spatialclust
  
  celltype$sample <- masterdf$sample[i]
  
  
  
  #Hand-defining spatial context
  #1. Distance to a given cell type:
  
  # # record IDs and distances to nearest 50 neighbors:
  # tumorcelltypes <- celltype$celltype_comprehensive == 'epithelial'
  # 
  # neighbors_dists <- FNN::get.knnx(data = xy[is.element(celltype$celltype_comprehensive, 
  #                                                       tumorcelltypes), ], 
  #                                  query = xy, 
  #                                  k = 5)
  # 
  # str(neighbors_dists)
  # # record distance to a cell type:
  # metadata$disttonearesttumor <- neighbors_dists$nn.dist[, 1]
  # # record 3rd-closest distance to the cell type:
  # metadata$distto3rdnearesttumor <- neighbors_dists$nn.dist[, 3]
  # 
  ##2. Number of neighbors of a cell type:
  #you might categorize cells by how many of a given cell type are in their neighborhood:
  
  # create a point process object:
  pp <- spatstat.geom::ppp(xy[, 1], xy[, 2], xrange = range(xy[, 1]), yrange = range(xy[, 2]))
  marks(pp) <- celltype$celltype_comprehensive
  spatstat.geom::marks(pp) <- celltype$celltype_comprehensive
  spatstat.geom::marks(pp) <- as.factor(spatstat.geom::marks(pp))
  # count nearest 50 neighbors of each db cluster:
  neighbormarks <- spatstat.explore::marktable(X = pp, R = NULL, N = 50, exclude=TRUE, collapse=FALSE)
  neighbormarks <- as.matrix(neighbormarks)
  rownames(neighbormarks) <- rownames(xy)
  head(neighbormarks)[, 1:10] 
  colnames(neighbormarks)
  
  for (item in colnames(neighbormarks)) {

    name <- paste("n_",gsub('\\.','_',item),"_neighbors",sep = '')

    celltype <- celltype %>% mutate( !!name := neighbormarks[, item])

  }
  
  celltype <- celltype %>% tibble::rownames_to_column('cell_ID')
  
  
  spatial_df <- bind_rows(spatial_df, celltype)
  
  }

write.csv(spatial_df, 
          '~/PTPN2_ST/PTPN2_ST_R/Spatial_cluster_hieratype/spatial_cluster.csv',
          row.names = F)

## 3. umap of spatial clustering 

umap <- read.csv('~/PTPN2_ST/umap_coordinates.csv')

spatial_df_plt <- spatial_df %>% left_join(.,umap, by = c('cell_ID','sample')) %>% 
  filter(!is.na(spatialclust)) %>% 
  mutate(spatialclust = as.factor(spatialclust))

ggplot(spatial_df_plt , 
       aes(UMAP1, UMAP2,color=spatialclust)) +
  geom_point(size=.001) +
  theme_classic() +
  #scale_color_manual(values = c('darkgreen','grey70'))+
  labs(color='')

## 4. barplot of spatial clustering in each tissue portion

spatial_df_plt %>% 
  group_by(tissue_portion, spatialclust,Response) %>% 
  summarise(counts = n(), .groups = 'drop') %>%
  group_by(tissue_portion,Response) %>%
  mutate(frequency = counts / sum(counts)) %>%
  ungroup() %>% 
  ggplot(aes(x = tissue_portion, y = frequency, 
             fill = spatialclust)) +
  geom_bar(stat = 'identity', position = 'fill') +
  theme_classic()+
  labs(title = 'Relative spatial clusters by Response group',
       x = '',
       y = 'Proportion',
       fill='') +
  theme(axis.text.x = element_text(angle=90,size=7)) +
  scale_fill_manual(values = c("#616161","#4285f4","#db4437","#f4b400","#0f9d58","#ab47bc","#00acc1",
                               "#ff7043","#9e9d24","#5c6bc0","#f06292","#00796b","#c2185b","#7e57c2",
                               "#03a9f4","#8bc34a","#fdd835","#fb8c00","#8d6e63","#9e9e9e","#607d8b")) +
  facet_wrap(~Response,nrow=1,scale='free_x')


## 5. barplot of spatial clustering cell type content

spatial_df_plt %>% 
  group_by(spatialclust,Response,celltype_comprehensive) %>% 
  summarise(counts = n(), .groups = 'drop') %>%
  group_by(spatialclust,Response) %>%
  mutate(frequency = counts / sum(counts)) %>%
  ungroup() %>% 
  ggplot(aes(x = spatialclust, y = frequency, 
             fill = celltype_comprehensive)) +
  geom_bar(stat = 'identity', position = 'fill',color='black') +
  theme_classic()+
  labs(title = 'Relative cell type composition in spatial cluster by Response group',
       x = '',
       y = 'Proportion',
       fill='') +
  theme(axis.text.x = element_text(angle=90,size=7)) +
  # scale_fill_manual(values = c("#616161","#4285f4","#db4437","#f4b400","#0f9d58","#ab47bc","#00acc1",
  #                              "#ff7043","#9e9d24","#5c6bc0","#f06292","#00796b","#c2185b","#7e57c2",
  #                              "#03a9f4","#8bc34a","#fdd835","#fb8c00","#8d6e63","#9e9e9e","#607d8b")) +
  facet_wrap(~Response,nrow=1,scale='free_x')


