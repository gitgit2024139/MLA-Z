library(ggplot2)
library(ggrepel)
library(data.table)
#remotes::install_github("Nanostring-Biostats/CosMx-Analysis-Scratch-Space", 
#                        subdir = "_code/HieraType", ref = "Main")
library(HieraType)

setwd("~/PTPN2_ST/PTPN2_ST_R/")

outdir <- './HieraType/'

#source("utils/spatial functions.R")
#Adjust globals option to avoid an error exceeding max allowed size. We’ve found this is necessary even with relatively small CosMx SMI datasets (30 - 40 FOVs).
options(future.globals.maxSize = 8000 * 1024^2)

#################################################################################
#ONE: Broad immune cell classification
#Using the full dataset, we can create a pipeline to 
#1. first infer amongst 5 major cell type categories [immune, epithelial, endothelial, fibroblast, plasma] in a similar fashion as described in our first example.
#2. we’ll infer subtypes of the immune cell labels with categories including [tcell,bcell,macrophage,neutrophil,mast,monocyte,cDC,pDC]. 
#3. we’ll do some basic subclassification of the tcells into [cd4t,cd8t].

##1. # load data:
### Pipeline, with 
### level-1 ('l1') being major categorization 
### level-2 ('l2') being classification of major immune cell categories
### level-t ('lt') being T8/T4 classification

pipeline_io <- HieraType::make_pipeline(
  markerslists = list("l1" = HieraType::markerslist_l1
                      ,"l2" = HieraType::markerslist_immunemajor
                      ,"lt" = HieraType::markerslist_tcellmajor)
  ,priors = list("lt" = "l2"
                 ,"l2" = "l1") 
  ,priors_category = list("lt" = "tcell"
                          ,"l2" = "immune")
)


seuratlist <- data.frame(path = list.files(path = '/projects/grc/io/datasets/ptpn2i/GTG-2243-PTPN2',
                         pattern = 'seurat',recursive = T,
                         full.names = T)) %>% 
  mutate(file = basename(path) %>% sub('^((?:[^.]*\\.){2}).*', '\\1', .) %>% 
           sub('seuratObject_','',.) , 
         name = 'HieraType',
         portion = c('11','23',
                     "21","54","64","11","23","39","14","OTX","SCR","OTX","SCR"
                     )) 

for (i in seq_along(seuratlist$path)[3:13]) {
  
  sem <- readRDS(seuratlist$path[i])
  
  ### run my pipeline (using all cells)
  if( i %in% 6:7) {
    
    immune_typing <- 
      run_pipeline(pipeline = pipeline_io
                   ,counts_matrix = Matrix::t(sem[["RNA"]]@counts)
                   ,adjacency_matrix = as(sem@graphs$RNA_RNA.cosmx_Neighbor.network.expression.space.1_1_snn
                                          ,"CsparseMatrix")
                   ,celltype_call_threshold = 0.5
                   ,return_all_columns_postprobs = FALSE
      )
  } else {
    
    immune_typing <- 
      run_pipeline(pipeline = pipeline_io
                   ,counts_matrix = Matrix::t(sem[["RNA"]]@counts)
                   ,adjacency_matrix = as(sem@graphs$RNA_RNA.modules_Neighbor.network.expression.space.1_1_snn
                                          ,"CsparseMatrix")
                   ,celltype_call_threshold = 0.5
                   ,return_all_columns_postprobs = FALSE
      )
  }
  
  
  fc_l1 <- 
    clusterwise_foldchange_metrics(normed = sem[["RNA"]]@data
                                   ,metadata =immune_typing$post_probs[[1]]
                                   ,cluster_column = "celltype_granular"
    )
  
  hm_l1 <- marker_heatmap(fc_l1, extras = c("CD3D", "CD4", "CD8A", "CD8B", "FOXP3"))
  print(hm_l1)
  
  
  #spatial plot of the cell types 
  met <- merge(data.table(sem@meta.data)
               ,immune_typing$post_probs$l1[,.(cell_ID, celltype_supervised = celltype_granular)]
               ,by="cell_ID")
  
  colorpal <- c('#F0A0FF','#E0FF66','#C20088','#00998F','#426600'
                , "#4C005C" 
                ,'#191919'
                ,'#003380', '#005C31','#94FFB5','#990000','#0075DC','#FFA405')
  
  names(colorpal) <- sort(unique(met[["celltype_supervised"]]))
  
  if (i %in% 3:9) {
    met <- met %>% mutate(portion = ifelse(fov <= seuratlist$portion[i],'SCR','OTX'),
                          tissue_portion = paste(Run_Tissue_name,portion,sep = '_'))
  } else {
    met <- met %>% mutate(portion = seuratlist$portion[i],
                          tissue_portion = paste(Run_Tissue_name,portion,sep = '_'))
  }
 
  filename <- paste(outdir, "plot_xy",seuratlist$file[i],"_HieraType.png",sep = '')
  png(filename)
  
  xyplist_sup <- 
    lapply(split(met, by="tissue_portion"), function(xx){
      HieraType:::xyplot(cluster_column = "celltype_supervised", metadata = xx
                         , ptsize = 0.1, cls = colorpal
                         #,clusters = c("cd4t", "cd8t", "bcell")
                         #                       , ptsize = 0.01, cls = colorpal
                         ,plotfirst = c("epithelial", "endothelial", "fibroblast", "smooth_muscle", "plasma")
      ) + coord_fixed()
    }) 
  
  xyplot_sup <- 
    cowplot::plot_grid(plotlist = xyplist_sup,nrow = 1) + 
    theme(plot.background = element_rect(fill = 'white',color='white')) + 
    cowplot::panel_border(remove=TRUE)
  
  print(xyplot_sup)
  
  dev.off()
   
  saveRDS(met, paste0(outdir,'HieraType',seuratlist$file[i],"_metadata_with_HieraType.RDS",sep = ''))
  
  }

## write all HieraType annotation into one csv

HieraTypelist <- list.files('~/PTPN2_ST/PTPN2_ST_R/HieraType/',pattern = 'metadata',
                            recursive = T,full.names = T)

#bind all the hierratype annotation into one csv
df <- rbindlist(lapply(HieraTypelist, readRDS),fill = T)
write.csv(df,'~/PTPN2_ST/PTPN2_ST_R/HieraType/HieraTypebindlist.csv',row.names = F)

##save rds to csv in a list of files
for (file in HieraTypelist) {
    data <- readRDS(file)  # Read the .rds file
    csv_name <- sub('.RDS$', '.csv', file)  # Replace .rds with .csv
    write.csv(data, csv_name, row.names = FALSE)
 }

## analyze HierraType downstream

df <- read.csv('~/PTPN2_ST/PTPN2_ST_R/HieraType/HieraTypebindlist.csv') 
df[,c('celltype_supervised','cell_ID','Run_Tissue_name','tissue_portion')]

df$Response = 'NE'
df$Response = ifelse(df$Run_Tissue_name %in% c("2203-TONSIL REPEAT", "2204-hnscc-repeat-batch1"),
                     'PD',df$Response)
df$Response = ifelse(df$Run_Tissue_name %in% c("16004-1-cRcc","16004-2-cRcc",
                                               "30012-2-117 SLIDE","30012-1-116 SLIDE"),
                     'SD',df$Response)
df$Response = ifelse(df$Run_Tissue_name %in% c("2801-OTX-cRcc","2801-SCR-cRcc-Repeat"),
                     'NE',df$Response)
df$Response = ifelse(df$Run_Tissue_name %in% c("2503-OTX-cRcc","2503-SCR-cRcc"),
                     'PR',df$Response)
df$Response = ifelse(df$Run_Tissue_name %in% c("2501-cRCC"),
                     'CR',df$Response)

df$Diagnosis = 'NE'
df$Diagnosis = ifelse(df$Run_Tissue_name %in% c("2203-TONSIL REPEAT", "2204-hnscc-repeat-batch1"),
                      'HNSCC',df$Diagnosis)
df$Diagnosis = ifelse(df$Run_Tissue_name %in% c("30012-2-117 SLIDE","30012-1-116 SLIDE"),
                      'NSCLC',df$Diagnosis)
df$Diagnosis = ifelse(!(df$Run_Tissue_name %in% c("30012-2-117 SLIDE","30012-1-116 SLIDE",
                                                  "2203-TONSIL REPEAT", "2204-hnscc-repeat-batch1")),
                      'RCC',df$Diagnosis)

df$sample = df$Run_Tissue_name
df$sample = ifelse(df$sample %in% c("2503-OTX-cRcc","2503-SCR-cRcc"),
                      '2503-cRcc',df$sample)
df$sample = ifelse(df$sample %in% c("2801-OTX-cRcc","2801-SCR-cRcc-Repeat"),
                   '2801-cRcc',df$sample)

df$sample%>%table()


df %>% 
  group_by(tissue_portion, celltype_supervised,Diagnosis) %>% 
  summarise(counts = n(), .groups = 'drop') %>%
  group_by(tissue_portion,Diagnosis) %>%
  mutate(frequency = counts / sum(counts)) %>%
  ungroup() %>%
  ggplot(aes(x = tissue_portion, y = frequency, fill = celltype_supervised)) +
  geom_bar(stat = 'identity', position = 'fill') +
  theme_classic()+
  labs(title = 'Relative composition of cell types by tissue portion',
       x = '',
       y = 'Proportion') +
  theme(axis.text.x = element_text(angle=90,size=7)) +
  scale_fill_manual(values = c("#616161","#4285f4","#db4437","#f4b400","#0f9d58","#ab47bc","#00acc1",
          "#ff7043","#9e9d24","#5c6bc0","#f06292","#00796b","#c2185b","#7e57c2",
          "#03a9f4","#8bc34a","#fdd835","#fb8c00","#8d6e63","#9e9e9e","#607d8b")) +
  facet_wrap(~Diagnosis,nrow=1,scale='free_x')


## per cell population compositional change after PTPN2

df %>% 
  group_by(Response,sample,portion, celltype_supervised) %>% 
  summarise(counts = n(), .groups = 'drop') %>%
  group_by(sample,portion,Response) %>%
  mutate(frequency = counts / sum(counts)) %>%
  ungroup() %>% 
  
  ggplot(aes(x = portion, y = frequency)) +
  geom_line(aes(group = sample)) +
  scale_color_manual(values = c("#616161","#4285f4","#db4437","#f4b400","#0f9d58","#ab47bc","#00acc1",
                               "#ff7043","#9e9d24","#5c6bc0","#f06292","#00796b","#c2185b","#7e57c2",
                               "#03a9f4","#8bc34a","#fdd835","#fb8c00","#8d6e63","#9e9e9e","#607d8b"))
  


df %>% 
  group_by(Response,sample,portion, celltype_supervised) %>% 
  summarise(counts = n(), .groups = 'drop') %>%
  group_by(sample,portion,Response) %>%
  mutate(frequency = counts / sum(counts)) %>%
  ungroup()%>% 
  mutate(Treatment = factor(portion, levels = c('SCR','OTX'))) %>% 
  ggplot(aes(x = Treatment,y=frequency)) +
  #geom_boxplot(aes(color = 'Treatment'), alpha = .1)+
  geom_line(aes(group = sample,color = Response),linetype = 1,linewidth=1) + 
  geom_point(size=2,shape = 2) +
  facet_wrap(~ celltype_supervised+Response,ncol = 15) + 
  theme_bw(base_size = 10,base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0, "cm"), 
            axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
            legend.position = 'right',strip.background = element_rect(fill = 'white')) +
  labs(x = '', y = 'Frequency', fill = '') +
  scale_fill_manual(values = c("#616161","#4285f4","#db4437","#f4b400","#0f9d58","#ab47bc","#00acc1",
                               "#ff7043","#9e9d24","#5c6bc0","#f06292","#00796b","#c2185b","#7e57c2",
                               "#03a9f4","#8bc34a","#fdd835","#fb8c00","#8d6e63","#9e9e9e","#607d8b"))

#### save updated HieraType metadata as final

write.csv(df,'~/PTPN2_ST/PTPN2_ST_R/HieraType/HieraTypebindlist.csv',row.names = F)

################################################################################################
###### 2. Subclustering T cells

data("pipeline_tcell")


seuratlist <- data.frame(path = list.files(path = '/projects/grc/io/datasets/ptpn2i/GTG-2243-PTPN2',
                                           pattern = 'seurat',recursive = T,
                                           full.names = T)) %>% 
  mutate(file = basename(path) %>% sub('.RDS', '', .) %>% 
           sub('seuratObject_','',.) , 
         name = 'HieraType',
         portion = c('11','23',
                     "21","54","64","11","23","39","14","OTX","SCR","OTX","SCR"
         )) 

## whole HieraType metadata to subset T cells out for subtyping

celltype <- read.csv('~/PTPN2_ST/PTPN2_ST_R/HieraType/HieraTypebindlist.csv')


## write loop to go through 11 files for T cell subtyping

for (i in seq_along(seuratlist$path)[3:13]) {
  
  sem <- readRDS(seuratlist$path[i])
  
  celltype_sample <- celltype[celltype$Run_Tissue_name == sem@meta.data$Run_Tissue_name%>%unique,]
  
  ### these are cells I want to subcluster
  tcell_ids <- celltype_sample[celltype_sample$celltype_supervised %in% c('cd4t','cd8t'), 
                        "cell_ID"]
  
  ### Run a 'tcell'-typing pipeline, which 
  ### first classifies into T8/T4 categories (using the `tmajor` markerslist), 
  ### then runs subclassification for T4 and T8 using the t4minor and t8minor markerslists.
  
  ### run my pipeline (using all cells)
  if( i %in% 6:7) {
    
    tcell_typing <- 
      run_pipeline(pipeline = pipeline_tcell
                   ,counts_matrix = Matrix::t(sem[["RNA"]]@counts[,tcell_ids])
                   ,adjacency_matrix = as(sem@graphs$RNA_RNA.cosmx_Neighbor.network.expression.space.1_1_snn
                                          ,"CsparseMatrix")[tcell_ids,tcell_ids]
                   ,celltype_call_threshold = 0.5
      )
    
  } else {
    
    tcell_typing <- 
      run_pipeline(pipeline = pipeline_tcell
                   ,counts_matrix = Matrix::t(sem[["RNA"]]@counts[,tcell_ids])
                   ,adjacency_matrix = as(sem@graphs$RNA_RNA.modules_Neighbor.network.expression.space.1_1_snn
                                          ,"CsparseMatrix")[tcell_ids,tcell_ids]
                   ,celltype_call_threshold = 0.5
      )
  }
  
  #Here we can attach our T-cell annotations back onto our metadata, and remake our marker heatmap.
  
  met <- 
    merge(celltype_sample, tcell_typing$post_probs[["tmajor"]]
          [,.(cell_ID, celltype_Tsub = celltype_granular, best_score_granular)]
          ,by="cell_ID", all.x=TRUE)
  
  #':=' is used for assigning or updating values by reference
  met <- met %>% 
    mutate(celltype_comprehensive = ifelse(is.na(celltype_Tsub), celltype_supervised, celltype_Tsub))
  
  ## T subtypes fold change across each cluster
  
  fc_t_all <- 
    HieraType::clusterwise_foldchange_metrics(normed = sem[["RNA"]]@data
                                              ,metadata = met
                                              ,cluster_column = "celltype_comprehensive"
    )
  
  ##save T subtype heatmap plot
  filename <- paste(outdir, "Heatmap_Tsubtype",seuratlist$file[i],"_HieraType.png",sep = '')
  png(filename, width = 800, height = 400)
  
  hm_tcell <- HieraType::marker_heatmap(fc_t_all
                                        ,extras = c("CD4", "CD8A", "CD8B")
  )
  print(hm_tcell)
  dev.off()
  
  saveRDS(met, paste0(outdir,'T_subtype',seuratlist$file[i]," _with_HieraType.RDS",sep = ''))
  
}


## write all HieraType annotation into one csv

HieraTypelist <- list.files('~/PTPN2_ST/PTPN2_ST_R/HieraType',pattern = 'T_subtype',
                            recursive = T,full.names = T)

#bind all the hierratype annotation into one csv
df <- rbindlist(lapply(HieraTypelist, readRDS),fill = T)

write.csv(df,'~/PTPN2_ST/PTPN2_ST_R/HieraType/HieraTypebindlist_T_subtype.csv',row.names = F)





