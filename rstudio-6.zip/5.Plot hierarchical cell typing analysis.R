library(ggplot2)
library(grid)
library(data.table)
library(R.utils)
library(dplyr)
library(ggsci)
library(pals)
library(FNN)
library(viridis)
library(scales)
library(ggplot2)
library(ggrepel)
library(data.table)
library(HieraType)
library(RColorBrewer)

# Read data
# cell_meta <- read.csv(paste0(raw_data_dir, "/", slide_name, "_metadata_file.csv.gz")) #Note this is a small file and we read it into a data frame for convenience
# cell_polygons <- fread(paste0(raw_data_dir, "/", slide_name, "-polygons.csv.gz"))
# fov_positions <- fread(paste0(raw_data_dir, "/", slide_name, "_fov_positions_file.csv.gz"))

setwd("~/PTPN2_ST/PTPN2_ST_R/")
outdir <- './HieraType/'
#Adjust globals option to avoid an error exceeding max allowed size. We’ve found this is necessary even with relatively small CosMx SMI datasets (30 - 40 FOVs).
options(future.globals.maxSize = 8000 * 1024^2)

#build all the polygon files into a dataframe
polygonlist <- list.files('~/PTPN2_ST/PTPN2_ST_R/HieraType',pattern = 'Polygon',
                                  recursive = T,full.names = T)

polygonlist <- data.frame(polygonfile = polygonlist) %>%
  mutate(sample = basename(polygonfile) %>% 
      gsub('Polygon','',.) %>%
      gsub('.RDS','',.))
  

#build all the fov_position files into a dataframe
fovpositionlist <- list.files('/projects/grc/io/datasets/ptpn2i/GTG-2243-PTPN2',
                              pattern = 'fov_position',recursive = T,full.names = T)

fov_poslist <- data.frame(fovpos = fovpositionlist) %>%
  mutate(sample = basename(fovpos) %>% 
           gsub('_fov_positions_file.csv.gz','',.)) 

fov_poslist <- fov_poslist[3:13,]

#################################################################################
## read in metadata with HierraType
cell_meta <- read.csv('~/PTPN2_ST/PTPN2_ST_R/HieraType/HieraTypebindlist.csv')

## 1 Set up scale bar function
make_scale_bar_r <- function(x_vals, y_vals, microns_per_pixel = 0.12028) {
  
  # Calculate x-axis range
  x_range <- range(x_vals, na.rm = TRUE)
  x_length <- diff(x_range)
  x_length_um <- x_length * microns_per_pixel
  
  # Target scale length ~1/4 of the x-axis
  target <- x_length_um / 4
  
  # Compute order of magnitude
  order <- 10^floor(log10(target))
  mantissa <- target / order
  
  # Round mantissa to nearest 1, 2, or 5
  nice_mantissa <- if (mantissa < 1.5) {
    1
  } else if (mantissa < 3.5) {
    2
  } else if (mantissa < 7.5) {
    5
  } else {
    10
  }
  
  # Final scale length in pixels
  scale_length_um <- nice_mantissa * order
  scale_length_px <- scale_length_um / microns_per_pixel
  
  # Format label
  scale_label <- if (scale_length_um >= 1000) {
    paste0(scale_length_um / 1000, " mm")
  } else {
    paste0(scale_length_um, " µm")
  }
  
  # Set coordinates for the scale bar 
  x_start <- x_range[2] - scale_length_px * 1.1
  x_end <- x_range[2] - scale_length_px * 0.1
  y_pos <- min(y_vals, na.rm = TRUE) + scale_length_px * 0.1
  
  # Generate scale bar background, scale bar and annotation to return
  list(
    bg = annotation_custom(
      grob = rectGrob(gp = gpar(fill = "white", alpha = 0.8, col = NA)),
      xmin = x_start- scale_length_px*0.05, xmax = x_end+ scale_length_px*0.05,
      ymin = y_pos- scale_length_px*0.05, ymax = y_pos + scale_length_px*0.3
    ),
    rect = annotation_custom(
      grob = rectGrob(gp = gpar(fill = "black")),
      xmin = x_start, xmax = x_end,
      ymin = y_pos, ymax = y_pos + scale_length_px * 0.05
    ),
    label = annotation_custom(
      grob = textGrob(scale_label, gp = gpar(col = "black"), just = "center", vjust = 0),
      xmin = (x_start + x_end)/2, xmax = (x_start + x_end)/2,
      ymin = y_pos + scale_length_px * 0.1, ymax = y_pos + scale_length_px * 0.1
    )
  )
}

##2 Set up scale bar
cell_meta <- cell_meta %>% 
  mutate(CenterX_global_px = x_FOV_px,
         CenterY_global_px = y_FOV_px)

scale_bar <- make_scale_bar_r(x_vals = cell_meta$CenterX_global_px,
                              y_vals = cell_meta$CenterY_global_px)

####################################################################################################
####Session One: check HieraType on xyplot

met <- cell_meta %>% filter(Response == 'CR')
met <- cell_meta %>% filter(Response == 'PR')
met <- cell_meta %>% filter(Response == 'SD')
met <- cell_meta %>% filter(Response == 'PD')


colorpal <- c("#616161","#4285f4","#db4437","#f4b400","#0f9d58","#ab47bc","#00acc1",
              "#ff7043","#9e9d24","#5c6bc0","#f06292","#00796b","#c2185b","#7e57c2",
              "#03a9f4","#8bc34a","#fdd835","#fb8c00","#8d6e63","#9e9e9e","#607d8b")

names(colorpal) <- sort(unique(met[["celltype_supervised"]]))

##1.1 whole FOV cell type view
xyplist_sup <- 
  lapply(split(met, f=met$portion), function(xx){
    HieraType:::xyplot(cluster_column = "celltype_supervised", metadata = xx
                       , ptsize = 0.1, cls = colorpal
                       ,plotfirst = c("epithelial", "fibroblast", "monocyte", "cd4t",'cd8t')
    ) + coord_fixed()
  }) 

xyplot_sup <- 
  cowplot::plot_grid(plotlist = xyplist_sup,nrow = 2) + 
  theme(plot.background = element_rect(fill = 'white',color='white')) + 
  cowplot::panel_border(remove=TRUE) 
print(xyplot_sup)

############################################################################
##1.2 FOV polygon visulization
## Add cell type to polygons
met <- cell_meta %>% filter(Response == 'CR')
met <- cell_meta %>% filter(Response == 'PR')
met <- cell_meta %>% filter(Response == 'SD', sample == '16004-1-cRcc')
met <- cell_meta %>% filter(Response == 'PD', sample == '2203-TONSIL REPEAT')
## Treg visulazation
met <- cell_meta %>% filter(Response == 'PD', sample == '2204-hnscc-repeat-batch1') 

polyfile <- polygonlist[polygonlist$sample == unique(met$Run_Tissue_name),]

cell_polygons <- readRDS(polyfile$polygonfile)

df <- met %>% group_by(tissue_portion,fov) %>%
  summarise(count = n()) %>% arrange(-count) %>%
  group_by(tissue_portion) %>%
  filter(count == max(count))

## fov4 == otx, fov21 == scr
#FOV='4'
FOV = df$fov[1]
FOV = df$fov[2]

plot.df <- cell_polygons %>% filter(fov %in% FOV) %>% as.data.frame()

meta <- as.data.frame(met) %>% filter(fov %in% FOV)

row.names(meta) <- meta$cell_ID
plot.df$cell_type <- as.data.frame(meta)[plot.df$cell, 'celltype_supervised']

## Set up scale bar
scale_bar <- make_scale_bar_r(x_vals = plot.df %>% pull(x_global_px),
                              y_vals =  plot.df %>% pull(y_global_px))

## Plot it
# Set the desired number of colors
nb.cols <- 13 # Example: for 20 colors
mycolors <- colorRampPalette(brewer.pal(8, "Set2"))(nb.cols)

ggplot(plot.df,
       aes(x = x_global_px, y = y_global_px, 
           group = cell, # Group cells for polygons
           fill = as.factor(cell_type))) + # Polygon fill by cell type
  geom_polygon(color = "black", linewidth = 0.3) +
  scale_fill_manual(values = mycolors) + #Palette inspired by UCSB Genome Browser
  coord_fixed() +
  theme_void() +
  labs(fill = "Cell type") +
  scale_bar$bg +
  scale_bar$rect +
  scale_bar$label


##1.3 FOV specific fibroblast and monocyte dark visulization
meta <- met %>% filter(fov %in% df$fov)

xyplist_lymph <- 
  lapply(split(meta, f = meta$portion), function(xx){
    HieraType:::xyplot(cluster_column = "celltype_supervised", metadata = xx
                       , ptsize = 0.05, cls = colorpal
                       ,clusters = c("fibroblast", "monocyte",'epithelial')
    ) + coord_fixed()
  })

lymphplot <- 
  cowplot::plot_grid(
    xyplist_lymph[[1]]  + 
      facet_wrap(~celltype_supervised) + ggdark::dark_theme_bw() + 
      theme(text=element_text(size=12,face='bold'))
    ,xyplist_lymph[[2]]  + 
      facet_wrap(~celltype_supervised) + ggdark::dark_theme_bw() + 
      theme(text=element_text(size=12,face='bold'))
    ,nrow=2
    ,rel_heights  = c(1.3,1)
  )  + 
  theme(plot.background = element_rect(fill = 'black',color='black')) + 
  cowplot::panel_border(remove=TRUE) 

print(lymphplot)

############################################################################
##1.4. Overlay Specific Transcripts
samplelist <- data.frame(Run_Tissue_name = unique(cell_meta$Run_Tissue_name)) %>%
  mutate(sample = gsub('-','',Run_Tissue_name) %>%
           gsub(' ','',.)) 

txfilelist <- read.csv('~/PTPN2_ST/PTPN2_ST_R/HieraType/txfilelist.csv')

txlist <- data.frame(txfile = txfilelist$x) %>%
  mutate(sample = basename(txfile) %>% 
           gsub('_tx_file.csv.gz','',.)) %>%
  slice(-c(1,2)) %>%
  left_join(.,samplelist)

## Read in transcripts

# Define your file name as a variable
file_name <- txlist[txlist$Run_Tissue_name == meta$Run_Tissue_name %>%unique, "txfile"]

# Construct the shell command using sprintf, # fov is in column 1 and target is in column 9
vals1 <- paste(df$fov[1], df$fov[2], sep='|')
vals9 <- 'ACTA2|S100A4|FAP|PDGFRA' ## CAF markers
vals9 <- 'ITGAM|CD33|CD14'#(for monocytic MDSCs) 

cmd <- sprintf(
  "zcat %s | awk -F',' 'NR==1 || ($1 ~ /^(%s)$/ && $9 ~ /^(%s)$/)'",
  file_name, vals1, vals9
)

# Read the filtered tx data
filtered_tx <- fread(cmd = cmd)

## Set up scale bar
FOV = df$fov[1]
FOV = df$fov[2]

scale_bar <- make_scale_bar_r(x_vals = cell_polygons %>% filter(fov == FOV) %>% pull(x_global_px),
                              y_vals =  cell_polygons %>% filter(fov == FOV) %>% pull(y_global_px))

pltlist <- list()

for (gene in unlist(strsplit(vals9, split = "\\|"))) {
  
  filtered_tx_poly <- filtered_tx %>% filter(fov == FOV, target == gene)
  
  pltlist[[gene]] <-  ggplot(cell_polygons %>% filter(fov == FOV),
           aes(x = x_global_px, y = y_global_px, group = cell)) +
    geom_polygon(fill = "lightgrey", color = "darkgrey", linewidth = 0.3) +
    geom_point(data = filtered_tx_poly, aes(x = x_global_px, y = y_global_px), 
               #Overlay transcript points
               color = "red", size = 0.3) +
    coord_fixed() +
    theme_void()  +
    scale_bar$bg +
    scale_bar$rect +
    scale_bar$label +
    labs(title = gene)
}

cowplot::plot_grid(plotlist = pltlist,nrow=1) 



###1.5 Mute Background Cells

## Add cell type to polygons
plot.df <- cell_polygons %>% filter(fov == FOV) %>% as.data.frame()
meta <- as.data.frame(meta)
row.names(meta) <- meta$cell_ID
plot.df$cell_type <- as.data.frame(meta)[plot.df$cell, "celltype_supervised"] 

## Set alpha by cell type
alpha_vals <- rep(0.1, length(unique(plot.df$cell_type)))
names(alpha_vals) <- c(unique(plot.df$cell_type))
alpha_vals["fibroblast"] <- 1

## Set up scale bar
scale_bar <- make_scale_bar_r(x_vals = plot.df %>% pull(x_global_px),
                              y_vals =  plot.df %>% pull(y_global_px))

## Plot it
ggplot(plot.df,
       aes(x = x_global_px, y = y_global_px, group = cell,
           fill = as.factor(cell_type), alpha = as.factor(cell_type))) +
  geom_polygon(color = "darkgrey", linewidth = 0.3) +
  scale_fill_d3(palette = "category20", na.value = "lightgrey") + # Inspired by colors in the D3 visualization library
  coord_fixed() +
  theme_void() +
  labs(fill = "Cell type", alpha = "Cell type") +
  scale_alpha_manual(values = alpha_vals, na.value = 0.2) + # Adjust opacity by cell type
  scale_bar$bg +
  scale_bar$rect +
  scale_bar$label

##########################################################################################
#Session Two  T subtype Hieratype downstream analysis
##########################################################################################

umap <- read.csv('~/PTPN2_ST/umap_coordinates.csv')

T_sub <- read.csv("~/PTPN2_ST/PTPN2_ST_R/HieraType/HieraTypebindlist_T_subtype.csv") 

T_sub_df <- T_sub %>% mutate(sample = gsub("-",'',sample) %>%
                               gsub(' ','',.))

T_sub_df <- T_sub_df %>% left_join(umap, by = c('cell_ID','sample'))

T_sub_df <- T_sub_df %>% mutate(celltype_supervised_T_only_plot = 
                                  ifelse(celltype_supervised %in% c('cd4t','cd8t'),
                                         celltype_supervised, 'other'))

#2.1 UMAP whole cell type
ggplot(T_sub_df, aes(UMAP1, UMAP2,color=celltype_supervised_T_only_plot)) +
  geom_point(size=.001) +
  theme_classic() +
  scale_color_manual(values = c('red','darkgreen','grey70'))+
  labs(color='')

##2.2 UMAP T subtype

alpha_vals <- rep(1, length(unique(T_sub_df$celltype_Tsub)))
names(alpha_vals) <- c(unique(T_sub_df$celltype_Tsub))
alpha_vals["NA"] <- .1

ggplot(T_sub_df, aes(UMAP1, UMAP2,color = celltype_Tsub, 
                     alpha = as.factor(celltype_Tsub))) +
  geom_point() +
  theme_classic() +
  scale_color_d3(palette = "category20", na.value = "lightgrey") + # Inspired by colors in the D3 visualization library
  labs(color='',alpha='') +
  scale_alpha_manual(values = alpha_vals, na.value = 0.2)

## ## per cell population composition change after PTPN2
# T_sub %>% filter(!is.na(celltype_supervised)) %>%
#   group_by(Response,sample,portion, celltype_supervised) %>% 
#   summarise(counts = n(), .groups = 'drop') %>%
#   group_by(sample,portion,Response) %>%
#   mutate(frequency = counts / sum(counts)) %>%
#   ungroup() %>% ggplot(aes(x = portion, y = frequency)) +
#   geom_line(aes(group = sample)) +
#   scale_color_manual(values = c("#616161","#4285f4","#db4437","#f4b400","#0f9d58","#ab47bc","#00acc1",
#                                 "#ff7043","#9e9d24","#5c6bc0","#f06292","#00796b","#c2185b","#7e57c2",
#                                 "#03a9f4","#8bc34a","#fdd835","#fb8c00","#8d6e63","#9e9e9e","#607d8b"))


##2.3 CD4 T cell subtype compositional changes before and after Tx

T_sub %>% filter(!is.na(celltype_supervised)) %>% 
  group_by(Response,sample,portion, celltype_Tsub) %>% 
  summarise(counts = n(), .groups = 'drop') %>%
  group_by(sample,portion,Response) %>%
  mutate(frequency = counts / sum(counts)) %>%
  ungroup()%>% 
  mutate(Treatment = factor(portion, levels = c('SCR','OTX')))  %>% 
  filter(!is.na(celltype_Tsub)) %>% ## remove non-Tsubtype
  ggplot(aes(x = Treatment,y=frequency)) +
  #geom_boxplot(aes(color = 'Treatment'), alpha = .1)+
  geom_line(aes(group = sample,color = Response),linetype = 1,linewidth=1) + 
  geom_point(size=2,shape = 2) +
  facet_wrap(~ celltype_Tsub+Response,ncol = 15) + 
  theme_bw(base_size = 10,base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0, "cm"), 
        axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
        legend.position = 'right',strip.background = element_rect(fill = 'white')) +
  labs(x = '', y = 'Frequency', fill = '') +
  scale_fill_manual(values = c("#616161","#4285f4","#db4437","#f4b400","#0f9d58","#ab47bc","#00acc1",
                               "#ff7043","#9e9d24","#5c6bc0","#f06292","#00796b","#c2185b","#7e57c2",
                               "#03a9f4","#8bc34a","#fdd835","#fb8c00","#8d6e63","#9e9e9e","#607d8b"))


##2.4 ONLY draft CD4 subtypes
T_sub %>% filter(!is.na(celltype_supervised)) %>% 
  group_by(Response,sample,portion, celltype_Tsub) %>% 
  summarise(counts = n(), .groups = 'drop') %>%
  group_by(sample,portion,Response) %>%
  mutate(frequency = counts / sum(counts)) %>%
  ungroup()%>% 
  mutate(Treatment = factor(portion, levels = c('SCR','OTX')))  %>% 
  filter(!is.na(celltype_Tsub)) %>% ## remove non-Tsubtype
  filter(grepl('cd4_',celltype_Tsub)) %>% 
  ggplot(aes(x = Treatment,y=frequency)) +
  #geom_boxplot(aes(color = 'Treatment'), alpha = .1)+
  geom_line(aes(group = sample,color = Response),linetype = 1,linewidth=1) + 
  geom_point(size=2,shape = 2) +
  facet_wrap(~ celltype_Tsub+Response,ncol = 10) + 
  theme_bw(base_size = 10,base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0, "cm"), 
        axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
        legend.position = 'right',strip.background = element_rect(fill = 'white')) +
  labs(x = '', y = 'Frequency', fill = '') +
  scale_fill_manual(values = c("#616161","#4285f4","#db4437","#f4b400","#0f9d58","#ab47bc","#00acc1",
                               "#ff7043","#9e9d24","#5c6bc0","#f06292","#00796b","#c2185b","#7e57c2",
                               "#03a9f4","#8bc34a","#fdd835","#fb8c00","#8d6e63","#9e9e9e","#607d8b"))

###################
### found imperfection of CD4 and CD8 subtyping results, 
### need to refine the subtyping strategies
####################

T_sub %>% filter(celltype_supervised %in% c('cd4t','cd8t')) -> test

table(test$celltype_Tsub,test$celltype_supervised)

###############################################################
##2.5 draft CD4 Treg xy plot and FOV focused Treg population + transcripts

#### check HieraType on xyplot Treg visulazation
polygonlist <- polygonlist %>% mutate(sample_tsub = gsub('[- ]','',sample)) 
#remove both hyphen and space

met <- T_sub_df %>% filter(Response == 'PD',sample == '2204hnsccrepeatbatch1') 


colorpal <- c("#616161","#4285f4","#db4437","#f4b400","#0f9d58","#ab47bc","#00acc1",
              "#ff7043","#9e9d24","#5c6bc0","#f06292","#00796b","#c2185b","#7e57c2",
              "#03a9f4","#8bc34a","#fdd835","#fb8c00","#8d6e63","#9e9e9e","#607d8b")

names(colorpal) <- sort(unique(met[["celltype_Tsub"]]))

## whole FOV cell type view

xyplist_sup <- 
  lapply(split(met, f=met$portion), function(xx){
    HieraType:::xyplot(cluster_column = "celltype_Tsub", metadata = xx
                       , ptsize = 0.1, cls = colorpal
                       ,plotfirst = c("cd4_treg")
    ) + coord_fixed()
  }) 

xyplot_sup <- 
  cowplot::plot_grid(plotlist = xyplist_sup,nrow = 2) + 
  theme(plot.background = element_rect(fill = 'white',color='white')) + 
  cowplot::panel_border(remove=TRUE) 
print(xyplot_sup)

############################################################################
## 2.6  FOV polygon visulization
## Add cell type to polygons
## Treg visulazation
met <- T_sub_df %>% filter(Response == 'PD',sample == '2204hnsccrepeatbatch1') 

polygonlist <- polygonlist %>% mutate(sample_tsub = gsub('[- ]','',sample)) #remove both hyphen and space
polyfile <- polygonlist[polygonlist$sample == unique(met$Run_Tissue_name),]

cell_polygons <- readRDS(polyfile$polygonfile)

df <- met %>% group_by(tissue_portion,fov,celltype_Tsub) %>%
  summarise(count = n()) %>% filter(celltype_Tsub == 'cd4_treg') %>% 
  arrange(-count) %>%
  group_by(tissue_portion) %>%
  filter(count == max(count))

## fov4 == otx, fov21 == scr
#FOV='4'
FOV = df$fov[1]
FOV = df$fov[2]

plot.df <- cell_polygons %>% filter(fov %in% FOV) %>% as.data.frame()

meta <- as.data.frame(met) %>% filter(fov %in% FOV)

row.names(meta) <- meta$cell_ID
plot.df$cell_type <- as.data.frame(meta)[plot.df$cell, 'celltype_Tsub']

## Set up scale bar
scale_bar <- make_scale_bar_r(x_vals = plot.df %>% pull(x_global_px),
                              y_vals =  plot.df %>% pull(y_global_px))

## Plot it
# Set the desired number of colors
nb.cols <- 13 # Example: for 20 colors
#mycolors <- colorRampPalette(brewer.pal(8, "Set2"))(nb.cols)
mycolors <- viridis::viridis(nb.cols)
mycolors['cd4_treg'] <- '#FF0000'

ggplot(plot.df,
       aes(x = x_global_px, y = y_global_px, 
           group = cell, # Group cells for polygons
           fill = as.factor(cell_type))) + # Polygon fill by cell type
  geom_polygon(color = "black", linewidth = 0.3) +
  scale_fill_manual(values = mycolors) + #Palette inspired by UCSB Genome Browser
  coord_fixed() +
  theme_void() +
  labs(fill = "Cell type") +
  scale_bar$bg +
  scale_bar$rect +
  scale_bar$label

## 2.7. Treg barplot pre and post plots

met %>% group_by(tissue_portion,fov,celltype_Tsub) %>%
  summarise(count = n()) %>% filter(celltype_Tsub == 'cd4_treg') %>% 
  arrange(-count) %>%
  ggplot(aes(x = tissue_portion, y = count,fill=tissue_portion)) +
  geom_boxplot(alpha=.5,color='black') +
  geom_jitter(color='black',shape=21) +
  theme_classic() +
  theme(axis.text.x = element_blank())+
  labs(x='Treg')


## 2.8 FOV specific CD4 treg dark visulization
meta <- met %>% filter(fov %in% df$fov)

xyplist_lymph <- 
  lapply(split(meta, f = meta$portion), function(xx){
    HieraType:::xyplot(cluster_column = "celltype_comprehensive", metadata = xx
                       , ptsize = 0.05, cls = colorpal
                       ,clusters = c("cd4_treg",'epithelial')
    ) + coord_fixed()
  })

lymphplot <- 
  cowplot::plot_grid(
    xyplist_lymph[[1]]  + 
      facet_wrap(~celltype_comprehensive) + ggdark::dark_theme_bw() + 
      theme(text=element_text(size=12,face='bold'))
    ,xyplist_lymph[[2]]  + 
      facet_wrap(~celltype_comprehensive) + ggdark::dark_theme_bw() + 
      theme(text=element_text(size=12,face='bold'))
    ,nrow=2
    ,rel_heights  = c(1.3,1)
  )  + 
  theme(plot.background = element_rect(fill = 'black',color='black')) + 
  cowplot::panel_border(remove=TRUE) 

print(lymphplot)

##2.9 DE analysis of Treg pre and post PTPN2i
library(Seurat)

seu <- readRDS('/projects/grc/io/datasets/ptpn2i/GTG-2243-PTPN2/GTG2243PTPN2Batch_1_Repeat_22_07_2025/2204-Repeat/seuratObject_2204.hnscc.repeat.batch1.RDS')

## add Tsubtype metadata

rownames(met) <- met$cell_ID

seu <- AddMetaData(seu, metadata = met)

seu$celltype_Tsub %>%table()

seu_treg <- subset(seu, celltype_Tsub == 'cd4_treg')

Idents(seu_treg) <- seu_treg$portion

treg.de <- FindMarkers(seu_treg, ident.1 = "OTX", ident.2 = "SCR", verbose = FALSE)

##2.10 Volcano plot
library(ggrepel)
plotABVRES <- treg.de
plotABVRES$SYMBOL <- rownames(treg.de)
plotABVRES$adj.P.Val_l10 <- -log10(plotABVRES$p_val_adj)
plotABVRES$sig_flag <- "NS"
plotABVRES$sig_flag[ which(abs(plotABVRES$avg_log2FC) > 0.5 & 
                             plotABVRES$p_val_adj < 0.2) ] <- "Suggestive"
plotABVRES$sig_flag[ which(abs(plotABVRES$avg_log2FC) > 1 & 
                             plotABVRES$p_val_adj < 0.05) ] <- "Significant"

#topGENES
topABVRES <- plotABVRES[ 1:300, ]

##Plotting
ggplot(data = plotABVRES, aes(x = avg_log2FC, y = adj.P.Val_l10, fill = sig_flag)) +
  geom_point(size = 1.75, shape = 21) + 
  scale_y_continuous("-log10 (Adjusted P value)") +
  scale_x_continuous("Log fold-change") + 
  scale_fill_manual("Significance", values = c("NS" = "grey40", 
                                               "Suggestive" = "red",
                                               "Significant" = "purple")) + 
  geom_text_repel(data = topABVRES, aes(label = SYMBOL), size = 3, max.overlaps = 20) +
  geom_hline(yintercept = 1.3, linetype = 2) +
  geom_vline(xintercept = -1, linetype = 2) +
  geom_vline(xintercept = 1, linetype = 2) +
  guides(fill = guide_legend(override.aes = list(size = 7))) +
  theme_bw(base_size = 20) +
  theme(legend.position = "none")

write.csv(plotABVRES,'~/PTPN2_ST/PTPN2_ST_R/HieraType/DEG_2204_Treg_OTX_CTL.csv',row.names = F)

## 2.11 GSEA analysis of Treg DE results
library(clusterProfiler)

final.tbl <- fread('~/PTPN2_ST/PTPN2_ST_R/HieraType/DEG_2204_Treg_OTX_CTL.csv')

##convert symbol to entrezid
gene.df <- bitr(final.tbl$SYMBOL, fromType = "SYMBOL",
                toType = c("ENSEMBL", "ENTREZID"),
                OrgDb = org.Hs.eg.db) %>%
  filter(!duplicated(SYMBOL)) #remove duplicated rows

## combine gene.df back to the DEG list for downstream

geneList_df <- final.tbl %>% left_join(.,gene.df,by='SYMBOL') %>%
  filter(!is.na(ENTREZID)) %>% # REMOVE any empty ENTREZID
  arrange(-avg_log2FC)

geneList <- geneList_df$avg_log2FC

names(geneList) <- geneList_df$ENTREZID

######################## 
library(msigdbr)
library(org.Hs.eg.db)

### GOBP
m_t2g <- msigdbr(species = "Homo sapiens", category = "C5",subcategory = 'GO:BP') %>%
  dplyr::select(gs_name, entrez_gene,ensembl_gene,gene_symbol)

head(m_t2g)

#MSigDb over-presentaton analysis GOBO
gene <- names(geneList)[geneList>=2]

#MSigDb over-presentaton analysis, input must be ENTREZID
em <- enricher(gene, TERM2GENE=m_t2g)
em_df <- data.frame(em)

ego <- enrichGO(gene          = gene,
                universe      = names(geneList),
                OrgDb         = org.Hs.eg.db,
                ont           = "BP",
                pAdjustMethod = "BH",
                pvalueCutoff  = 0.01,
                qvalueCutoff  = 0.05,
                readable      = TRUE)
head(ego)

#2 MSigDb gene set enrichment analysis GOBP -- no significant enriched 
# em2 <- GSEA(geneList, TERM2GENE = m_t2g)
# em2_df <- data.frame(em2)
# 
# ego3 <- gseGO(geneList     = geneList,
#               OrgDb        = org.Hs.eg.db,
#               ont          = "BP",
#               minGSSize    = 100,
#               maxGSSize    = 500,
#               pvalueCutoff = 0.05,
#               verbose      = FALSE)
# 
# head(ego3)

##ploting

dotplot(ego, showCategory=15) + ggtitle("Enriched pathways in Tregs\n after PTPN2i treatment")


############################################################################
##Session 3 Macrophage Hierratype downstream analysis
##########################################################################################

umap <- read.csv('~/PTPN2_ST/umap_coordinates.csv')

T_sub <- read.csv("~/PTPN2_ST/PTPN2_ST_R/HieraType/HieraTypebindlist_T_subtype.csv") 

T_sub_df <- T_sub %>% mutate(sample = gsub("-",'',sample) %>%
                               gsub(' ','',.))

T_sub_df <- T_sub_df %>% left_join(umap, by = c('cell_ID','sample'))

Macrophage_df <- T_sub_df %>% mutate(celltype_supervised_Macrophage_only_plot = 
                                  ifelse(celltype_supervised == 'macrophage',
                                         celltype_supervised, 'other')) %>% 
  filter(!is.na(celltype_supervised))

#3.1 Macrophage content proportion before and on treatment by response groups

Macrophage_df %>% 
  group_by(tissue_portion, celltype_supervised_Macrophage_only_plot,Response) %>% 
  summarise(counts = n(), .groups = 'drop') %>%
  group_by(tissue_portion,Response) %>%
  mutate(frequency = counts / sum(counts)) %>%
  ungroup() %>% 
  ggplot(aes(x = tissue_portion, y = frequency, 
             fill = celltype_supervised_Macrophage_only_plot)) +
  geom_bar(stat = 'identity', position = 'fill') +
  theme_classic()+
  labs(title = 'Relative Macrophage content by Response group',
       x = '',
       y = 'Proportion',
       fill='') +
  theme(axis.text.x = element_text(angle=90,size=7)) +
  scale_fill_manual(values = c("#ff7043","#9e9e9e","#607d8b")) +
  facet_wrap(~Response,nrow=1,scale='free_x')


#3.2 UMAP of macrophage 
ggplot(Macrophage_df, aes(UMAP1, UMAP2,color=celltype_supervised_Macrophage_only_plot)) +
  geom_point(size=.001) +
  theme_classic() +
  scale_color_manual(values = c('darkgreen','grey70'))+
  labs(color='')

##3.3 UMAP of re-clustering of macrohpage cells -- do with Python

umap_macrophage <- read.csv('~/PTPN2_ST/macrophage_umap_coordinates.csv')

T_sub <- read.csv("~/PTPN2_ST/PTPN2_ST_R/HieraType/HieraTypebindlist_T_subtype.csv") 

T_sub_df <- T_sub %>% mutate(sample = gsub("-",'',sample) %>%
                               gsub(' ','',.))# %>% 
  #dplyr::select(cell_ID, sample, Response,celltype_supervised,tissue_portion)

T_sub_df <- T_sub_df %>% left_join(umap_macrophage,by = c('cell_ID','tissue_portion'))

Macrophage_df <- T_sub_df %>% filter(celltype_supervised == 'macrophage')

Macrophage_df %>% mutate(recluster_leiden = as.character(recluster_leiden)) %>% 
  group_by(tissue_portion,recluster_leiden ,Response) %>% 
  summarise(counts = n(), .groups = 'drop') %>%
  group_by(tissue_portion,Response) %>%
  mutate(frequency = counts / sum(counts)) %>%
  ungroup() %>% 
  ggplot(aes(x = tissue_portion, y = frequency, 
             fill = recluster_leiden)) +
  geom_bar(stat = 'identity', position = 'fill') +
  theme_classic()+
  labs(title = 'Macrophage content by Response group',
       x = '',
       y = 'Proportion',
       fill='') +
  theme(axis.text.x = element_text(angle=90,size=7)) +
  scale_fill_manual(values = c("#616161","#4285f4","#db4437","#f4b400","#0f9d58","#ab47bc","#00acc1",
                               "#ff7043","#9e9d24","#5c6bc0","#f06292","#00796b","#c2185b","#7e57c2",
                               "#03a9f4","#8bc34a","#fdd835","#fb8c00","#8d6e63","#9e9e9e","#607d8b")) +
  facet_wrap(~Response,nrow=1,scale='free_x')

## 3.4 M1 and M2 macrophage subtyping 
##marker_genes = {
#"M1": ["CD80", "CD86",'CD40','ITGAX',"NOS2","TNF","IL1B","IL6"],
#"M2": ["CD163",'FCGR3A', "MRC1", "CD40",'HLA-DRA',"ARG1","IL10","TGFB1"],
#"macrophage": ["CD163","CD68","MARCO","CSF1R"],
#}

## macrophage cluster 0,2,3 are M2, the rest is M1

Macrophage_df$Macrophage_subtypes <- ifelse(Macrophage_df$recluster_leiden %in% c('0','2','3'),
                                            'M2', 'M1')

Macrophage_df %>% group_by(tissue_portion,Macrophage_subtypes ,Response) %>% 
  summarise(counts = n(), .groups = 'drop') %>%
  group_by(tissue_portion,Response) %>%
  mutate(frequency = counts / sum(counts)) %>%
  ungroup() %>% 
  ggplot(aes(x = tissue_portion, y = frequency, 
             fill = Macrophage_subtypes)) +
  geom_bar(stat = 'identity', position = 'fill') +
  theme_classic()+
  labs(title = 'Macrophage subtypes by Response group',
       x = '',
       y = 'Proportion',
       fill='') +
  theme(axis.text.x = element_text(angle=90,size=7)) +
  scale_fill_manual(values = c("#00acc1", "#ff7043","#9e9d24","#5c6bc0","#f06292","#00796b","#c2185b","#7e57c2",
                               "#03a9f4","#8bc34a","#fdd835","#fb8c00","#8d6e63","#9e9e9e","#607d8b")) +
  facet_wrap(~Response,nrow=1,scale='free_x')

#######
##3.5 draft Macrophage xy plot and FOV focused on population + transcripts

#### check HieraType on xyplot macrophage visulazation #remove both hyphen and space
polygonlist <- polygonlist %>% mutate(sample_tsub = gsub('[- ]','',sample)) 

met <- T_sub_df %>% filter(Response == 'SD',sample == '300121116SLIDE') 


colorpal <- c("#616161","#4285f4","#db4437","#f4b400","#0f9d58","#ab47bc","#00acc1",
              "#ff7043","#9e9d24","#5c6bc0","#f06292","#00796b","#c2185b","#7e57c2",
              "#03a9f4","#8bc34a","#fdd835","#fb8c00","#8d6e63","#9e9e9e","#607d8b")

names(colorpal) <- sort(unique(met[["celltype_supervised"]]))

## whole FOV cell type view

xyplist_sup <- 
  lapply(split(met, f=met$portion), function(xx){
    HieraType:::xyplot(cluster_column = "celltype_supervised", metadata = xx
                       , ptsize = 0.1, cls = colorpal
                       ,plotfirst = c("macrophage")
    ) + coord_fixed()
  }) 

xyplot_sup <- 
  cowplot::plot_grid(plotlist = xyplist_sup,nrow = 2) + 
  theme(plot.background = element_rect(fill = 'white',color='white')) + 
  cowplot::panel_border(remove=TRUE) 
print(xyplot_sup)

#######
## 3.6  FOV polygon visulization. Add cell type to polygons

met <- Macrophage_df %>% filter(Response == 'SD',sample == '300121116SLIDE') 

polygonlist <- polygonlist %>% mutate(sample_tsub = gsub('[- ]','',sample)) #remove both hyphen and space
polyfile <- polygonlist[polygonlist$sample == unique(met$Run_Tissue_name),]

cell_polygons <- readRDS(polyfile$polygonfile)

df <- met %>% group_by(tissue_portion,fov,Macrophage_subtypes) %>%
  summarise(count = n()) %>% filter(Macrophage_subtypes == 'M2') %>% 
  arrange(-count) %>%
  group_by(tissue_portion) %>%
  filter(count == max(count))

#FOV
FOV = df$fov[1]
FOV = df$fov[2]

plot.df <- cell_polygons %>% filter(fov %in% FOV) %>% as.data.frame()

meta <- as.data.frame(met) %>% filter(fov %in% FOV)

row.names(meta) <- meta$cell_ID
plot.df$cell_type <- as.data.frame(meta)[plot.df$cell, 'Macrophage_subtypes']

## Set up scale bar
scale_bar <- make_scale_bar_r(x_vals = plot.df %>% pull(x_global_px),
                              y_vals =  plot.df %>% pull(y_global_px))

## Plot it
# Set the desired number of colors
nb.cols <- 13 # Example: for 20 colors
#mycolors <- colorRampPalette(brewer.pal(8, "Set2"))(nb.cols)
mycolors <- viridis::viridis(nb.cols)
mycolors['M2'] <- '#ff7043'
mycolors['M1'] <- '#8bc34a'

ggplot(plot.df,
       aes(x = x_global_px, y = y_global_px, 
           group = cell, # Group cells for polygons
           fill = as.factor(cell_type))) + # Polygon fill by cell type
  geom_polygon(color = "black", linewidth = 0.3) +
  scale_fill_manual(values = mycolors) + #Palette inspired by UCSB Genome Browser
  coord_fixed() +
  theme_void() +
  labs(fill = "macrophage") +
  scale_bar$bg +
  scale_bar$rect +
  scale_bar$label

########
## 3.7. macrophage M2/M1 ratio barplot pre and post plots in each sample 
library(tidyr)

Macrophage_df %>%
  group_by(tissue_portion, fov, Macrophage_subtypes,Response,,portion) %>%
  summarise(count = n()) %>%
  pivot_wider(names_from = Macrophage_subtypes, 
              values_from = count,values_fill = 0) %>%
  mutate(ratio_M2_M1 = ifelse(M1 == 0, NA, M2/M1)) %>%
  ggplot(aes(x = tissue_portion, y = ratio_M2_M1,fill=portion)) +
  geom_boxplot(alpha=.5,color='black') +
  geom_jitter(color='black',shape=21) +
  theme_classic() +
  theme(axis.text.x = element_text(angle=90,size=7))+
  labs(title ='Macrophage',x='', y='M2/M1 Ratio',fill='') +
  facet_wrap(~Response,nrow=2,scale = 'free_x')

#######
## 3.8 FOV specific Macrophage dark visulization

meta <- T_sub_df  %>% filter(Response == 'SD',sample == '300121116SLIDE') %>% 
  filter(fov %in% df$fov)

meta <- meta %>% left_join(Macrophage_df %>% 
                             dplyr::select(tissue_portion,cell_ID,Macrophage_subtypes), 
                           by = c("tissue_portion","cell_ID"))

meta <- meta %>%
  mutate(celltype_comprehensive_phage = ifelse(celltype_comprehensive == 'macrophage',
                                               Macrophage_subtypes, celltype_comprehensive))


colorpal <- c("#4285f4","#db4437","#f4b400","#0f9d58","#ab47bc","#00acc1","grey","red","green","blue",
              "#ff7043","#9e9d24","#5c6bc0","#f06292","#00796b","#c2185b","#7e57c2",
              "#03a9f4","#8bc34a","#fdd835","#fb8c00","#8d6e63","#9e9e9e","#607d8b")

names(colorpal) <- sort(unique(meta[["celltype_comprehensive_phage"]]))

xyplist_lymph <- 
  lapply(split(meta, f = meta$portion), function(xx){
    HieraType:::xyplot(cluster_column = "celltype_comprehensive_phage", metadata = xx
                       , ptsize = 0.05, cls = colorpal
                       ,clusters = c("M2",'epithelial')
    ) + coord_fixed()
  })

lymphplot <- 
  cowplot::plot_grid(
    xyplist_lymph[[1]]  + 
      facet_wrap(~celltype_comprehensive_phage) + ggdark::dark_theme_bw() + 
      theme(text=element_text(size=12,face='bold'))+
      labs(color='')
    ,xyplist_lymph[[2]]  + 
      facet_wrap(~celltype_comprehensive_phage) + ggdark::dark_theme_bw() + 
      theme(text=element_text(size=12,face='bold')) +
      labs(color='')
    ,nrow=2
    ,rel_heights  = c(1.3,1)
  )  + 
  theme(plot.background = element_rect(fill = 'black',color='black')) + 
  cowplot::panel_border(remove=TRUE) 

print(lymphplot)


############################################################################
## Session 4. CD8 focused analysis

##4.1 ONLY draft CD8 subtypes
T_sub %>% filter(!is.na(celltype_supervised)) %>% 
  group_by(Response,sample,portion, celltype_Tsub) %>% 
  summarise(counts = n(), .groups = 'drop') %>%
  group_by(sample,portion,Response) %>%
  mutate(frequency = counts / sum(counts)) %>%
  ungroup()%>% 
  mutate(Treatment = factor(portion, levels = c('SCR','OTX')))  %>% 
  filter(!is.na(celltype_Tsub)) %>% ## remove non-Tsubtype
  filter(grepl('cd8_',celltype_Tsub)) %>% 
  ggplot(aes(x = Treatment,y=frequency)) +
  #geom_boxplot(aes(color = 'Treatment'), alpha = .1)+
  geom_line(aes(group = sample,color = Response),linetype = 1,linewidth=1) + 
  geom_point(size=2,shape = 2,color='black') +
  facet_wrap(~ celltype_Tsub+Response,ncol = 10) + 
  theme_bw(base_size = 10,base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0, "cm"), 
        axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
        legend.position = 'right',strip.background = element_rect(fill = 'white')) +
  labs(x = '', y = 'Frequency', fill = '') +
  scale_fill_manual(values = c("#616161","#4285f4","#db4437","#f4b400","#0f9d58","#ab47bc","#00acc1",
                               "#ff7043","#9e9d24","#5c6bc0","#f06292","#00796b","#c2185b","#7e57c2",
                               "#03a9f4","#8bc34a","#fdd835","#fb8c00","#8d6e63","#9e9e9e","#607d8b"))



########
## 4.2. CD8 cytotoxic and exhausted ratio barplot pre and post plots in each sample 
library(tidyr)

T_sub %>% filter(!is.na(celltype_comprehensive)) %>%
  group_by(tissue_portion, fov, celltype_comprehensive,Response,portion) %>%
  summarise(count = n()) %>%
  pivot_wider(names_from = celltype_comprehensive, 
              values_from = count,values_fill = 0) %>%
  mutate(ratio_CD8exh_CD8toxic = ifelse(cd8_cytotoxic == 0, NA, 
                                        cd8_exhausted/cd8_cytotoxic)) %>%
  ggplot(aes(x = tissue_portion, y = ratio_CD8exh_CD8toxic,fill=portion)) +
  geom_boxplot(alpha=.5,color='black') +
  geom_jitter(color='black',shape=21) +
  theme_classic() +
  theme(axis.text.x = element_text(angle=90,size=7))+
  labs(title ='CD8 Exhaustion vs Cytotoxicity ratio',x='', y='Exhausted/Cytotoxic CD8 Ratio',fill='') +
  facet_wrap(~Response,nrow=1,scale = 'free_x')

### 4.3 CD8 exhausted cell position in PD samples 2203,2204
#2203TONSILREPEAT; 2204hnsccrepeatbatch1
met <- T_sub_df %>% filter(Response == 'PD',sample == '2203TONSILREPEAT') 
met <- T_sub_df %>% filter(Response == 'PD',sample == '2204hnsccrepeatbatch1') 

polygonlist <- polygonlist %>% mutate(sample_tsub = gsub('[- ]','',sample)) #remove both hyphen and space
polyfile <- polygonlist[polygonlist$sample == unique(met$Run_Tissue_name),]

cell_polygons <- readRDS(polyfile$polygonfile)

df <- met %>% group_by(tissue_portion,fov,celltype_Tsub) %>%
  summarise(count = n()) %>% filter(celltype_Tsub %in% c(#"cd8_cytotoxic",
                                                         "cd8_exhausted")) %>% 
  arrange(-count) %>%
  group_by(tissue_portion) %>%
  filter(count == max(count))

#FOV
FOV = df$fov[1]
FOV = df$fov[2]

plot.df <- cell_polygons %>% filter(fov %in% FOV) %>% as.data.frame()

meta <- as.data.frame(met) %>% filter(fov %in% FOV)

row.names(meta) <- meta$cell_ID
plot.df$cell_type <- as.data.frame(meta)[plot.df$cell, 'celltype_Tsub']

## Set up scale bar
scale_bar <- make_scale_bar_r(x_vals = plot.df %>% pull(x_global_px),
                              y_vals =  plot.df %>% pull(y_global_px))

## Plot it
# Set the desired number of colors
nb.cols <- 13 # Example: for 20 colors
#mycolors <- colorRampPalette(brewer.pal(8, "Set2"))(nb.cols)
mycolors <- viridis::viridis(nb.cols)
mycolors['cd8_exhausted'] <- '#00acc1'
mycolors['cd8_cytotoxic'] <- '#db4437'

ggplot(plot.df,
       aes(x = x_global_px, y = y_global_px, 
           group = cell, # Group cells for polygons
           fill = as.factor(cell_type))) + # Polygon fill by cell type
  geom_polygon(color = "black", linewidth = 0.3) +
  scale_fill_manual(values = mycolors) + #Palette inspired by UCSB Genome Browser
  coord_fixed() +
  theme_void() +
  labs(fill = "CD8 cells") +
  scale_bar$bg +
  scale_bar$rect +
  scale_bar$label

## 4.4 Spatial visualization of per FOV metrics of ratio

# Extract fov metric columns to plot
#2203TONSILREPEAT; 2204hnsccrepeatbatch1

tissueportiondf <- T_sub_df %>% group_by(Run_Tissue_name) %>% 
  summarise(count = n()) %>% filter(!is.na(Run_Tissue_name))

pltlist <- list()

for (i in seq_along(tissueportiondf$Run_Tissue_name)) {
  
  tisportion = tissueportiondf$Run_Tissue_name[i]
  
  met <- T_sub_df %>% filter(Run_Tissue_name == tisportion) 
  
  qc <- met %>% #filter(!is.na(celltype_comprehensive)) %>% 
    group_by(tissue_portion, fov, celltype_comprehensive,Response,portion) %>%
    summarise(count = n()) %>%
    pivot_wider(names_from = celltype_comprehensive, 
                values_from = count,
                names_expand = TRUE,
                names_sort = TRUE) 
  
  if (!'cd8_exhausted' %in% colnames(qc)) {
    qc[['cd8_exhausted']] <- 0
    
    qc <- qc %>% mutate(ratio_CD8exh_CD8toxic = 0)
  
  } else {
    
    qc <- qc %>% mutate(ratio_CD8exh_CD8toxic = ifelse(cd8_cytotoxic == 0, NA, 
                                                       cd8_exhausted/cd8_cytotoxic))
  }
   
  fov_metrics <- grep("ratio", colnames(qc), value = TRUE)
  
  # Add xy positions for each FOV to qc dataframe
  
  fovlist <- fov_poslist %>% mutate(sample_tsub = gsub('[- ]','',sample)) #remove both hyphen and space
  
  fovlist <- fovlist[fovlist$sample == unique(met$Run_Tissue_name %>% gsub('[- ]','',.)),]
  
  fov_positions <- read.csv(fovlist$fovpos)
  
  row.names(fov_positions) <- as.character(fov_positions$FOV)
  qc$x_global_px <- fov_positions[as.character(qc$fov), "x_global_px"]
  qc$y_global_px <- fov_positions[as.character(qc$fov), "y_global_px"]
  
  ## Set up scale bar for all plots
  scale_bar <- make_scale_bar_r(x_vals = qc %>% pull(x_global_px),
                                y_vals =  qc %>% pull(y_global_px))
  
  ## Plot each per FOV metric in space
  pltlist[[i]] <- ggplot(qc, 
         aes(x = x_global_px, y = y_global_px, 
             fill = get(fov_metric))) +
    geom_tile(width = 4254/200, height = 4254/200) + #CosMx FOVs are 4254x4254 pixels
    scale_fill_gradient(low = "blue", high = "magenta") +
    geom_label(aes(label = fov)) + # Label each FOV in space
    theme_void() +
    labs(title = paste(unique(met$Response), tisportion, sep=' '),
         fill = gsub("_", "/", fov_metric) %>%
           gsub('ratio/','',.)) +
    theme(axis.title.x = element_blank(),
          axis.title.y = element_blank()) +
    coord_fixed() +
    scale_bar$bg +
    scale_bar$rect +
    scale_bar$label +
    facet_wrap(~portion,ncol=1)
 
}

gridExtra::grid.arrange(grobs = pltlist[1:2], ncol=2)
gridExtra::grid.arrange(grobs = pltlist[3:4], ncol=2)
gridExtra::grid.arrange(grobs = pltlist[5], ncol=1)
gridExtra::grid.arrange(grobs = pltlist[6:7], ncol=2)
gridExtra::grid.arrange(grobs = pltlist[10:11], ncol=2)

############################################################################
## Session 5. tumor subclone focused analysis
library(Seurat)

expr <- read.csv('~/PTPN2_ST/integrated_data/RCC_expression_matrix.csv', row.names=1)
meta <- read.csv('cell_metadata.csv', row.names=1)

seurat_obj <- CreateSeuratObject(counts = expr, meta.data = meta)




############################################################################
## Session 6. nearest neighbor focused analysis

devtools::install_github("Nanostring-Biostats/CosMx-Analysis-Scratch-Space@Main", subdir = "_code/cellular-neighborhoods")

library(CellularNeighborhoods)

T_sub_df <- T_sub_df %>% filter(!is.na(Run_Tissue_name))


neighborhood <- data.frame()

for ( i in unique(T_sub_df$Run_Tissue_name) ) {
  
  meta <- T_sub_df %>% filter(Run_Tissue_name == i)
  
  celltype <- meta$celltype_comprehensive
  
  xy <- meta %>% dplyr::select(x_FOV_px, y_FOV_px, cell_ID) %>% 
    tibble::column_to_rownames('cell_ID')
  
  ##6.1 Defining a cell’s neighbors: We prefer the K-nearest neighbors approach, mainly because radius-based neighborhoods tend to vary widely in the number of cells they contain, and neighborhoods of very few cells are statistically unstable.
  
  # define neighbors using a K-nearest approach:
  neighbors.nearest50 <- nearestNeighborGraph(x = xy[, 1], y = xy[, 2], N = 50)
  # the output is a sparse matrix of cells * cells:
  str(neighbors.nearest50)
  # compare the number of neighbors found by each approach:
  summary(Matrix::rowSums(neighbors.nearest50))
  
  # #6.1.1 Subsampling neighbors to minimize spatial auto-correlation: get a neighborhood matrix with random subsetting:
  # subsetted_neighbors <- subsampleNeighborsByRow(neighbors = neighbors.nearest50, p = 0.5)
  # summary(Matrix::rowSums(subsetted_neighbors))
  # 
  #6.2 Summarizing a cell’s neighbors to define its spatial context
  
  # mean cell type abundances:
  spatialcontext_celltypes <- neighbor_tabulate(celltype, neighbors.nearest50)
  
  # cluster the top PCs:
  temp <- mclust::Mclust(spatialcontext_celltypes, 
                         G = 6, # 6 clusters
                         #modelNames = c("EEI")
  )
  
  spatialclust <- temp$classification
  
  # plot the results:
  cols <- c("#616161","#4285f4","#db4437","#f4b400","#0f9d58","#ab47bc","#00acc1",
            "#ff7043","#9e9d24","#5c6bc0","#f06292","#00796b","#c2185b","#7e57c2",
            "#03a9f4","#8bc34a","#fdd835","#fb8c00","#8d6e63","#9e9e9e","#607d8b")
  # plot:
  sub = TRUE
  plot(xy[sub, ], pch = 16, cex = 1, 
       asp = 1, xlab = "", ylab = "",
       col = cols[as.numeric(as.factor(spatialclust[sub]))])
  
  # add spatial cluster to metadata
  
  meta$spatialcluster <- spatialclust
  
  neighborhood <- rbind(neighborhood, meta)
  
} 

write.csv(neighborhood, '~/PTPN2_ST/PTPN2_ST_R/HieraType/spatial_cluster.csv',row.names = F)

meta$Run_Tissue_name

# plot the results:
cols <- c("#616161","#4285f4","#db4437","#f4b400","#0f9d58","#ab47bc","#00acc1",
          "#ff7043","#9e9d24","#5c6bc0","#f06292","#00796b","#c2185b","#7e57c2",
          "#03a9f4","#8bc34a","#fdd835","#fb8c00","#8d6e63","#9e9e9e","#607d8b")
# plot:
plot(xy, pch = 16, cex = 1, 
     asp = 1, xlab = "", ylab = "",
     col = cols[as.numeric(as.factor(spatialclust))])



# data(cosmx_kidney)
# annot <- cosmx_kidney$annot
# rownames(annot) <- annot$cell_ID
# counts <- cosmx_kidney$counts
# celltype <- as.factor(cosmx_kidney$annot$celltype)
# xy <- cosmx_kidney$xy
# 
# ##6.1 Defining a cell’s neighbors: We prefer the K-nearest neighbors approach, mainly because radius-based neighborhoods tend to vary widely in the number of cells they contain, and neighborhoods of very few cells are statistically unstable.
# 
# # define neighbors using a K-nearest approach:
# neighbors.nearest50 <- nearestNeighborGraph(x = xy[, 1], y = xy[, 2], N = 50)
# # the output is a sparse matrix of cells * cells:
# str(neighbors.nearest50)
# # compare the number of neighbors found by each approach:
# summary(Matrix::rowSums(neighbors.nearest50))
# 
# #6.1.1 Subsampling neighbors to minimize spatial auto-correlation: get a neighborhood matrix with random subsetting:
# subsetted_neighbors <- subsampleNeighborsByRow(neighbors = neighbors.nearest50, p = 0.5)
# summary(Matrix::rowSums(subsetted_neighbors))
# 
# #6.2 Summarizing a cell’s neighbors to define its spatial context
# 
# # mean neighborhood expression:
# spatialcontext_expression <- get_neighborhood_expression(counts, neighbors.nearest50)
# 
# # cluster the top PCs:
# temp <- mclust::Mclust(spatialcontext_expression, 
#                        G = 6, # 6 clusters
#                        modelNames = c("EEI"))
# 
# spatialclust <- temp$classification
# 
# # plot the results:
# cols <- c("#616161","#4285f4","#db4437","#f4b400","#0f9d58","#ab47bc","#00acc1",
#           "#ff7043","#9e9d24","#5c6bc0","#f06292","#00796b","#c2185b","#7e57c2",
#           "#03a9f4","#8bc34a","#fdd835","#fb8c00","#8d6e63","#9e9e9e","#607d8b")
# # plot:
# sub = TRUE
# plot(xy[sub, ], pch = 16, cex = 1, 
#      asp = 1, xlab = "", ylab = "",
#      col = cols[as.numeric(as.factor(spatialclust[sub]))])
# 
# annot$spatialcluster <- temp$classification
# 
# table(annot$celltype,annot$spatialcluster)
# 
# # mean cell type abundances:
# spatialcontext_celltypes <- neighbor_tabulate(annot$celltype, neighbors.nearest50)
# 
# # cluster the top PCs:
# temp <- mclust::Mclust(spatialcontext_celltypes, 
#                        G = 6, # 6 clusters
#                        #modelNames = c("EEI")
#                        )
# 
# spatialclust <- temp$classification
# 
# # plot the results:
# cols <- c("#616161","#4285f4","#db4437","#f4b400","#0f9d58","#ab47bc","#00acc1",
#           "#ff7043","#9e9d24","#5c6bc0","#f06292","#00796b","#c2185b","#7e57c2",
#           "#03a9f4","#8bc34a","#fdd835","#fb8c00","#8d6e63","#9e9e9e","#607d8b")
# # plot:
# sub = TRUE
# plot(xy[sub, ], pch = 16, cex = 1, 
#      asp = 1, xlab = "", ylab = "",
#      col = cols[as.numeric(as.factor(spatialclust[sub]))])
# 
