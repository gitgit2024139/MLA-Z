library(data.table)
library(Matrix)
library(dplyr)
library(stringr)
library(tidyr)
library(ggplot2)
library(tibble)
library(Seurat)


setwd("~/PTPN2_ST/PTPN2_ST_R/")

outdir <- paste('~/PTPN2_ST/PTPN2_ST_R/Spatial_context_and_InsituCor/downstream',
                '164002', sep='/')

dir.create(outdir,recursive = TRUE)

###1. cell annotation analysis in 164002
## FOV 1:14 == SCR; 15: == OTX

meta <- readRDS('~/PTPN2_ST/PTPN2_ST_R/data_processing_CosMxref/160042cRccprocessed_data_metadata.RDS') %>% 
  mutate(Treatment = ifelse(fov < 15, "SCR", "OTX"))

annotation <- readRDS('~/PTPN2_ST/PTPN2_ST_R/data_processing_CosMxref/160042cRccinsitutype_initial_results.RDS')

ct <- data.frame(cell_annotation = annotation$clust) %>% tibble::rownames_to_column("cell_id")

left_join(ct, meta) %>% group_by(cell_annotation, Treatment) %>% 
  summarise(counts = n()) %>% group_by(Treatment) %>% 
  mutate(frequency = counts / sum(counts)) %>% 
  mutate(Treatment = factor(Treatment, levels = c('SCR','OTX'))) %>% 
  ggplot(aes(x = reorder(cell_annotation,-frequency),y=frequency,fill = cell_annotation)) +
  geom_bar(stat = 'identity', position = 'dodge') +
  geom_text(aes(label = round(frequency, 3)), angle = 90,vjust = 0, size = 2.5)+
  theme_bw() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
        panel.grid = element_blank()) +
  xlab('') + ylab('Frequency') +
  guides(fill = guide_legend(keywidth = 0.5, 
                             keyheight = 0.5, 
                             override.aes = list(size = 2),
                             ncol = 1)) +
  facet_wrap(~Treatment,ncol=1)

## per fov immune infiltration with different treatment

left_join(ct, meta) %>% group_by(cell_annotation, Treatment,fov) %>% 
  summarise(counts = n()) %>% group_by(Treatment,fov) %>% 
  mutate(frequency = counts / sum(counts)) %>% 
  mutate(Treatment = factor(Treatment, levels = c('SCR','OTX'))) %>% 
  ggplot(aes(x = reorder(cell_annotation,-frequency),y=frequency,fill = cell_annotation)) +
  geom_bar(stat = 'identity', position = 'dodge') +
  geom_text(aes(label = round(frequency, 3)), angle = 90,vjust = 0.5,hjust = -.15, size = 2.5)+
  theme_bw() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
        panel.grid = element_blank()) +
  xlab('') + ylab('Frequency') +
  guides(fill = guide_legend(keywidth = 0.5, 
                             keyheight = 0.5, 
                             override.aes = list(size = 2),
                             ncol = 1)) +
  facet_wrap(~Treatment+fov,ncol=5) +
  ylim(c(0,.8))

##1.3 zoom in on one tumor-rich region using the Crop() function. 
#fov 5 and fov 18
# Positions in space, here shown for one image / slide
seurat_object@images$X16004.2.cRcc$centroids@coords[1:10,]

# Plot by using the 'group.by' option
## Change the default boundaries for the first slide
DefaultBoundary(seurat_object[['X16004.2.cRcc']]) <- "segmentation"


p1 <- ImageDimPlot(seurat_object,
             fov = Images(seurat_object)[1],
             border.color = "black",
             group.by = "cell_annotation",
             cols = "glasbey",# Option to use a different palette for cell colors
             coord.fixed = FALSE,
             #shuffle.cols = TRUE,
             cells = row.names(seurat_object@meta.data)
             [which(seurat_object@meta.data$fov == 5)]) +
  ggtitle("FOV 5")

p2 <- ImageDimPlot(seurat_object,
                   fov = Images(seurat_object)[1],
                   border.color = "black",
                   group.by = "cell_annotation",
                   cols = "glasbey",# Option to use a different palette for cell colors
                   coord.fixed = FALSE,
                   #shuffle.cols = TRUE,
                   cells = row.names(seurat_object@meta.data)
                   [which(seurat_object@meta.data$fov == 18)]) +
  ggtitle("FOV 18")

p1/p2

## 2. whole slide-wise immune infiltration between treatment

left_join(ct, meta) %>% group_by(cell_annotation, Treatment,fov) %>% 
  summarise(counts = n()) %>% group_by(Treatment,fov) %>% 
  mutate(frequency = counts / sum(counts)) %>% 
  mutate(Treatment = factor(Treatment, levels = c('SCR','OTX'))) %>%
  ggplot(aes(x = reorder(cell_annotation,-frequency),y=frequency,color = Treatment)) +
  geom_boxplot(alpha=.5) +
  geom_jitter(position = position_dodge(width = 0.5),alpha=.5) +
  #geom_text(aes(label = round(frequency, 3)), angle = 90,vjust = 0, size = 2.5)+
  theme_bw() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
        panel.grid = element_blank()) +
  xlab('') + ylab('Frequency') +
  guides(fill = guide_legend(keywidth = 0.5, 
                             keyheight = 0.5, 
                             override.aes = list(size = 2),
                             ncol = 1)) 

#####################################################################
## 3. Spatial context
#####################################################################

spatialcontex <- readRDS('~/PTPN2_ST/PTPN2_ST_R/Spatial_context_and_InsituCor/160042cRcc_metadata_with_spatialcontext.RDS')

annotation <- readRDS('~/PTPN2_ST/PTPN2_ST_R/data_processing_CosMxref/160042cRccinsitutype_initial_results.RDS') 

ct <- data.frame(cell_annotation = annotation$clust)

seurat_object <- readRDS("/projects/grc/io/datasets/ptpn2i/GTG-2243-PTPN2/GTG2243PTPN2IBatch_4_20_07_2025/seuratObject_16004.2.cRcc.RDS")

## add metadata to seurat obj

rownames(spatialcontex) <- spatialcontex$cell_id

seurat_object <- AddMetaData(object = seurat_object, metadata = spatialcontex)
seurat_object <- AddMetaData(object = seurat_object, metadata = ct)

## shorter names for ploting
seurat_object$niche <- seurat_object$RNA.modules_Neighborhood.Analysis.1_1_assignments
seurat_object$Leiden <- seurat_object$RNA.modules_Neighbor.network.expression.space.1_1_cluster_RNA.modules_Leiden.Clustering.1_1

#plot by cell type
p1 <- ImageDimPlot(seurat_object, fov = "X16004.2.cRcc", axes = TRUE, cols = "glasbey",
             flip_xy = "True", group.by = "cell_annotation")
## 3.1 spatial cluster on umap
# 3.1.1.) niche

p2 <- ImageDimPlot(seurat_object,fov = "X16004.2.cRcc", axes = TRUE, cols = 'glasbey',
             flip_xy = 'True', group.by = 'niche')
# #3.1.2) umap leiden
# DimPlot(seurat_object,group.by = 'Leiden') 

#3.1.3) spatial cluster

p3 <- ImageDimPlot(seurat_object,fov = "X16004.2.cRcc", axes = TRUE, cols = 'glasbey',
             flip_xy = 'True', group.by = "spatialclust")

p2 / p3

## 3.2. Distance to a given cell type, say distance to tumor cells from all immune cells
#imagedimplot
Idents(seurat_object) <- seurat_object$cell_annotation

ImageDimPlot(seurat_object, fov = "X16004.2.cRcc", 
             cells = WhichCells(seurat_object, 
                                idents = c("NK.cell", "Macrophage","B.cell","Plasmablast","T.cell")), 
             cols = "glasbey", size = 0.6,flip_xy = "True")

seurat_object@meta.data %>% filter(cell_annotation %in% 
                                     c("NK.cell", "Macrophage","B.cell","Plasmablast","T.cell")) %>%
  mutate(Treatment = ifelse(fov < 15, "SCR", "OTX")) %>% 
  mutate(Treatment = factor(Treatment, levels = c('SCR','OTX'))) %>%
  ggplot(aes( x = cell_annotation, y = disttonearesttumor,color = Treatment))+
  geom_boxplot(fill="white", outlier.colour=NA, position=position_dodge(width=0.9),alpha=.5) +
  geom_point(position=position_jitterdodge(dodge.width=0.9),alpha=.5) +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
        panel.grid = element_blank()) +
  xlab('') + ylab('Distance to nearest Tumor cells') +
  guides(fill = guide_legend(keywidth = 0.5, 
                             keyheight = 0.5, 
                             override.aes = list(size = 2),
                             ncol = 1)) 

## 3.3 Number of neighbors of a cell type:how many of a given cell type are in their neighborhood
## look at each niche how many tumor neighbors and lymphoid neighbors
#imagedimplot
DefaultBoundary(seurat_object[['X16004.2.cRcc']]) <- "centroid" # to show color in imagedimplot, if set segmentation, then no color on this plot

ImageDimPlot(seurat_object, fov = "X16004.2.cRcc",group.by = "niche", 
             cols = "glasbey", size = 0.6,flip_xy = "True")

# number of tumor cells in the nearest 50 neighbors
p1 <- seurat_object@meta.data %>% mutate(Treatment = ifelse(fov < 15, "SCR", "OTX")) %>%
  ggplot(aes(x = niche,y= n_tumor_neighbors,color = Treatment)) +
  geom_boxplot(alpha=.5) +
  geom_jitter(position = position_dodge(width = 0.6),alpha=.5) +
  #geom_text(aes(label = round(frequency, 3)), angle = 90,vjust = 0, size = 2.5)+
  theme_bw() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
        panel.grid = element_blank()) +
  xlab('') + ylab('Number of tumor cells in the neighborhood') +
  guides(fill = guide_legend(keywidth = 0.5, 
                             keyheight = 0.5, 
                             override.aes = list(size = 2),
                             ncol = 1)) 
# number of lymphoid cells in the nearest 50 neighbors
p2 <- seurat_object@meta.data %>% mutate(Treatment = ifelse(fov < 15, "SCR", "OTX")) %>%
  ggplot(aes(x = niche,y= n_lymphoid_neighbors,color = Treatment)) +
  geom_boxplot(alpha=.5) +
  geom_jitter(position = position_dodge(width = 0.6),alpha=.5) +
  #geom_text(aes(label = round(frequency, 3)), angle = 90,vjust = 0, size = 2.5)+
  theme_bw() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
        panel.grid = element_blank()) +
  xlab('') + ylab('Number of lymphoid cells in the neighborhood') +
  guides(fill = guide_legend(keywidth = 0.5, 
                             keyheight = 0.5, 
                             override.aes = list(size = 2),
                             ncol = 1)) 

p1 / p2 




## 4. DE analysis by seurat
#ONE. location of flatfiles:
flatfilelist <- fread("~/PTPN2_ST/flatfileExprMat_list.csv",
                      col.names = 'fullpath') %>% 
  mutate(filename = basename(fullpath),
         batch = str_split(fullpath,'/',simplify = T)[,8],
         filepath = dirname(fullpath),
         sample = str_extract(filename, pattern = "^[^_]+"),
         filegroup = str_split(filename,pattern = '_',simplify = T)[,2]
  ) %>% select(-fullpath) %>% filter(batch != 'Batch2') %>% 
  pivot_wider(names_from = 'filegroup',values_from = 'filename')

library(Seurat)

obj <- readRDS("/projects/grc/io/datasets/ptpn2i/GTG-2243-PTPN2/GTG2243PTPN2IBatch_4_20_07_2025/seuratObject_16004.2.cRcc.RDS")

## add metadata to seurat obj

rownames(meta) <- meta$cell_id
rownames(spatialcontex) <- spatialcontex$cell_id
rownames(ct) <- ct$cell_id

seurat_object <- AddMetaData(object = obj, metadata = meta)
seurat_object <- AddMetaData(object = seurat_object, metadata = spatialcontex)
seurat_object <- AddMetaData(object = seurat_object, metadata = ct)

#plot by cell type
ImageDimPlot(seurat_object, fov = "X16004.2.cRcc", axes = TRUE, cols = "glasbey",
             flip_xy = "True",group.by = "cell_annotation")


#Since there are many cell types present, we can highlight the localization of a few select groups.

Idents(seurat_object) <- seurat_object$cell_annotation

ImageDimPlot(seurat_object, fov = "X16004.2.cRcc", 
             cells = WhichCells(seurat_object, 
                                 idents = c("a", "b","c","e","NK.cell", "T.cell")), 
             cols = "glasbey", size = 0.6,flip_xy = "True")

# find all markers distinguishing cluster 5 from clusters 0 and 3

seurat_object$Treatment_celltype <- paste(seurat_object$Treatment,seurat_object$cell_annotation,sep = "_")

## set new Idents for DE analysis
Idents(seurat_object) <- seurat_object$Treatment_celltype

cluster_scra.markers <- FindMarkers(seurat_object, ident.1 = "SCR_a", 
                                ident.2 = c("OTX_b","OTX_c","OTX_e"))

sig_cluster_scra.markers <- cluster_scra.markers %>% 
  filter(p_val_adj < .05, abs(avg_log2FC) > 2) %>%
  arrange(avg_log2FC,p_val_adj)

## most decreased DEGs in SCR_A
head(sig_cluster_scra.markers, n = 10)

## top decreased markers
ImageFeaturePlot(seurat_object, fov = "X16004.2.cRcc", 
                 features = "APOE", max.cutoff = "q95") + coord_flip()

ImageFeaturePlot(seurat_object, fov = "X16004.2.cRcc", 
                 features = "CD74", max.cutoff = "q95") + coord_flip()

ImageFeaturePlot(seurat_object, fov = "X16004.2.cRcc", 
                 features = "B2M", max.cutoff = "q95") + coord_flip()

ImageFeaturePlot(seurat_object, fov = "X16004.2.cRcc", 
                 features = "APOC1", max.cutoff = "q95") + coord_flip()

## top Overexpressed markers
## most increased DEGs in SCR_A
tail(sig_cluster_scra.markers,n=10)

ImageFeaturePlot(seurat_object, fov = "X16004.2.cRcc", 
                 features = "IGFBP3", max.cutoff = "q95") + coord_flip()

ImageFeaturePlot(seurat_object, fov = "X16004.2.cRcc", 
                 features = "ENTPD4", max.cutoff = "q95") + coord_flip()


## cell typing marker expression to confirm tumors
Idents(seurat_object) <- seurat_object$cell_annotation

VlnPlot(seurat_object, features = "IDO1", assay = "RNA", layer = "counts", 
        pt.size = 0.1, y.max = 30) +
  NoLegend()

basal.crop <- Crop(seurat_object[["X16004.2.cRcc"]], x = c(15950, 16400), y = c(8700, 10500))

nano.obj[["zoom1"]] <- basal.crop
DefaultBoundary(nano.obj[["zoom1"]]) <- "segmentation"





