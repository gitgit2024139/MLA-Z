library(data.table)
library(Matrix)
library(dplyr)
library(stringr)
library(tidyr)
library(ggplot2)
library(tibble)

setwd("~/PTPN2_ST/PTPN2_ST_R/")

outdir <- './QC_plots/'

#################################################################################
#ONE. some QC plots for FOV:
##1. histarea QC

FOVpng <- data.frame(fullpath = list.files('~/PTPN2_ST/PTPN2_ST_R/data_processing_CosMxref',
                     pattern = "png",full.names = T )) %>% 
  mutate(filename = basename(fullpath),
         sample = str_split(filename,pattern = ' ',simplify = T)[,3]
  ) 
 
ctRDS <- data.frame(fullpath = list.files('~/PTPN2_ST/PTPN2_ST_R/data_processing_CosMxref',
                                           pattern = "insitutype_initial",full.names = T )) %>% 
  mutate(filename = basename(fullpath),
         sample = str_split(filename,pattern = 'insitutype_initial',simplify = T)[,1]
  ) 


## read a list of images and plot on one page
library(gridExtra)
library(png)
library(grid)

gfiles <- grep(pattern = 'histarea', FOVpng$fullpath)

img_list <- lapply(gfiles, function(i) { 
  
  img <- rasterGrob(readPNG(FOVpng$fullpath[i]), interpolate = TRUE)
  
  title <- textGrob(FOVpng$sample[i], 
                    gp = gpar(fontsize = 10, fontface = "bold"))
  
  arrangeGrob(title, img, ncol = 1, heights = c(.05, .95))
  
})

filename <- paste(outdir, "plot_all_","histarea",".png",sep = '')
png(filename)
grid.arrange(grobs = img_list, ncol = 4)
dev.off()

##2.plot XY

gfiles <- grep(pattern = 'plot_xy ', FOVpng$fullpath)

img_list <- lapply(gfiles, function(i) { 
  
  img <- rasterGrob(readPNG(FOVpng$fullpath[i]), interpolate = TRUE)
  
  title <- textGrob(FOVpng$sample[i], 
                    gp = gpar(fontsize = 10, fontface = "bold"))
  
  arrangeGrob(title, img, ncol = 1, heights = c(.05, .95))
  
})

filename <- paste(outdir, "plot_all_","XY",".png",sep = '')
png(filename)
grid.arrange(grobs = img_list, ncol = 4)
dev.off()

##3. plot SignalLossSpatial FOVs

gfiles <- grep(pattern = 'mapFlagFOVs ', FOVpng$fullpath)

img_list <- lapply(gfiles, function(i) { 
  
  img <- rasterGrob(readPNG(FOVpng$fullpath[i]), interpolate = TRUE)
  
  title <- textGrob(FOVpng$sample[i], 
                    gp = gpar(fontsize = 10, fontface = "bold"))
  
  arrangeGrob(title, img, ncol = 1, heights = c(.05, .95))
  
})

filename <- paste(outdir, "plot_all_","mapFlagFOVs",".png",sep = '')
png(filename)
grid.arrange(grobs = img_list, ncol = 4)
dev.off()

### 4. plot FOVEffectsHeatmap

gfiles <- grep(pattern = 'FOVEffectsHeatmap', FOVpng$fullpath)[c(1:2,4,5)]

img_list <- lapply(gfiles, function(i) { 
  
  img <- rasterGrob(readPNG(FOVpng$fullpath[i]), interpolate = TRUE)
  
  title <- textGrob(FOVpng$sample[i], 
                    gp = gpar(fontsize = 10, fontface = "bold"))
  
  arrangeGrob(title, img, ncol = 1, heights = c(.05, .95))
  
})

filename <- paste(outdir, "plot_all_","FOVEffectsHeatmap",".png",sep = '')
png(filename)
grid.arrange(grobs = img_list, ncol = 2)
dev.off()

## 5. cell typing umap
gfiles <- grep(pattern = 'umapInsituType ', FOVpng$fullpath)

img_list <- lapply(gfiles, function(i) { 
  
  img <- rasterGrob(readPNG(FOVpng$fullpath[i]), interpolate = TRUE)
  
  title <- textGrob(FOVpng$sample[i], 
                    gp = gpar(fontsize = 10, fontface = "bold"))
  
  arrangeGrob(title, img, ncol = 1, heights = c(.05, .95))
  
})

filename <- paste(outdir, "plot_all_","umapInsituType",".png",sep = '')
png(filename)
grid.arrange(grobs = img_list, ncol = 4)
dev.off()


## 6. cell typing in each ST slide summarization
gfiles <- grep(pattern = 'xyInsityType ', FOVpng$fullpath) ## image 
cfiles <- ctRDS ## celltype rds

for (i in gfiles) {
  
  img <- rasterGrob(readPNG(FOVpng$fullpath[i]), interpolate = TRUE)
  
  title <- textGrob(FOVpng$sample[i], 
                    gp = gpar(fontsize = 10, fontface = "bold"))
  
  ct <- readRDS(cfiles$fullpath[cfiles$sample == FOVpng$sample[i]])
  
  ctimag <- data.frame(cell_annotation = ct$clust) %>% group_by(cell_annotation) %>% 
    summarise(counts = n()) %>% 
    mutate(frequency = counts / sum(counts)) %>% 
    ggplot(aes(x = reorder(cell_annotation,-frequency),y=frequency,fill = cell_annotation)) +
    geom_bar(stat = 'identity', position = 'dodge') +
    geom_text(aes(label = round(frequency, 3)), angle = 90,vjust = 0, size = 2.5)+
    theme_bw() +
    theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
          panel.grid = element_blank()) +
    xlab('') + ylab('Count') +
    guides(fill = guide_legend(keywidth = 0.5, 
                               keyheight = 0.5, 
                               override.aes = list(size = 2),
                               ncol = 1))
  
  filename <- paste(outdir, "plot_",FOVpng$sample[i],"_xyInsituType_pct",".png",sep = '')
  png(filename,width = 800, height = 300)
  grid.arrange(arrangeGrob(img, ctimag, ncol = 2, top = title))
  dev.off()
}


###7. cell annotation analysis in 2501 
## FOV 1:21 == SCR; 22: == OTX

meta <- readRDS('~/PTPN2_ST/PTPN2_ST_R/data_processing_CosMxref/2501cRCCprocessed_data_metadata.RDS') %>% 
  mutate(Treatment = ifelse(fov < 22, "SCR", "OTX"))

annotation <- readRDS('~/PTPN2_ST/PTPN2_ST_R/data_processing_CosMxref/2501cRCCinsitutype_initial_results.RDS')

ct <- data.frame(cell_annotation = annotation$clust) %>% tibble::rownames_to_column("cell_id")

left_join(ct, meta) %>% group_by(cell_annotation, Treatment) %>% 
  summarise(counts = n()) %>% group_by(Treatment) %>% 
  mutate(frequency = counts / sum(counts)) %>% 
  mutate(Treatment = factor(Treatment, levels = c('SCR','OTX'))) %>% 
  ggplot(aes(x = reorder(cell_annotation,-frequency),y=frequency,fill = cell_annotation)) +
  geom_bar(stat = 'identity', position = 'dodge') +
  geom_text(aes(label = round(frequency, 3)), angle = 90,vjust = 0, size = 2.5)+
  theme_bw() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
        panel.grid = element_blank()) +
  xlab('') + ylab('Count') +
  guides(fill = guide_legend(keywidth = 0.5, 
                             keyheight = 0.5, 
                             override.aes = list(size = 2),
                             ncol = 1)) +
  facet_wrap(~Treatment,ncol=1)

###8. cell annotation analysis in 164002
## FOV 1:14 == SCR; 15: == OTX

meta <- readRDS('~/PTPN2_ST/PTPN2_ST_R/data_processing_CosMxref/160042cRccprocessed_data_metadata.RDS') %>% 
  mutate(Treatment = ifelse(fov < 15, "SCR", "OTX"))

annotation <- readRDS('~/PTPN2_ST/PTPN2_ST_R/data_processing_CosMxref/160042cRccinsitutype_initial_results.RDS')

ct <- data.frame(cell_annotation = annotation$clust) %>% tibble::rownames_to_column("cell_id")

left_join(ct, meta) %>% group_by(cell_annotation, Treatment) %>% 
  summarise(counts = n()) %>% group_by(Treatment) %>% 
  mutate(frequency = counts / sum(counts)) %>% 
  mutate(Treatment = factor(Treatment, levels = c('SCR','OTX'))) %>% 
  ggplot(aes(x = reorder(cell_annotation,-frequency),y=frequency,fill = cell_annotation)) +
  geom_bar(stat = 'identity', position = 'dodge') +
  geom_text(aes(label = round(frequency, 3)), angle = 90,vjust = 0, size = 2.5)+
  theme_bw() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
        panel.grid = element_blank()) +
  xlab('') + ylab('Count') +
  guides(fill = guide_legend(keywidth = 0.5, 
                             keyheight = 0.5, 
                             override.aes = list(size = 2),
                             ncol = 1)) +
  facet_wrap(~Treatment,ncol=1)


