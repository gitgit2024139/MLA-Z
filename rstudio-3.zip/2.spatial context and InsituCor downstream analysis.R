library(data.table)
library(Matrix)
library(dplyr)
library(stringr)
library(tidyr)
library(ggplot2)
library(tibble)

setwd("~/PTPN2_ST/PTPN2_ST_R/")

outdir <- './Spatial_context_and_InsituCor/'

library(mclust)
library(irlba)
library(spatstat)
library(spatstat.geom)
library(spatstat.explore)

source("utils/spatial functions.R")

#Adjust globals option to avoid an error exceeding max allowed size. We’ve found this is necessary even with relatively small CosMx SMI datasets (30 - 40 FOVs).
options(future.globals.maxSize = 8000 * 1024^2)

#################################################################################
#ONE. to study how cells change in response to their spatial context
#distance to nearest tumor cell, number of tumor cells in neighborhood, neighborhood expression level of a given cytokine
##1. # load data:
# note these files are for convenience during analysis, and are not a NanoString-supported format

masterdf <- rbind(data.frame(fullpath = list.files('~/PTPN2_ST/PTPN2_ST_R/data_processing_CosMxref',
                                         pattern = "norm.RDS",full.names = T )) %>% 
  mutate(filename = basename(fullpath),
         sample = str_split(filename,pattern = 'processed_data',simplify = T)[,1],
         filetype = "norm"
  ),
  data.frame(fullpath = list.files('~/PTPN2_ST/PTPN2_ST_R/data_processing_CosMxref',
                                   pattern = "metadata.RDS",full.names = T )) %>% 
    mutate(filename = basename(fullpath),
           sample = str_split(filename,pattern = 'processed_data',simplify = T)[,1],
           filetype = "metadata"
    ),
  data.frame(fullpath = list.files('~/PTPN2_ST/PTPN2_ST_R/data_processing_CosMxref',
                                   pattern = "insitutype_initial_results.RDS",full.names = T )) %>% 
    mutate(filename = basename(fullpath),
           sample = str_split(filename,pattern = 'insitutype_initial_results',simplify = T)[,1],
           filetype = "celltype"
    ),
  data.frame(fullpath = list.files('~/PTPN2_ST/PTPN2_ST_R/data_processing_CosMxref',
                                   pattern = "xy.RDS",full.names = T )) %>% 
    mutate(filename = basename(fullpath),
           sample = str_split(filename,pattern = 'processed_data',simplify = T)[,1],
           filetype = "xy"
    )
) %>% select(-filename) %>%
  pivot_wider(names_from = filetype, values_from = fullpath)
  
## 2.  Spatial clustering,  we record the mean expression in each cell’s neighborhood, and we cluster cells based on these values

for (i in seq_along(masterdf$sample)) {
  
  norm <- readRDS(masterdf$norm[i])
  metadata <- readRDS(masterdf$metadata[i]) 
  celltype <- readRDS(masterdf$celltype[i])
  xy <- readRDS(masterdf$xy[i])
  
  #1) define neighbors:
  neighbors_sparsematrix <- nearestNeighborGraph(x = xy[, 1], y = xy[, 2], N = 50,
                                                 subset = metadata$Run_Tissue_name)
  
  # get matrix of mean expression in each cell's neighbors:
  neighborhoodexpression <- neighbor_colMeans(x = norm, neighbors = neighbors_sparsematrix)
  
  # reduce the matrix to its top PCs:
  pc <- irlba::prcomp_irlba(neighborhoodexpression, n = 25)$x
  
  # cluster the top PCs:
  temp <- mclust::Mclust(pc, 
                         G = 6, # 6 clusters
                         modelNames = c("EEI"))
  spatialclust <- temp$classification
  
  # plot the results:
  cols <- c("#616161","#4285f4","#db4437","#f4b400","#0f9d58","#ab47bc","#00acc1",
            "#ff7043","#9e9d24","#5c6bc0","#f06292","#00796b","#c2185b","#7e57c2",
            "#03a9f4","#8bc34a","#fdd835","#fb8c00","#8d6e63","#9e9e9e","#607d8b")
  
  # plot:
  filename <- paste(outdir, "plot_xy",masterdf$sample[i],"_spatial_context",".png",sep = '')
  png(filename)
  sub = TRUE
  plot(xy[sub, ], pch = 16, cex = 0.1, 
       asp = 1, xlab = "", ylab = "",
       col = cols[as.numeric(as.factor(spatialclust[sub]))])
  dev.off()
  
  # add to metadata:
  metadata$spatialclust <- spatialclust
  
  #Hand-defining spatial context
  #1. Distance to a given cell type:
  
  # record IDs and distances to nearest 50 neighbors:
  tumorcelltypes <- celltype$clust%>%unique
  
  tumorcelltypes <- tumorcelltypes[nchar(tumorcelltypes)==1]
  
  neighbors_dists <- FNN::get.knnx(data = xy[is.element(celltype$clust, tumorcelltypes), ], 
                                   query = xy, 
                                   k = 5)
  
  str(neighbors_dists)
  # record distance to a cell type:
  metadata$disttonearesttumor <- neighbors_dists$nn.dist[, 1]
  # record 3rd-closest distance to the cell type:
  metadata$distto3rdnearesttumor <- neighbors_dists$nn.dist[, 3]
  
  ##2. Number of neighbors of a cell type:
  #you might categorize cells by how many of a given cell type are in their neighborhood:
  
  # create a point process object:
  pp <- spatstat.geom::ppp(xy[, 1], xy[, 2], xrange = range(xy[, 1]), yrange = range(xy[, 2]))
  marks(pp) <- celltype$clust
  spatstat.geom::marks(pp) <- celltype$clust
  spatstat.geom::marks(pp) <- as.factor(spatstat.geom::marks(pp))
  # count neighbors of each db cluster:
  neighbormarks <- spatstat.explore::marktable(X = pp, R = NULL, N = 50, exclude=TRUE, collapse=FALSE)
  neighbormarks <- as.matrix(neighbormarks)
  rownames(neighbormarks) <- rownames(xy)
  head(neighbormarks)[, 1:10] 
  colnames(neighbormarks)
  
  nontumorcelltypes <- colnames(neighbormarks)[!(colnames(neighbormarks) %in% tumorcelltypes)]
  lymphoidcelltypes <- nontumorcelltypes[grep("^T.cell|^B.cell|^Macrophage|^NK.cell|^Plasma" ,
                                              nontumorcelltypes)]
  
  # save results for your desired cell types:
  
  for (celltype in colnames(neighbormarks)) {
    
    name <- paste("n_",gsub('\\.','_',celltype),"_neighbors",sep = '')
    
    metadata <- metadata %>% mutate( !!name := neighbormarks[, celltype])
    
  }
  
   # save the sum of several related cell types:
  
  metadata$n_tumor_neighbors <- rowSums(neighbormarks[, tumorcelltypes])
  
  metadata$n_lymphoid_neighbors <- rowSums(neighbormarks[, lymphoidcelltypes])
  
  #3. Neighborhood expression of a gene
  # immune cells respond to cytokine signaling, so you might want to see how much of a given cytokine each cell is exposed to.
  
  # get cells' nearest 50 spatial neighbors:
  neighbors_sparsematrix <- nearestNeighborGraph(x = xy[, 1], y = xy[, 2], N = 50, 
                                                 subset = metadata$Run_Tissue_name)  
  # get neighborhood expression of a chosen gene:
  gene <- "IFNG"
  metadata$neighborhood_IFNG_expression <- neighbor_mean(x = norm[, gene], 
                                                         neighbors = neighbors_sparsematrix)
  
  saveRDS(metadata, paste0(outdir, masterdf$sample[i],"_metadata_with_spatialcontext.RDS",sep = ''))
  
  }






