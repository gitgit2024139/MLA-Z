library(data.table)
library(Matrix)
library(dplyr)
library(stringr)
library(tidyr)

setwd("~/PTPN2_ST/PTPN2_ST_R/")

#################################################################################
#ONE. location of flatfiles:
flatfilelist <- fread("~/PTPN2_ST/flatfileExprMat_list.csv",
                      col.names = 'fullpath') %>% 
  mutate(filename = basename(fullpath),
         batch = str_split(fullpath,'/',simplify = T)[,8],
         filepath = dirname(fullpath),
         sample = str_extract(filename, pattern = "^[^_]+"),
         filegroup = str_split(filename,pattern = '_',simplify = T)[,2]
         ) %>% select(-fullpath) %>% filter(batch != 'Batch2') %>% 
  pivot_wider(names_from = 'filegroup',values_from = 'filename')

outdir <- './data_processing_scRNAandIoprofileREF/'

### read in ST file per slide into rds

for ( i in 1:dim(flatfilelist)[1]) {
  
  counts <- paste(flatfilelist$filepath[i],
                  flatfilelist$exprMat[i],sep = '/')
  
  metadata <- paste(flatfilelist$filepath[i],
                    flatfilelist$metadata[i],sep='/')
  
  sample <- flatfilelist$sample[i]
  
  counts <- fread(counts)
  
  counts_mtx_rowname <- paste('c_1',counts$fov,counts$cell_ID,sep = '_')
  #convert to sparsemtx
  counts_mtx <- as(counts[,-c('fov','cell_ID'),with = F],'sparseMatrix')
  #add rownames
  rownames(counts_mtx) <- counts_mtx_rowname
  
  #add metadata
  metadata <- fread(metadata)
  
  rownames(metadata) <- metadata$cell_id
  
  metadata$cell_ID <- NULL
  
  # isolate negative control matrices:
  negcounts <- counts_mtx[, grepl("Negative", colnames(counts_mtx))]
  falsecounts <- counts_mtx[, grepl("SystemControl", colnames(counts_mtx))]
  
  # reduce counts matrix to only genes:
  counts_mtx <- counts_mtx[, !grepl("Negative", colnames(counts_mtx)) & 
                             !grepl("SystemControl", colnames(counts_mtx))]
  
  #####################################################################################
  ##TWO: Finessing tissues’ spatial arrangement Preliminaries
  #break out cells’ xy positions in a distinct data object:
  
  xy <- as.matrix(metadata[,c("CenterX_global_px", "CenterY_global_px")])
  rownames(xy) <- metadata$cell_id
  
  # rescale to mm:
  thisinstrument_nanometers_per_pixel = 120.280945   
  # The above value holds for most instruments. Your RunSummary file specifies the value for your instrument. 
  xy <- xy * thisinstrument_nanometers_per_pixel / 1000000
  colnames(xy) <- paste0(c("x", "y"), "_mm")
  
  #Now we make sure that no tissue overlaps another. (In studies with multiple slides, xy positions can overlap.) The script utils/condenseTissues.R holds a useful function for automating this process:
  source("utils/condenseTissues.R")
  
  set.seed(1)
  xy <- condenseTissues(xy = xy, 
                        tissue = metadata$Run_Tissue_name, 
                        tissueorder = NULL,  # optional, specify the order tissues are tiled in
                        buffer = 1, # space between tissues
                        widthheightratio = 4/3) # desired shape of final xy locations 
  
  #Now we can see our tissues’ xy coordinates:
  # to avoid unnecessarily plotting all the cells, just show a subset:
  sub <- sample(1:nrow(xy), round(nrow(xy) / 20), replace = FALSE)
  
  # define a color palette (using a Google palette):
  cols <- c("#616161","#4285f4","#db4437","#f4b400","#0f9d58","#ab47bc",
            "#00acc1","#ff7043","#9e9d24","#5c6bc0","#f06292","#00796b","#c2185b","#7e57c2",
            "#03a9f4","#8bc34a","#fdd835","#fb8c00","#8d6e63","#9e9e9e","#607d8b")
  
  filename <- paste(outdir, "plot_xy", sample, ".png")
  png(filename)
  # plot:
  plot(xy[sub, ], pch = 16, cex = 0.2, 
       asp = 1, # important: keep the true aspect ratio
       col = cols[as.numeric(as.factor(metadata$Run_Tissue_name[sub])) %% length(cols) + 1])
  dev.off()
  # # label tissues:
  # for (slidename in unique(metadata$Run_Tissue_name)) {
  #   text(text(median(xy[metadata$Run_Tissue_name == slidename, 1]), 
  #             max(xy[metadata$Run_Tissue_name == slidename, 2]), slidename))
  # }
  
  ################################################################################################
  #THREE : QC normalization and batch-correction
  
  library(Matrix)
  library(viridis)
  
  # 1 cell_level QC
  
  # require 250 counts per cell 
  count_threshold <- 250
  flag <- metadata$nCount_RNA < count_threshold
  table(flag)
  
  filename <- paste(outdir, "plot_histarea", sample, ".png")
  png(filename)
  
  # what's the distribution of areas?
  hist(metadata$Area, breaks = 100, xlab = "Cell Area", main = "")
  # based on the above, set a threshold:
  area_threshold <- 30000
  abline(v = area_threshold, col = "red")
  
  dev.off()
  
  # flag cells based on area:
  flag <- flag | (metadata$Area > area_threshold)
  table(flag)
  
  # 2 FOV-level QC
  
  ## preparing resources:
  # source the FOV QC tool:
  source("utils/FOV QC utils.R")
  # load necessary information for the QC tool: the gene to barcode map:
  allbarcodes <- readRDS(url("https://github.com/Nanostring-Biostats/CosMx-Analysis-Scratch-Space/raw/Main/_code/FOV%20QC/barcodes_by_panel.RDS"))
  names(allbarcodes)
  # get the barcodes for the panel we want:
  barcodemap <- allbarcodes$Hs_6k
  head(barcodemap)
  ## run the method:
  fovqcresult <- runFOVQC(counts = counts_mtx, xy = xy, fov = metadata$fov, barcodemap = barcodemap, max_prop_loss = 0.3) 
  # map of flagged FOVs:
  filename <- paste(outdir, "plot_mapFlagFOVs", sample, ".png")
  png(filename)
  
  par(mfrow = c(1,1))
  mapFlaggedFOVs(fovqcresult)
  dev.off()
  
  # list FOVs flagged for any reason, for loss of signal, for bias:
  fovqcresult$flaggedfovs
  fovqcresult$flaggedfovs_fortotalcounts
  fovqcresult$flaggedfovs_forbias
  
  #We only flagged FOVs for bias, not for signal loss, but the map of signal strength is still worth examining:
  filename <- paste(outdir, "plot_FOVSignalLossSpatial", sample, ".png")
  png(filename)
  
  FOVSignalLossSpatialPlot(fovqcresult) 
  
  dev.off()
  
  # spatial plots of flagged reporter positions:
  par(mfrow = c(2,2))
  FOVEffectsSpatialPlots(res = fovqcresult, outdir = NULL, 
                         bits = "flagged_reportercycles") 
  
  #A final useful plot shows which barcode bits x FOVs showed evidence for lost signal:
  filename <- paste(outdir, "plot_FOVEffectsHeatmap", sample, ".png")
  png(filename)
  
  FOVEffectsHeatmap(fovqcresult) 
  dev.off()
  
  #The FOV QC result also reports which genes are impacted in any flagged FOVs:
  print(unique(fovqcresult$flagged_fov_x_gene[,"gene"]))
  
  #Thus while we only flagged one reporter cycle, i.e. 4 barcode bits, over a quarter of the gene panel relies on one of these bits. None of these genes can be analyzed in this FOV. The simplest way forward is to flag and remove all cells in this FOV:
  flag <- flag | is.element(metadata$fov, fovqcresult$flaggedfovs)
  table(flag)
  
  # subset all data objects to only the cells to be kept:
  counts <- counts_mtx[!flag, ]
  negcounts <- negcounts[!flag, ]
  falsecounts <- falsecounts[!flag, ]
  metadata <- metadata[!flag, ]
  xy <- xy[!flag, ]
  # overwrite saved data with filtered data:
  # note these files are for convenience during analysis, and are not a NanoString-supported format
  #saveRDS(counts, paste(outdir,sample, "processed_data_counts.RDS",sep = ''))
  #saveRDS(negcounts, paste0(outdir,sample, "processed_data_negcounts.RDS",sep = ''))
  #saveRDS(falsecounts, paste0(outdir, sample,"processed_data_falsecounts.RDS",sep = ''))
  #saveRDS(metadata, paste0(outdir, sample,"processed_data_metadata.RDS",sep = ''))
  #saveRDS(xy, paste0(outdir, sample,"processed_data_xy.RDS",sep = ''))
  
  #Normalization
  scaling_factor <- mean(metadata$nCount_RNA)
  norm <- Matrix::Diagonal(x = scaling_factor/metadata$nCount_RNA,names=colnames(counts)) %*% counts
  #saveRDS(norm, paste0(outdir,sample, "processed_data_norm.RDS",sep = ''))
  
  ##################################################################################################
  ## FOUR Dimension reduction
  library(uwot)
  library(irlba)
  library(viridis)
  
  # run PCA:
  pc <- irlba::prcomp_irlba(sqrt(norm), n = 25)$x
  
  # run UMAP:
  um <- uwot::umap(pc, n_neighbors = 40, spread = 1, min_dist = 0.1, metric = "cosine")
  rownames(um) <- rownames(norm)
  #saveRDS(um, paste0(outdir,sample, "processed_data_um.RDS",sep = ''))
  
  # More umap with QCs
  # random point order so no tissue or slide is on top by default:
  o <- sample(1:nrow(um))
  
  filename <- paste(outdir, "plot_UMAP", sample, ".png")
  png(filename)
  
  par(mfrow = c(1,1))
  # color by tissue
  plot(um[o, ], pch = 16, cex = 0.1, 
       col = as.numeric(as.factor(metadata$fov[o])), 
       main = "by FOV")
  legend("topright", pch = 16, cex=.5,bty = 'n',
         col = 1:length(unique(metadata$fov)), 
         legend = levels(as.factor(metadata$fov)))
  dev.off()
  
  #saveRDS(um, file = paste(outdir,sample, 'processed_data_umap_coord.RDS',sep = ''))
  
  ###############################################################################################
  ## FIVE. Cell Typing
  #Adjust globals option to avoid an error exceeding max allowed size. We’ve found this is necessary even with relatively small CosMx SMI datasets (30 - 40 FOVs).
  options(future.globals.maxSize = 8000 * 1024^2)
  
  library(pheatmap)
  
  ## before installing insitutype, also need fastglm and lsa, had to install by manual local and github
  # devtools::install_github("jaredhuling/fastglm")
  # install.packages("~/PTPN2_ST/PTPN2_ST_R/lsa_0.73.3.tar.gz", repos = NULL, type = "source")
  # # Install Insitutype:
  #devtools::install_github("https://github.com/Nanostring-Biostats/InSituType")
  
  library(InSituType)
  #download a reference profile matrix from a previous CosMx experiment:
  #data("ioprofiles") ## 1. ioprofiles has worst results of cell typing
  ##2. using other CosMx ref dataset
  ##3. Using scRNAseq + IOprofiles from Bruker CellProfileLibrary
  library(InSituType)
  data("ioprofiles")
  
  ## refine refdata
  
  if (sample %in% c("2203TONSILREPEAT","2204hnsccrepeatbatch1")) {
    # load HCA profiles for tissue spacific:
    load('~/PTPN2_ST/PTPN2_ST_R/scRNA_ref/Skin_HCA.RData')
    
  } else if (sample %in% c("300121116SLIDE","300122117SLIDE")) {
    # load HCA profiles for tissue spacific:
    load('~/PTPN2_ST/PTPN2_ST_R/scRNA_ref/Lung_HCA.RData')
    
  } else {
    # load HCA profiles for tissue spacific:
    load('~/PTPN2_ST/PTPN2_ST_R/scRNA_ref/Kidney_HCA.RData')
    
  }
  
  mtx <- as.matrix(profile_matrix)
  
  # align genes:
  sharedgenes <- intersect(rownames(ioprofiles), rownames(mtx))
  ioprofiles <- ioprofiles[sharedgenes, ]
  mtx <- mtx[sharedgenes, ]
  
  # put on appproximately the same scale:
  ioprofiles <- ioprofiles / quantile(ioprofiles, 0.99) * 1000
  mtx <- mtx / quantile(mtx, 0.99) * 1000
  
  # merge:
  ref <- cbind(ioprofiles[, setdiff(colnames(ioprofiles), colnames(mtx))], 
               mtx[, setdiff(colnames(mtx), colnames(ioprofiles))])
  
  refprofiles <- ref
  
  refprofiles <- refprofiles[is.element(rownames(refprofiles),colnames(counts)),]
  
  pheatmap::pheatmap(
    sweep(refprofiles,1,pmax(
      apply(refprofiles, 1, max),0.2),
      "/"),
    col = colorRampPalette(c('blue','white','red'))(100),
    fontsize_row = 1
  )
  
  ## ONE. Initial cell typing
  #Next we’ll use Insitutype to assign our cells to these previously-published cell types, while looking for 6 new clusters (it’s usually advisable to overcluster at first):
  
  insitutypefileloc <- paste(outdir,sample, "insitutype_initial_results.RDS",sep='')
  
  if(!file.exists(insitutypefileloc)) {
    
    set.seed(0)
    res <- InSituType::insitutype(
      x = counts,
      neg = Matrix::rowMeans(negcounts),
      reference_profiles = refprofiles,
      update_reference_profiles = FALSE,
      n_clust = 6
    )
    saveRDS(res,file = insitutypefileloc)
  } else {
    res <- readRDS(insitutypefileloc)
  }
  
  # cell type color 
  cols <- InSituType::colorCellTypes(freqs = table(res$clust), palette = "brewers")
  str(cols)
  
  ## QC of cell typing results
  # flightpath
  flightpath <- InSituType::flightpath_layout(logliks = res$logliks, profiles = res$profiles)
  
  filename <- paste(outdir, "plot_flightpath", sample, ".png")
  png(filename)
  
  par(mar = c(0,0,0,0))
  plot(flightpath$cellpos, pch = 16, cex = 0.2, col = cols[res$clust])
  text(flightpath$clustpos[, 1], flightpath$clustpos[, 2], rownames(flightpath$clustpos), cex = 0.7)
  dev.off()
  
  filename <- paste(outdir, "plot_umapInsituType", sample, ".png")
  png(filename)
  # umap
  plot(um, pch = 16, cex = 0.1, col = cols[res$clust])
  
  for (cell in unique(res$clust)) {
    text(median(um[res$clust == cell, 1]), 
         median(um[res$clust == cell, 2]), 
         cell, 
         cex = 0.7)  
  }
  dev.off()
  
  filename <- paste(outdir, "plot_xyInsityType", sample, ".png")
  png(filename)

  # xy space:
  plot(xy, pch = 16, cex = 0.1, col = cols[res$clust], asp = 1)  
  dev.off()
  #Higher rates of confusion are seen between closely-related cell types, e.g. among T-cell subtypes or the (presumably tumor) clusters a, b, c, and e. But for the most part this is a good result, with no indication that any clusters are irredeemably confused.
  #Next we draw a heatmap of the cluster profiles. These are helpful for confirming that clusters have the expected marker genes
  # profiles heatmap
  #pdf(paste0(mydir, "/results/celltypeprofiles.pdf"), height = 20)
  filename <- paste(outdir, "plot_HeatmapInsitutype", sample, ".png")
  png(filename)
  
  pheatmap::pheatmap(sweep(res$profiles, 1, 
                           pmax(apply(res$profiles, 1, max), 
                                0.2), "/")[apply(res$profiles, 1, max) > 0.2, ],  
                     fontsize_row = 4,
                     col = colorRampPalette(c("blue","white", "red"))(100)) 
  dev.off()
  
}

################################################################################








