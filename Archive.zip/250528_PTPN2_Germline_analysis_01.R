#### Loading in Libraries ####
setwd("/projects/users/wilsosx11/250528_PTPN2_Germline/")
options(bitmapType='cairo')
options(scipen = 999)
options(max.print = 10000)
options(future.globals.maxSize = 6 * 1024^3)
#List of libraries to load
library(remotes)
library("httr")
library("ggplot2")
library("dplyr")
library("tidyr")
library("gt")
require("scales")
library("janitor")
library("BiocManager")
library("S4Vectors")
library("tidyverse")
library("devtools")
library("ggcorrplot")
library('reshape2')
library("ggpubr")
library(pheatmap)
library(gplots)
library(limma)
library(illuminaio)
library(VariantAnnotation)
library(biomaRt)

#### Loading in my Imputed Chr18 data, filtering for Ptpn2 and annotating ####
#file paths
file <- "/projects/users/wilsosx11/250528_PTPN2_Germline/GTG-2090_Final/250606_Mighican_server_imputation_output/chr18.dose.vcf.gz"

#Loading in vcf  file
vcf <- readVcf(file)
samples(header(vcf)) # lists TCGA_patient samples
geno(header(vcf))

#Converting Genotype into a dataframe
GT <-geno(vcf)$GT
GT.wide <- as.data.frame(GT)
GT.wide <- rownames_to_column(GT.wide, var = "Name")
GT.wide$Name <- gsub("X", "", GT.wide$Name)
GT.wide$Name <- sub("\\.", ":", GT.wide$Name)

##Adding Annotation to dataframe
#creating coordinate dataframe
coords <- GT.wide$Name
coords <- as.data.frame(coords)
coords <- separate(coords,coords, into = c("Chromosome","Start"), sep = ":")
coords$End <- coords$Start
coords <- na.omit(coords)
coords <- coords %>% mutate(Chromosome=paste("chr",Chromosome,sep=""))
coords <- coords %>%filter(Start >= 12828777 & Start <= 12854981) # filtering for Ptpn2 gene coordinates

#Adding Gene and Gene locus annotation
library(annotatr)
colnames(coords)
my_snps <- coords[, !(names(coords) %in% c("SNP","REF.0.","ALT.1.","ALT_Frq","MAF","AvgCall","Rsq","Genotyped","LooRsq","EmpR","EmpRsq","Dose0","Dose1","rsid","unknown","strand"))]
names(my_snps)[names(my_snps) =="start"]<- "Start"
names(my_snps)[names(my_snps) =="end"]<- "End"
intervals = GenomicRanges::makeGRangesFromDataFrame(my_snps)
annots = c('hg19_basicgenes')
annotations = build_annotations(genome = 'hg19', annotations = annots)
dm_annotated = annotate_regions(regions = intervals,annotations = annotations,ignore.strand = TRUE,quiet = FALSE)
df_dm_annotated = data.frame(dm_annotated)
new_SNP6_anno <- df_dm_annotated
new_SNP6_anno <- na.omit(new_SNP6_anno)
colnames(new_SNP6_anno)
new_SNP6_anno <-subset(new_SNP6_anno,select=c("seqnames","start","end","strand","annot.symbol","annot.type")) #select columns needed
names(new_SNP6_anno)[names(new_SNP6_anno) =="seqnames"]<- "Chromosome"
new_SNP6_anno <- new_SNP6_anno %>%  distinct(Chromosome,start,end,annot.symbol,annot.type) #creates only one instance of genotype per probe
new_SNP6_anno$Chromosome <- gsub("^chr", "", new_SNP6_anno$Chromosome)
new_SNP6_anno <- new_SNP6_anno %>% mutate(Name = paste(Chromosome, start, sep = ":"))
new_SNP6_anno <-subset(new_SNP6_anno,select=c("Name","annot.symbol","annot.type")) #select columns needed

# Convert the wide dataframe to a long dataframe
GT.long <- melt(GT.wide, id.vars = "Name", variable.name = "barcode", value.name = "genotype")

#Merging Annotation with GT.long
GT.long <- merge(GT.long,new_SNP6_anno,by=c("Name"))

## Saving data as a rsid file
saveRDS(coords, file = "250606_coords_file.rds")
saveRDS(GT.wide, file = "250606_GT_wide_annotated_file.rds")
saveRDS(GT.long, file = "250606_GT_long_annotated_file.rds")
coords <-  readRDS(file = "250606_coords_file.rds")
GT.wide <- readRDS(file = "250606_GT_wide_annotated_file.rds")
GT.long <- readRDS(file = "250606_GT_long_annotated_file.rds")

#### Loading in Seve's Chr18 data ####
#file paths
file <- "/projects/users/wilsosx11/250528_PTPN2_Germline/seve_cleaned_vcf_files/chr18.filtered.vcf.gz"

#Loading in vcf  file
vcf.seve <- readVcf(file)
samples(header(vcf.seve)) # lists TCGA_patient samples
geno(header(vcf.seve))

#Converting Genotype into a dataframe
GT <-geno(vcf.seve)$GT
GT.seve.wide <- as.data.frame(GT)
GT.seve.wide <- rownames_to_column(GT.seve.wide, var = "Name")


# Function to remove everything after the second ':'
remove_after_second_colon <- function(x) {
  sub("^([^:]+:[^:]+):.*", "\\1", x)
}
GT.seve.wide <- sapply(GT.seve.wide, remove_after_second_colon)
GT.seve.wide <- as.data.frame(GT.seve.wide)

# Test to see if GT.wide is found within GT.seve.wide
is_in <- GT.wide$Name %in% GT.seve.wide$Name
common_names <- GT.wide$Name[is_in]
print(common_names)

# Merging the datasets so that there is only one GT.wide
GT.wide2 <- merge(GT.wide,GT.seve.wide,by = "Name")

# Convert the wide dataframe to a long dataframe
GT.long <- melt(GT.wide2, id.vars = "Name", variable.name = "barcode", value.name = "genotype")

#Merging Annotation with GT.long
GT.long <- merge(GT.long,new_SNP6_anno,by=c("Name"))


#Adding annotation for which batch its from. 
GT.long$batch <- ifelse(GT.long$barcode %in% colnames(GT.seve.wide), "batch1",
                   ifelse(GT.long$barcode %in% colnames(GT.wide), "batch2", NA))

## Saving data as a rsid file
saveRDS(GT.long, file = "250610_GT_long_annotated_file.rds")
GT.long <- readRDS(file = "250610_GT_long_annotated_file.rds")

#### Filtering for specifically PTPN2 and plotting frequency ####

# Loading in the data 
GT.long <- readRDS(file = "250610_GT_long_annotated_file.rds")

## filtering GT.long for ptpn2
# the filter
GT.ptpn2 <- GT.long %>% dplyr::filter(grepl("PTPN2", annot.symbol))
colnames(GT.ptpn2)

# cleaning up the data by making 0/1 and 1/0 so that they are the same
unique(GT.ptpn2$genotype)
GT.ptpn2 <- GT.ptpn2 %>%  mutate(genotype = if_else(genotype == "0|1", "1|0", genotype))


# Summarizing Ptpn2 snps frequencies and plotting as a stacked barplot 
Ptpn2_snp_summary <- GT.ptpn2 %>% group_by(Name, genotype) %>% summarise(count = n())
p <- ggplot(Ptpn2_snp_summary, aes(x=reorder(Name,count), y=count, fill=genotype)) + geom_bar(stat="identity") + theme_classic()
p <- p + labs(x = "Series", y ="Proportion",fill="Agent") #+ theme(legend.position = "none")
p <- p + theme(axis.text.x = element_text(angle=90,face="bold",size=12,color="black")) 
p <- p + theme(axis.text.y = element_text(face="bold",size=12,color="black")) 
p <- p + theme(strip.text = element_text(face = "bold",size=12,color="black")) 
p <- p + theme(axis.title = element_text(face = "bold",size = 12,color="black"))
p <- p + theme(legend.text = element_text(face = "bold",size=12,color="black"))
p <- p + theme(legend.title = element_text(face = "bold",size=12,color="black"))
p

#Plot faceted by batches
Ptpn2_snp_summary <- GT.ptpn2 %>% group_by(Name,batch,genotype) %>% summarise(count = n()) %>% mutate(percentage = count / sum(count) * 100)
p <- ggplot(Ptpn2_snp_summary, aes(x=batch, y=percentage, fill=genotype)) + geom_bar(stat="identity") + theme_classic()
p <- p + facet_wrap(~Name,ncol=15)
p <- p + labs(x = "Series", y ="Proportion",fill="Agent") #+ theme(legend.position = "none")
p <- p + theme(axis.text.x = element_text(angle=90,face="bold",size=12,color="black")) 
p <- p + theme(axis.text.y = element_text(face="bold",size=12,color="black")) 
p <- p + theme(strip.text = element_text(face = "bold",size=12,color="black")) 
p <- p + theme(axis.title = element_text(face = "bold",size = 12,color="black"))
p <- p + theme(legend.text = element_text(face = "bold",size=12,color="black"))
p <- p + theme(legend.title = element_text(face = "bold",size=12,color="black"))
p


#### The End ####