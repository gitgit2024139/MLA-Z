

aws s3 ls s3://abbvie-calico-aging-oncology-internal-us-east-1/dropoff/Calico/Clinical/PTPN2/Archived_M20-124/ --profile abbvie-Calico-aging-oncology-clinical