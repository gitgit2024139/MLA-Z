library(tidyverse)
library(dplyr)
library(readxl)
library(data.table)
library(Biobase)
library(genefilter)
library(Rtsne)
library(ggplot2)
library(gridExtra)
library(pheatmap)
library(gplots)
library(limma)
library(RColorBrewer)
library(reshape)
library(GSVA)
library(quantiseqr)
library(ComplexHeatmap)
library(lessR)

### filter to retain SetB and 0817_TN data when having overlaps for tumor analysis

#1. filelsit
allS3file_tumors <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/allS3files_0827.csv')

colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch245_colData_0903.csv')

TMB <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch245_TMB.csv') %>%
  filter(name =='SNVs') %>%
  merge(.,colData, by.x = 'Accession_number',by.y = 'Accession_number')

colData <- TMB

#read clinical sample shiping manifest, get paired tumor samples
manifest <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/M20_431_and_M20_124_Personalis_Shipment_Summary_6Aug2024_yz_mj.xlsx',
                               sheet = 3)%>%
  filter(Batch_Type != 'Gene Expression') %>% ##remove blood samples
  mutate(Accession_number = Accession_Number) %>%
  mutate(Accession_number = ifelse(nchar(Accession_number)==12,
                                   str_sub(Accession_number, end = -3),
                                   Accession_number)) %>%
  #filter(Cohort =='M20-431') %>% page 3 is M20-431 only
  filter(Mosaic_ID != 'N/A') %>%
  mutate(Accession_Number = parse_number(Accession_number)) %>%
  dplyr::select(-Annotation)

#2. filter wes files

matches_wes_report <- allS3file_tumors[grepl('rna_gene_expression_report',
                                             allS3file_tumors$filetype),] %>%
  filter(suffix == 'xlsx',pipeline == 'RNA')

##3 add metadata

final_list <- matches_wes_report %>% dplyr::select(filepath,filetype,Accession_number) %>%
  merge(.,colData,by.x = 'Accession_number',by.y = 'Accession_number'  )  %>%
  filter(Mosaic_ID != 'N/A')

final_list_edit <- final_list[order(final_list$Patient_ID,
                                    final_list$Treatment),]

final_list_edit <- final_list_edit %>% mutate(
  batchset = str_extract(filepath, 'Batch\\d(_\\w+)') %>%
    lapply(.,function(x) {head(strsplit(x, split = '_7')[[1]],1)[1]}) %>%
    unlist(),
  batchdate = str_extract(filepath, '\\d{4}_\\d{4}'),
  batchtotal = paste(batchset,batchdate,sep = '_')
)

test <- final_list_edit %>% group_by(Accession_number) %>%
  reframe(occurrance = paste(sort(unique(batchtotal)),collapse = '; '))

final_list_edit <- final_list_edit[grepl(paste(c('Batch2_Set_A__0812_2024',
                                                 'Batch2_SetB_0807_2024',
                                                 'Batch2_SetB_0809_2024',
                                                 'Batch4_0711_2024',
                                                 'Batch5_TN_0816_2024',
                                                 'Batch2_Set_A__0812_2024'),collapse = '|'),
                                         final_list_edit$batchtotal),]


##4. download gene expression reports from s3 by print bash command lines and run command lines in terminal

for (i in 1: length(final_list_edit$filepath)) {

  s3_loc <- final_list_edit$filepath[i]
  filename <- paste(final_list_edit$batchset[i], final_list_edit$filetype[i],sep = '_')

  cmd <- paste('aws s3 cp s3://abv-arrayserver/', s3_loc,
               ' --profile arrayserver /ui/abv/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorRNAexp/',
               filename,sep = '')

  write(cmd,file = '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/bash_cp_cmd.sh', append = T)

}

#7. rbind snv files
files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorRNAexp/',
                    pattern = 'xlsx',
                    full.names = T)

names(files) <- stringr::str_extract(basename(files), pattern = 'RNA_\\d{10}')

##counts
counts <- purrr::map_df(files, .f = read_excel, .id = "sample") %>% dplyr::select(1:4) %>%
  tidyr::pivot_wider(names_from = 1, values_from = 4 )

write.csv(counts, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_41tumors_rawCounts_0906.csv',
          row.names = F)

##tpm
tpm <- purrr::map_df(files, .f = read_excel, .id = "sample") %>% dplyr::select(1:3,7) %>%
  tidyr::pivot_wider(names_from = 1, values_from = 4 )

write.csv(tpm, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_41tumors_TPM_0906.csv',
          row.names = F)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

counts <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_41tumors_rawCounts_0906.csv')
tpm <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_41tumors_TPM_0906.csv')

colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch245_colData_0903.csv')

TMB <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch245_TMB.csv') %>%
  filter(name =='SNVs') %>% 
  merge(.,colData, by.x = 'Accession_number',by.y = 'Accession_number') 

colData <- TMB %>% mutate (Accession_Number = paste('RNA_',Accession_Number,sep = '')) %>%
  column_to_rownames('Accession_Number')


##Making diagnosis a little easier to work around from Kyle's code 20240912
colData$Diagnosis_edit <- colData$Diagnosis
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Breast Cancer (TNBC)", "Breast Cancer"))] <- "Breast"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("TNBC"))] <- "Breast"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Sigmoid colon cancer"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Adenocarcinoma of rectum", "Colon Cancer", "Colorectal Cancer"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Rectal Adenocarcinoma"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("MSI-H CRC"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("MSS CRC"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Malignant neoplasma of tonsil (HNSCC)"))] <- "HNSCC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Pancreatic Cancer"))] <- "Pancreatic"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Malignant Melanoma", "Melanoma"))] <- "Melanoma"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Soft Tissue Sarcoma", "Anaplastic Soft Tissue Sarcoma",
                                                            "Sarcoma", "Retropertioneal Synovial Sarcoma", "Chondrosarcoma",
                                                            "Clear Cell Sarcoma", "Myxoid Liposarcoma"))] <- "Sarcoma"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Urethral", "Urothelial Carcinoma"))] <- "Urothelial"
otherTmrs <- names(which(table(colData$Diagnosis_edit) <= 2))
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% otherTmrs)] <- "Other"

###############################################################################################
##1. load
###############################################################################################

##Loading RDS object with non-normalized counts and TPMs
counts
tpm
##Adding on pre/post for the two paired samples since that wasn't done in the 
colData <- colData[order(colData$Patient_ID, colData$Treatment),]
##expressionsets

tumorTPM <- ExpressionSet(assayData = tpm %>% dplyr::select(-1) %>% 
                            column_to_rownames('NCBI.Gene.ID') %>% 
                            dplyr::select(rownames(colData)) %>% as.matrix,
                          phenoData = AnnotatedDataFrame(colData),
                          featureData = AnnotatedDataFrame(
                            data.frame(symbol = tpm$Gene.Symbol, row.names = tpm$NCBI.Gene.ID))
)

##log2(+1) converting expression data for TPMs
exprs(tumorTPM) <- log2(exprs(tumorTPM) + 1)

# QC plots
#Plotting some QC plots prior to differential expression analysis. 

hist(rowMeans(exprs(tumorTPM)))

##Histogram of row vars
hist(rowVars(exprs(tumorTPM)))

#Potentially an outlier. Checking which genes are over 15. 

intGenes <- which(rowVars(exprs(tumorTPM)) > 15)
intGS <- fData(tumorTPM)$symbol[ which(featureNames(tumorTPM) %in% intGenes)]

print(intGS)


#Alright, some reasonable genes in there (H2BC3 in particular) but others
#not sure why variance so high. Will not exclude, but will monitor for inclusion
#in analysis down the road. 

# Sample distribution
# Now working on sample distribution, specifically to see what the sample-sample
# relationships are. 

## Sample expression tSNE

##Subsetting to variable and expressed genes
rnaTUSE <- exprs(tumorTPM)[ which(rowMeans(exprs(tumorTPM)) > 2.5 & 
                                  rowVars(exprs(tumorTPM)) > 0.15), ]

##Getting tsne together
set.seed(777)
tstTSNE <- Rtsne(t(rnaTUSE),
                 check_duplicates=FALSE,
                 pca=TRUE,
                 perplexity=2,
                 theta=0.5,
                 dims=2)

##Making a dataframe for plotting
tstTSNEDF <- as.data.frame(tstTSNE$Y)
tstTSNEDF$Patient_ID <- factor(tumorTPM$Patient_ID)
tstTSNEDF$Mosaic_ID <- factor(tumorTPM$Mosaic_ID)
tstTSNEDF$Treatment <- factor(tumorTPM$Treatment)
tstTSNEDF$Diagnosis <- factor(tumorTPM$Diagnosis_edit)
tstTSNEDF$batchset <- factor(tumorTPM$batchset)
tstTSNEDF$name <- factor(paste(tumorTPM$Patient_ID, tumorTPM$Diagnosis_edit, sep = '_'))


##Plotting
ggplot(data = tstTSNEDF, aes(x = V1, y = V2, col = Treatment, label = name)) +
  #geom_label(size = 4) + 
  ggrepel::geom_label_repel(size = 3,# aes(y = V2 - 5, label = Diagnosis)
                           ) + 
  geom_point(size = 3)+
  scale_x_continuous("tSNE X") +
  scale_y_continuous("tSNE Y") +
  scale_color_manual(values = c("Archival Pre" = "navy","Fresh Pre" = 'black', 
                                "On-Treatment" = "red")) + 
  theme_classic(base_size = 10) +
  theme(plot.title = element_text(hjust = 0.5)) 
#+ 
#  guides(color = guide_none())


##Saving plot
# pdf(file = "ptpn2i_m20_431_tsne_expression_2024-08-12.pdf",
#     paper = "special", 
#     width = 6.5,
#     height = 6)
# ggplotxxxxxx
# graphics.off()

## Heatmap of key genes

##Plotting some relevant genes
intGenes <- c("CD274", "CXCL9", "CXCL10", "IFNG", "GZMB", "PRF1", "CD3E", "CD4",
              "CD8A", "NKG7",'NKG2D','TRGV4','TRDV1', "KLRC1", "ARG1", "CLEC9A", "CD68", "CD163",
              "FOXP3", "CTLA4", "ICOS", "HAVCR2", "MKI67", "CENPA")

##Subsetting to only these genes
rnaLINT <- tumorTPM[ which(fData(tumorTPM)$symbol %in% intGenes), ]
rnaLINT$sample_label <- paste(rnaLINT$Patient_ID, rnaLINT$Treatment,sep = '_')

##Peeling off, subsetting annotation data
annoSS <- pData(rnaLINT) %>% dplyr::select(#"Patient_ID", #"Mosaic_ID", 
                                    "Diagnosis", "BOR", 
                                     # "Months on Treatment",
                                    'Treatment'
                                    #,'sample_label' 
                                    )

##Heatmap
ComplexHeatmap::pheatmap(exprs(rnaLINT[,rownames(colData[order(colData$Patient_ID,colData$Treatment),])]),
         labels_row = fData(rnaLINT)$symbol,
         labels_col = pData(rnaLINT)$sample_label,
         show_colnames = TRUE, 
         show_rownames = TRUE,
         annotation_colors = list(#"Diagnosis" =   c("HNSCC" = "magenta",
                                  #              "RCC" = "yellow"),
                                  "BOR" = c("CR" = "red",
                                            "PD" = "grey60",
                                            "SD" = "green",
                                            'NE' = 'black',
                                            'PR' = 'purple'),
                                  "Treatment" = c("Archival Pre" = "grey40","Fresh Pre" = 'grey', 
                                                  "On-Treatment" = "orange")),
         
         color = colorpanel(100, "blue", "white", "red"),
         scale = "row",
         clustering_distance_rows = "euclidean",
         clustering_method = "ward.D2",
         cluster_rows = T,
         cluster_cols = F,
         annotation_col = annoSS )

##Getting clustering
allClust <- hclust(dist(scale(t(exprs(rnaLINT)))), method = "ward.D2")

##assignments
clustAssign <- cutree(allClust, k = 4)

plot(allClust, labels = clustAssign)

# clustEdit <- clustAssign
# clustEdit[which(clustEdit %in% c(1,4))] <- "Inflamed"
# clustEdit[which(clustEdit == 2)] <- "Proliferative/Moderate"
# clustEdit[which(clustEdit == 3)] <- "Cold"

##Saving this real quick
# saveRDS(clustEdit, file = "../results/tme_assignments_2024-02-16.rds")


## Difference in key genes across pre/post samples

##Subsetting to only key genes for the paired samples
# rnaLPAIR <- rnaLINT[ , which(rnaLINT$Samp_ID %in% c("30012", "50007"))]

##Melting expression
rnaLPMELT <- as.data.frame(melt(exprs(rnaLINT), ))
colnames(rnaLPMELT) <- c("gene_id", "sample_id", "expression")

rnaLPMELT <- pData(rnaLINT) %>% rownames_to_column(var = 'sample_id') %>% 
  merge(.,rnaLPMELT) %>% merge(., fData(rnaLINT) %>% rownames_to_column('gene_id'))

## generate 2501 expression df and coldata
# rnaLINT <- tumorTPM
# rnaLPMELT <- as.data.frame(melt(exprs(rnaLINT), ))
# colnames(rnaLPMELT) <- c("gene_id", "sample_id", "expression")
# rnaLPMELT <- pData(rnaLINT) %>% rownames_to_column(var = 'sample_id') %>% 
#   merge(.,rnaLPMELT) %>% merge(., fData(rnaLINT) %>% rownames_to_column('gene_id'))
# 
# rnaLPMELT <- rnaLPMELT %>% filter(Patient_ID == '2501') %>% select(1:3,24:26)
# 
# expdf <- rnaLPMELT %>% select(2,5,6) %>% pivot_wider(names_from = 1, values_from = 2) 
# write.csv(expdf, 'CR_expression_TPM.csv')
# 
# metadf <- rnaLPMELT %>% select(2:4) %>% filter(!duplicated(sample_id))
# write.csv(metadf, 'CR_metadata.csv')


#Now plotting as barplots I guess for now. 

order <- c("MKI67", "CENPA","CD274","CTLA4","CXCL9", "CXCL10", "IFNG", "CD3E", "CD4",
              "CD8A", "NKG7",'NKG2D',"GZMB", "PRF1", "KLRC1", "CLEC9A", "CD68", "CD163","ARG1", 
              "FOXP3", "HAVCR2","ICOS")

ggplot(rnaLPMELT %>% mutate(symbol = factor(symbol,levels = order)), 
       aes(x = Treatment, y = expression, fill = Treatment)) +
  geom_bar(stat = "identity") + 
  facet_grid(Patient_ID ~ symbol) + 
  theme_bw(base_size = 10,base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0, "cm"), 
        axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
        legend.position = 'top',strip.background = element_rect(fill = 'white')) +
  labs(x = '', y = 'Expression log2(tpm + 1)', fill = '') 

#Looks quite good actually. Redoing, but with PTPN2-specific genes attached. 

##Plotting some relevant genes
intGenes <- c("PTPN1", "PTPN2", "JAK1", "JAK3", "STAT1", "STAT3", "STAT5A", "STAT5B")

##Subsetting to only these genes
rnaLINT <- tumorTPM[ which(fData(tumorTPM)$symbol %in% intGenes), ]

##Melting expression
rnaLPMELT <- as.data.frame(melt(exprs(rnaLINT), ))
colnames(rnaLPMELT) <- c("gene_id", "sample_id", "expression")

rnaLPMELT <- pData(rnaLINT) %>% rownames_to_column(var = 'sample_id') %>% 
  merge(.,rnaLPMELT) %>% merge(., fData(rnaLINT) %>% rownames_to_column('gene_id'))

##And plotting
ggplot(rnaLPMELT, aes(x = Treatment, y = expression, fill = Treatment)) +
  geom_bar(stat = "identity") + 
  facet_grid(Patient_ID ~ symbol) + 
  theme_bw(base_size = 10,base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0, "cm"), 
        axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
        legend.position = 'top',strip.background = element_rect(fill = 'white')) +
  labs(x = '', y = 'Expression log2(tpm + 1)', fill = '') 

##20240909 Plotting some relevant genes
intGenes <- c("ANKRD9", "TCF3", "RAP1GAP","ARG2")

##Subsetting to only these genes
rnaLINT <- tumorTPM[ which(fData(tumorTPM)$symbol %in% intGenes), ]

##Melting expression
rnaLPMELT <- as.data.frame(melt(exprs(rnaLINT), ))
colnames(rnaLPMELT) <- c("gene_id", "sample_id", "expression")

rnaLPMELT <- pData(rnaLINT) %>% rownames_to_column(var = 'sample_id') %>% 
  merge(.,rnaLPMELT) %>% merge(., fData(rnaLINT) %>% rownames_to_column('gene_id'))

##And plotting
ggplot(rnaLPMELT, aes(x = Treatment, y = expression)) +
  geom_boxplot(aes(fill = Treatment), alpha = .4)+
  geom_line(aes(group = Patient_ID),linetype = 2) + 
  geom_point(size=2,shape = 21, aes(fill = Treatment)) +
  facet_wrap(~ symbol,nrow = 1) + 
  theme_bw(base_size = 10,base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0, "cm"), 
        axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
        legend.position = 'right',strip.background = element_rect(fill = 'white')) +
  labs(x = '', y = 'Expression (log2 TPM + 1)', fill = '') 


# Gene set analysis
## Gene set scoring for sample TME composition
#First calculating TME composition via gene set scores from IO Atlas project. 
#Doing this as a quick first-pass for composition. 

##Relabeling featureNames
rnaETPM <- tumorTPM
rnaETPM <- rnaETPM[ duplicated(fData(rnaETPM)$symbol) == FALSE, ]
featureNames(rnaETPM) <- fData(rnaETPM)$symbol

##Loading gene sets
#library(qusage)
#geneList <-qusage::read.gmt('modules_plus_singletons_01052023_rename.gmt')
#saveRDS(geneList,'modules_plus_singletons_01052023_rename.rds')
#geneList <-qusage::read.gmt('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/core_modules_01052023_rename.gmt')
#saveRDS(geneList,'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/core_modules_01052023_rename.rds')

geneList <- readRDS('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/core_modules_01052023_rename.rds')

##Filtering
gLUSE <- GSVA::filterGeneSets(geneList, 
                        min.sz = 3, 
                        max.sz = 500)

##Scoring via ssGSEA
allRES <- gsva(expr = exprs(rnaETPM), 
               gset.idx.list = gLUSE,
               method = "ssgsea", 
               ssgsea.norm = F)



#Some jank in there, but seems to have run fine. 

saveRDS(allRES, file = "~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/results/core_geneset_gsva_41tumors.rds")

## Heatmap of gene sets
#Going to use prior heatmap ordering here, with a subset of gene sets. 

##Peeling off, subsetting annotation data
annoFULL <- pData(rnaETPM)
annoSS <- annoFULL %>% dplyr::select(#"Patient_ID", #"Mosaic_ID", 
  "Diagnosis", "BOR", 
  # "Months on Treatment",
  'Treatment' )

##Heatmap
pheatmap(allRES,
         labels_col = paste(annoFULL$Patient_ID, annoFULL$Treatment,sep="_"),
         show_colnames = TRUE, 
         show_rownames = TRUE,
         annotation_colors = list(#"Diagnosis" =   c("HNSCC" = "magenta",
                                  #                  "RCC" = "yellow"),
                                  "BOR" = c("CR" = "red",
                                            "PD" = "grey60",
                                            "SD" = "green",
                                            'NE' = 'black',
                                            'PR' = 'purple'),
                                  "Treatment" = c("Archival Pre" = "grey40","Fresh Pre" = 'grey', 
                                                  "On-Treatment" = "orange")),
         
         color = colorpanel(100, "blue", "white", "red"),
         scale = "row",
         cluster_cols = FALSE,
         clustering_distance_rows = "euclidean",
         clustering_method = "ward.D2",
         annotation_col = annoSS)

#corresponds well with the gene-level visualization. Going to save this as well. 

############# all gene sets
##Heatmap
geneList <- readRDS('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/modules_plus_singletons_01052023_rename.rds')
gLUSE <- GSVA::filterGeneSets(geneList, 
                              min.sz = 3, 
                              max.sz = 500)

##Scoring via ssGSEA
allRES <- gsva(expr = exprs(rnaETPM), 
               gset.idx.list = gLUSE,
               method = "ssgsea", 
               ssgsea.norm = F)

saveRDS(allRES, file = "~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/results/all_geneset_gsva_41tumors.rds")

annoFULL <- pData(rnaETPM)
annoSS <- annoFULL %>% select(#"Patient_ID", #"Mosaic_ID", 
                              "Diagnosis", "BOR", 
                              # "Months on Treatment",
                              'Treatment')

##Heatmap
pheatmap(allRES,
         labels_col = paste(annoFULL$Patient_ID, annoFULL$Treatment,sep="_"),
         show_colnames = TRUE, 
         show_rownames = TRUE,
         annotation_colors = list(#"Diagnosis" =   c("HNSCC" = "magenta",
                                  #                  "RCC" = "yellow"),
                                  "BOR" = c("CR" = "red",
                                            "PD" = "grey60",
                                            "SD" = "green",
                                            'NE' = 'black',
                                            'PR' = 'purple'),
                                  "Treatment" = c("Archival Pre" = "grey40","Fresh Pre" = 'grey', 
                                                  "On-Treatment" = "orange")),
         
         color = colorpanel(100, "blue", "white", "red"),
         scale = "row",
         cluster_cols = FALSE,
         clustering_distance_rows = "euclidean",
         clustering_method = "ward.D2",
         annotation_col = annoSS)

#corresponds well with the gene-level visualization. Going to save this as well. 

##########################
## using quantiseqr to deconvolute cell type composition in bulkRNAsq
library(AnnotationDbi)
library(org.Hs.eg.db)

#an ExpressionSet object (from the Biobase package), where the HGNC
#gene symbols are provided in a column of the fData slot - that is specified
#by the column parameter below

##checked no duplicated genes
tpm <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_41tumors_TPM_0906.csv') 
duplicated(rownames(tpm)) %>% sum()

colData <- read.csv('Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch245_colData_0903.csv') %>%
  mutate(complexname = paste(Patient_ID, Treatment, BOR,sep = '_'))

TMB <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch245_TMB.csv') %>%
  filter(name =='SNVs') %>% 
  merge(.,colData, by.x = 'Accession_number',by.y = 'Accession_number') 

colData <- TMB %>% mutate (Accession_Number = paste('RNA_',Accession_Number,sep = '')) %>%
  column_to_rownames('Accession_Number') %>%
  mutate(accession = paste('RNA_',Accession_number,sep = ''))


## try annotationdb 
columns(org.Hs.eg.db)
keytypes(org.Hs.eg.db)

annots <- select(org.Hs.eg.db, keys=tpm$NCBI.Gene.ID %>% as.character(),
                 columns=c("SYMBOL",'ENTREZID'), keytype="ENTREZID")
  
resultTable <- merge(annots,tpm, by.x="ENTREZID", by.y=2)

# entrezID matches with NCBI id
all(annots$ENTREZID %in% tpm$NCBI.Gene.ID)
#[1] TRUE

#but symbol doesn't match gene symbol in all cases
all(resultTable$SYMBOL %in% resultTable$`Gene Symbol`)
#[1] FALSE

# no symbol genes from annotationdbi
test <- resultTable %>% filter(is.na(resultTable$SYMBOL))
dim(test)[1]

exprTPM <- resultTable %>% filter(!is.na(resultTable$SYMBOL)) %>% 
  column_to_rownames('SYMBOL') %>% dplyr::select(-c(1:2))

colnam<- merge(data.frame(col = colnames(exprTPM)), 
                                       colData,
               by.x = 'col', by.y = 'accession') %>%
  arrange(complexname)

exprTPM <- exprTPM[,colnam$col]
#colnames(exprTPM) <- colnam$complexname

composition <- quantiseqr::run_quantiseq(
  expression_data = exprTPM,
  signature_matrix = "TIL10",
  is_arraydata = FALSE,
  is_tumordata = TRUE,
  scale_mRNA = TRUE,
  column = 'symbol'
)

quantiplot(composition)

## use ggplot for cell composition, remove Other cells

composition_gg <- composition %>% pivot_longer(cols = 2:12) %>% 
  filter(name != 'Other') %>%
  dplyr::rename('cell_type' = 'name', 'Fraction' = 'value') %>%
  merge(.,colData, by.x = 'Sample', by.y = 'accession')

composition_gg %>% ggplot(aes(x = Treatment, y = Fraction, fill=cell_type)) +
  geom_bar(stat = 'identity',color='black') +
  facet_wrap(~Patient_ID ,nrow = 2,scales = 'free_x') +
  scale_fill_brewer(palette = "Paired") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_text(angle = 90),
        strip.background = element_rect(fill = 'white')) +
  labs(x='')
  
#PART2 TCR clonality ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~``

#1. filelsit
allS3file_tumors <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/allS3files_0827.csv')

#read clinical sample shiping manifest, get paired tumor samples
colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch245_41tumor_colData_0909.csv')
  
matches_wes_report <- allS3file_tumors[grepl('tcr', allS3file_tumors$filetype),] %>%
  filter(suffix == 'xlsx')

##3 add metadata

final_list <- matches_wes_report %>% dplyr::select(filepath,filetype,Accession_number) %>% 
  merge(.,colData,by.x = 'Accession_number',by.y = 'Accession_number'  )  %>% 
  filter(Mosaic_ID != 'N/A')

final_list_edit <- final_list[order(final_list$Patient_ID, 
                                    final_list$Treatment),]

final_list_edit <- final_list_edit[grepl('beta', final_list_edit$filetype),]

final_list_edit <- final_list_edit %>% mutate(
  batchset = str_extract(filepath, 'Batch\\d(_\\w+)') %>% 
    lapply(.,function(x) {head(strsplit(x, split = '_7')[[1]],1)[1]}) %>%
    unlist(),
  batchdate = str_extract(filepath, '\\d{4}_\\d{4}'),
  batchtotal = paste(batchset,batchdate,sep = '_')
)

test <- final_list_edit %>% group_by(Accession_number) %>% 
  reframe(occurrance = paste(sort(unique(batchtotal)),collapse = '; '))

final_list_edit <- final_list_edit[grepl(paste(c('Batch2_Set_A__0812_2024',
                                                 'Batch2_SetB_0807_2024',
                                                 'Batch2_SetB_0809_2024', 
                                                 'Batch4_0711_2024',
                                                 'Batch5_TN_0816_2024',
                                                 'Batch2_Set_A__0812_2024'),collapse = '|'), 
                                         final_list_edit$batchtotal),]

##4. download gene expression reports from s3 by print bash command lines and run command lines in terminal

for (i in 1: length(final_list_edit$filepath)) {
  
  s3_loc <- final_list_edit$filepath[i]
  filename <- paste(final_list_edit$batchset[i], final_list_edit$filetype[i],sep = '_')
  
  cmd <- paste('aws s3 cp s3://abv-arrayserver/', s3_loc, 
               ' --profile arrayserver /ui/abv/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorTCRclone/', 
               filename,sep = '')
  
  write(cmd,file = '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/bash_cp_cmd_tcr.sh', append = T)
  
}

##5. downlaod files from s3 to HPC from command line

##6. TCR clonality counts
# TCR both chains
files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorTCRclone/',
                    pattern = 'beta',
                    full.names = T)

names(files) <- stringr::str_extract(basename(files), pattern = '\\d{10}')

##counts
counts <- purrr::map_df(files, .f = read_excel, .id = "sample")

write.csv(counts, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_41tumors_TCRbetaCount_0827.csv',
          row.names = F)

###############################################################################################
#1. clone proportion
###############################################################################################
counts <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_41tumors_TCRbetaCount_0827.csv')
colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch245_41tumor_colData_0909.csv')

#working table
counts_tcr <- merge(counts, colData, by.x = 'sample','Accession_number')
counts_tcr <- within(counts_tcr, quartile_group <- #as.integer #will change quantile cut value to 1:4 category value
                       (cut(Clone.Count, 
                            quantile(Clone.Count, probs=0:4/4), 
                            include.lowest=TRUE))) %>%
  mutate(chain = str_extract(Top.J.Hits,'TR[AB]')) 

counts_tcr %>% mutate(name = paste(Patient_ID,Treatment,sep = '_')) %>% 
  ggplot(aes(x = name, fill=quartile_group)) +
  geom_bar(stat = 'count',position = 'fill')+
  facet_wrap(~BOR,nrow=2,scales = 'free_x') +
  scale_fill_brewer(palette = "Paired") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_text(angle = 90),
        strip.background = element_rect(fill = 'white')) +
  labs(x='',fill = 'Clone Counts', y = 'Occupied repertoire space') + 
  scale_y_continuous(labels = scales::percent_format(accuracy = 1))

##number of clones pre and post treatment per patient

counts_tcr %>% mutate(name = paste(Patient_ID,Treatment,sep = '_')) %>% 
  group_by(name, Treatment, Patient_ID,BOR) %>% 
  reframe(numbers = n()) %>% 
  ggplot(aes(x = name,y=numbers, fill=Treatment)) +
  geom_bar(stat = 'identity')+
  facet_wrap(~BOR,nrow=2,scales = 'free_x') +
  scale_fill_brewer(palette = "Set2") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_text(angle = 90),
        strip.background = element_rect(fill = 'white')) +
  labs(x='',fill = '', y = 'Clone numbers') 

###############################################################################################
#2 number of clones association with BOR
###############################################################################################

df <- counts_tcr %>% left_join(., counts_tcr %>% group_by(sample)
                               %>% summarise(Number_of_Clones = n()))

library(ggpubr)

ggboxplot(df%>%group_by(sample,Number_of_Clones,BOR,Treatment,chain,batchset) %>%
            summarise(n()) %>% filter(chain == 'TRB'), 
          x = 'BOR', y = 'Number_of_Clones',color = 'Treatment', add = 'jitter',
          add.params = list(size=.7,alpha = .2, color = 'black')) +
  #facet_wrap(~chain) +
  stat_compare_means(comparisons = list(c('PD','CR','SD')), method = 'wilcox.test',
                     label = 'p.signif') +
  #scale_color_brewer(palette = "Spectral") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_text(angle = 90),
        strip.background = element_rect(fill = 'white')) +
  labs(x='') 


###############################################################################################
#3. clonal tracking
###############################################################################################
library(ggalluvial)

counts <- counts_tcr %>% 
  filter(Treatment != 'Archival Pre') 

counts <- counts %>%
  group_by(sample) %>% 
  mutate(Rank = order(order(Clone.Count, decreasing = T))) %>% 
  ungroup()


## only keep overlaps,
df_tracking <- counts %>% 
  group_by(Patient_ID,Clonal.Sequence) %>%
  reframe(occurrance = paste(unique(Treatment), collapse = ';'),
          time = n()) %>%
  filter(!(occurrance %in% c('Fresh Pre', 'On-Treatment')))

##get top15 overlapped pre treatment clonotype reads, only consider counts > 5
counts_tracking <- counts %>% 
  filter(Clonal.Sequence %in% df_tracking$Clonal.Sequence) %>%
  filter(Treatment == 'Fresh Pre') %>% 
  filter(Clone.Count > 4) %>%
  filter(Rank < 16)

pltlist <- list()

for (pat in unique(counts_tracking$Patient_ID)) {
  
  counts_final <- counts %>% 
    filter(Patient_ID == pat )%>% 
    filter(Clonal.Sequence %in% counts_tracking$Clonal.Sequence) %>%
    dplyr::select(Patient_ID,batchset,Clonal.Sequence,Clone.Frequency,Treatment,Rank)
  
  pltlist [[paste0(pat)]] <- ggplot(counts_final %>%  mutate(subject = Clonal.Sequence),
                                    aes(x = Treatment, y = Clone.Frequency ,fill = Clonal.Sequence ,
                                        label = Clonal.Sequence,
                                        stratum = Clonal.Sequence,
                                        alluvium = Clonal.Sequence)) +
    geom_flow() +
    geom_stratum(alpha = .5) +
    theme_bw(base_line_size = 0,base_rect_size = 1) +
    theme(panel.spacing = unit(0.1, "cm"),
          axis.text.x = element_text(angle = 90),
          strip.background = element_rect(fill = 'white'),
          legend.position = 'none') +
    labs(x='')  +
    facet_wrap(~Patient_ID,nrow = 2)
}

gridExtra::grid.arrange(grobs = pltlist,ncol=6)

#install.packages('Polychrome')
library(Polychrome)

# manualcolors<-c('black','forestgreen', 'red2', 'orange', 'cornflowerblue', 
# 'magenta', 'darkolivegreen4', 'indianred1', 'tan4', 'darkblue', 
# 'mediumorchid1','firebrick4',  'yellowgreen', 'lightsalmon', 'tan3',
# "tan1",'darkgray', 'wheat4', '#DDAD4B', 'chartreuse', 
# 'seagreen1', 'moccasin', 'mediumvioletred', 'seagreen','cadetblue1',
# "darkolivegreen1" ,"tan2" ,   "tomato3" , "#7CE3D8","gainsboro")

#https://www.color-hex.com/color/ff00ff

#color solution 1
# create your own color palette (50 colors) based on `seedcolors`
P50 = createPalette(45,  #c('black','forestgreen', 'red2', 'orange', 'cornflowerblue')
                    c('#E066FF',"#8B1A1A","#9ACD32","#ffa07a",'#6495ED','#7CE3D8'))
swatch(P50)


# color solution 2

library(RColorBrewer)
# Define the number of colors you want
nb.cols <- 45
mycolors <- colorRampPalette(brewer.pal(11, "Spectral"))(nb.cols)


#20240909 BCR for41 tumors ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#1. filelsit
allS3file_tumors <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/allS3files_0827.csv')
colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch245_41tumor_colData_0909.csv')
#filter gene expression report
matches_bcr_report <- allS3file_tumors[grepl('bcr_heavy', allS3file_tumors$filetype),] %>%
  filter(suffix == 'xlsx')

final_list <- matches_bcr_report %>% dplyr::select(filepath,filetype,Accession_number) %>% 
  merge(.,colData,by.x = 'Accession_number',by.y = 'Accession_number'  )  %>% 
  filter(Mosaic_ID != 'N/A')

final_list_edit <- final_list[order(final_list$Patient_ID, 
                                    final_list$Treatment),]

final_list_edit <- final_list_edit %>% mutate(
  batchset = str_extract(filepath, 'Batch\\d(_\\w+)') %>% 
    lapply(.,function(x) {head(strsplit(x, split = '_7')[[1]],1)[1]}) %>%
    unlist(),
  batchdate = str_extract(filepath, '\\d{4}_\\d{4}'),
  batchtotal = paste(batchset,batchdate,sep = '_')
)

test <- final_list_edit %>% group_by(Accession_number) %>% 
  reframe(occurrance = paste(sort(unique(batchtotal)),collapse = '; '))

final_list_edit <- final_list_edit[grepl(paste(c('Batch2_Set_A__0812_2024',
                                                 'Batch2_SetB_0807_2024',
                                                 'Batch2_SetB_0809_2024', 
                                                 'Batch4_0711_2024',
                                                 'Batch5_TN_0816_2024',
                                                 'Batch2_Set_A__0812_2024'),collapse = '|'), 
                                         final_list_edit$batchtotal),]

##4. download gene expression reports from s3 by print bash command lines and run command lines in terminal

for (i in 1: length(final_list_edit$filepath)) {
  
  s3_loc <- final_list_edit$filepath[i]
  filename <- paste(final_list_edit$batchset[i], final_list_edit$filetype[i],sep = '_')
  
  cmd <- paste('aws s3 cp s3://abv-arrayserver/', s3_loc, 
               ' --profile arrayserver /ui/abv/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorBCRclone/', 
               filename,sep = '')
  
  write(cmd,file = '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/bash_cp_cmd_bcr.sh', append = T)
  
}

##5. downlaod files from s3 to HPC from command line

##6. TCR clonality counts
# TCR both chains
files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorBCRclone/',
                    pattern = 'heavy_chain',
                    full.names = T)

names(files) <- stringr::str_extract(basename(files), pattern = '\\d{10}')

##counts
counts <- purrr::map_df(files, .f = read_excel, .id = "sample")

write.csv(counts, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_41tumors_BCRCount_0909.csv',
          row.names = F)

###############################################################################################
#1. clone proportion
###############################################################################################
counts <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_BCRbetaCount_0827.csv')
colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_colData_0827.csv')

#working table
counts_bcr <- merge(counts, colData, by.x = 'sample','accession')
counts_bcr <- within(counts_bcr, quartile_group <- #as.integer #will change quantile cut value to 1:4 category value
                       (cut(Clone.Count, 
                            quantile(Clone.Count, probs=0:4/4), 
                            include.lowest=TRUE))) %>%
  mutate(chain = Isotype) %>%
  filter(Isotype != 'undetermined') %>%
  mutate(xlabel2 = paste(Isotype,Treatment,Patient_ID,batchset))

## BCR occupation
counts_bcr %>%
  ggplot(aes(x = xlabel2,fill = quartile_group)) +
  geom_bar(stat = 'count',position = 'fill')+
  scale_y_continuous(expand=c(0,0.05))+
  facet_wrap(~Patient_ID + batchset,
             nrow = 2,
             scales = "free_x") +
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_text(angle = 90,size = 7),
        strip.background = element_rect(fill = 'white')) +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  labs(x='',fill = 'Clone Counts', y = 'Occupied repertoire space')

## delete batchset layer 

counts_bcr <- counts_bcr %>%
  dplyr::filter(batchset %in% c('Batch2_SetB', 'Batch4','Batch5_TN'))
# 
# counts_bcr %>% 
#   ggplot(aes(x = xlabel2,fill = quartile_group)) +
#   geom_bar(stat = 'count',position = 'fill') +
#   scale_y_continuous(expand=c(0,0.05))+
#   facet_wrap(~Patient_ID + Treatment,
#              ncol = 6,
#              scales = "free_x") +
#   theme(panel.spacing = unit(0.1, "cm"),
#         axis.text.x = element_text(angle = 0,size = 7),
#         strip.background = element_rect(fill = 'white')) +
#   scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
#   labs(x='',fill = 'Clone Counts', y = 'Occupied repertoire space') +
#   scale_x_discrete(labels = counts_bcr$Isotype)


pltlist <- list()

for (pat in unique(counts_bcr$Isotype)) {
  
  counts_final <- counts_bcr %>% 
    filter(Isotype == pat )
  
  pltlist [[paste0(pat)]] <- counts_final %>% 
    ggplot(aes(x = Treatment,fill = quartile_group)) +
    geom_bar(stat = 'count',position = 'fill') +
    scale_y_continuous(expand=c(0,0.05))+
    facet_wrap(~Patient_ID + Isotype,
               ncol = 6,
               scales = "free_x") +
    theme_bw(base_line_size = 0,base_rect_size = 1) + 
    theme(panel.spacing = unit(0.1, "cm"),
          axis.text.x = element_text(angle = 90,size = 7),
          strip.background = element_rect(fill = 'white')) +
    scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
    labs(x='',fill = 'Clone Counts', y = 'Occupied repertoire space') 
}

gridExtra::grid.arrange(grobs = pltlist,ncol=2)


##number of clones pre and post treatment per patient

df <- counts_bcr %>% group_by(sample, Treatment, Patient_ID,batchset) %>% 
  reframe(numbers = n())

df %>% ggplot(aes(x = Treatment,y=numbers, fill=Treatment)) +
  geom_bar(stat = 'identity')+
  facet_wrap(~Patient_ID+batchset,nrow=2,scales = 'free_x') +
  scale_fill_brewer(palette = "Set2") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_text(angle = 90),
        strip.background = element_rect(fill = 'white')) +
  labs(x='',fill = '', y = 'Clone numbers') 

###############################################################################################
#2 number of clones association with BOR
###############################################################################################

df <- counts_bcr %>% left_join(., counts_bcr %>% group_by(sample)
                               %>% summarise(Number_of_Clones = n()))

library(ggpubr)

ggboxplot(df%>%group_by(sample,Number_of_Clones,BOR,Treatment,chain,batchset) %>%
            summarise(n()) , 
          x = 'BOR', y = 'Number_of_Clones',color = 'Treatment', add = 'jitter',
          add.params = list(size=.7,alpha = .2, color = 'black')) +
  #facet_wrap(~chain) +
  stat_compare_means(comparisons = list(c('PD','CR','SD')), method = 'wilcox.test',
                     label = 'p.signif') +
  #scale_color_brewer(palette = "Spectral") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_text(angle = 90),
        strip.background = element_rect(fill = 'white')) +
  labs(x='') 


###############################################################################################
#3. clonal tracking
###############################################################################################
library(ggalluvial)

##option1
counts <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_BCRbetaCount_0827.csv')
colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_colData_0827.csv')

counts <- merge(counts, colData, by.x = 'sample', by.y = 'accession') %>% 
  filter(Treatment != 'Archival Pre') 

counts <- counts %>%
  group_by(sample,Isotype) %>% 
  mutate(Rank = order(order(Clone.Count, decreasing = T))) %>% 
  ungroup()


## only keep overlaps,
df_tracking <- counts %>% 
  group_by(Patient_ID,Isotype,CDR3.Clonal.Sequence) %>%
  reframe(occurrance = paste(unique(Treatment), collapse = ';'),
          time = n()) %>%
  filter(!(occurrance %in% c('Fresh Pre', 'On-Treatment'))) %>% 
  filter(Isotype != 'undetermined')

##get top15 overlapped pre treatment clonotype reads, only consider counts > 5
counts_tracking <- counts %>% 
  filter(CDR3.Clonal.Sequence %in% df_tracking$CDR3.Clonal.Sequence) %>%
  filter(Treatment == 'Fresh Pre') %>% 
  filter(Clone.Count > 4) %>%
  filter(Rank < 16)




pltlist <- list()

for (pat in unique(counts_tracking$Patient_ID)) {
  
  counts_final <- counts %>% 
    filter(Patient_ID == pat)%>% 
    filter(CDR3.Clonal.Sequence %in% counts_tracking$CDR3.Clonal.Sequence) %>%
    dplyr::select(Patient_ID,Isotype,batchset,CDR3.Clonal.Sequence,Isotype.Specific.Clone.Frequency,Treatment,Rank) %>%
    dplyr::filter(batchset %in% c('Batch2_SetB', 'Batch4','Batch5_TN')) %>%
    filter(Isotype != 'undetermined')
  
  pltlist [[paste0(pat)]] <- ggplot(counts_final %>%  mutate(subject = CDR3.Clonal.Sequence),
                                    aes(x = Treatment, y = Isotype.Specific.Clone.Frequency ,fill = CDR3.Clonal.Sequence ,
                                        label = CDR3.Clonal.Sequence,
                                        stratum = CDR3.Clonal.Sequence,
                                        alluvium = CDR3.Clonal.Sequence)) +
    geom_flow() +
    geom_stratum(alpha = .5) +
    theme_bw(base_line_size = 0,base_rect_size = 1) +
    theme(panel.spacing = unit(0.1, "cm"),
          axis.text.x = element_text(angle = 90),
          strip.background = element_rect(fill = 'white'),
          legend.position = 'none') +
    labs(x='',y = 'Clone.Frequency')  +
    facet_wrap(~Patient_ID+batchset+Isotype,nrow = 1)
}

gridExtra::grid.arrange(grobs = pltlist,ncol=2)

#install.packages('Polychrome')
library(Polychrome)

# manualcolors<-c('black','forestgreen', 'red2', 'orange', 'cornflowerblue', 
# 'magenta', 'darkolivegreen4', 'indianred1', 'tan4', 'darkblue', 
# 'mediumorchid1','firebrick4',  'yellowgreen', 'lightsalmon', 'tan3',
# "tan1",'darkgray', 'wheat4', '#DDAD4B', 'chartreuse', 
# 'seagreen1', 'moccasin', 'mediumvioletred', 'seagreen','cadetblue1',
# "darkolivegreen1" ,"tan2" ,   "tomato3" , "#7CE3D8","gainsboro")

#https://www.color-hex.com/color/ff00ff


# create your own color palette (50 colors) based on `seedcolors`
P50 = createPalette(45,  #c('black','forestgreen', 'red2', 'orange', 'cornflowerblue')
                    c('#E066FF',"#8B1A1A","#9ACD32","#ffa07a",'#6495ED','#7CE3D8'))
swatch(P50)


# counts %>% filter(Clonal.Sequence %in% counts_tracking$Clonal.Sequence) %>%
#   dplyr::select(Patient_ID,batchset,Clonal.Sequence,Clone.Frequency,Treatment,Rank) %>%  
#   mutate(subject = Clonal.Sequence) %>%
#   ggplot(aes(x = Treatment, y = Clone.Frequency ,
#                            fill = Clonal.Sequence ,
#                            label = Clonal.Sequence,
#                            stratum = Clonal.Sequence,
#                            alluvium = Clonal.Sequence,
#                            )) +
#   geom_flow() +
#   geom_stratum(alpha = .5) +
#   theme_bw(base_line_size = 0,base_rect_size = 1) +
#   theme(panel.spacing = unit(0.1, "cm"),
#         axis.text.x = element_text(angle = 90),
#         strip.background = element_rect(fill = 'white'),
#         legend.position = 'none') +
#   labs(x='')  +
#   facet_wrap(~Patient_ID+batchset,nrow = 2)+
#   scale_fill_manual(values = P50)

# color solution 2

library(RColorBrewer)
# Define the number of colors you want
nb.cols <- 45
mycolors <- colorRampPalette(brewer.pal(11, "Spectral"))(nb.cols)





















