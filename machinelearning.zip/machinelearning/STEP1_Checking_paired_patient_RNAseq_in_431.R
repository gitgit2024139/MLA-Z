library(dplyr)
library(data.table)
library(tidyr)
library(readxl)
library(stringr)

##aws s3 ls s3://abv-arrayserver/CloudDataRoot/Oncology/Clinical/personalis/M20-431/ 
##--profile arrayserver --recursive --human-readable --summarize > filenames_431.txt
## updated all files filenames_431_0823.txt
file_431 <- read.table('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/filenames_431_0823.txt',
                       sep = '\t') %>% 
  separate(V1, into = c('v1','filepath'), sep = 'CloudDataRoot') %>% 
  mutate(filepath = paste('CloudDataRoot',filepath,sep = ''))

#read clinical sample shiping manifest, get paired tumor samples
manifest <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/ptpn2i_shipment_manifest.xlsx', 
                               sheet = 4) %>% 
  dplyr::filter(Patient_ID %in% c( '2203','2204','2207','2209','2501','2801')) %>% 
  filter(Batch_Type != 'Gene Expression') 

manifest_order <- manifest[order(manifest$Patient_ID,manifest$Sample_Type),] %>% 
  mutate(Accession_number = Accession_Number) %>%
  separate(Accession_number, c('Accession_number','suffix'),sep = '27')

matches <- file_431[grepl(paste(manifest_order$Accession_number, collapse="|"), 
                          file_431$filepath), ] %>%
  mutate(filetype = lapply(filepath, function(x) {tail(strsplit(x,split = '/')[[1]], 1)}
  ) %>% unlist(),
  suffix = lapply(filetype, function(x) {tail(strsplit(x,split = '\\.')[[1]], 1)}
  ) %>% unlist(),
  
  pipeline = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 1)}
  ) %>% unlist(),
  
  Accession_number = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 2)[2]}
  ) %>% unlist()
  )

##save 6 tumor pairs all type files

write.csv(matches, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/allS3files_6tumorpairs_0827.csv',row.names = F)

#filter non gene pipelines files
matches_rna <- matches %>% 
  filter(suffix == 'xlsx', pipeline == 'RNA') 

#filter gene expression report
matches_exp_report <- matches_rna[grepl('rna_gene_expression_report', matches_rna$filetype),]

## add metadata

final_list <- matches_exp_report %>% select(filepath,filetype,Accession_number) %>% 
  right_join(manifest_order %>% select(-c('suffix','Annotation'))) 

#final_list <-  mutate_if( final_list, is.numeric, as.integer)

#write.csv(final_list, 'expression_filelist_6_tumor_pairs.csv')

## confirm with Kyle to remove no mosaic ID samples

final_list_edit <- final_list %>% filter(Mosaic_ID != 'N/A')
final_list_edit <- final_list_edit[order(final_list_edit$Patient_ID, 
                                         final_list_edit$Accession_number),] 

final_list_edit <- final_list_edit %>% 
  
  mutate(
  #   name6 = lapply(filepath, function(x) {head(strsplit(x,split = '/')[[1]], 6)[6]}
  # ) %>% unlist(),
  # name7 =  lapply(filepath, function(x) {head(strsplit(x,split = '/')[[1]], 7)[7]}
  # ) %>% unlist()
  
    batchset = str_extract(filepath, 'Batch\\d(_\\w+)') %>% 
      lapply(.,function(x) {head(strsplit(x, split = '_7')[[1]],1)[1]}) %>%
      unlist()
    )


write.table(final_list_edit%>%select(-c(1:3)),
            '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_pairs_metadata_0827.txt',
            quote = F, sep = '\t',row.names = F)

## 3 sample with missing expression report
#missing <- manifest_order[!(manifest_order$Accession_number %in% matches_rna$Anumber),]

##4. download gene expression reports from s3 by print bash command lines and run command lines in terminal

for (i in 1: length(final_list_edit$filepath)) {

  s3_loc <- final_list_edit$filepath[i]
  filename <- paste(final_list_edit$batchset[i], final_list_edit$filetype[i],sep = '_')
  
  cmd <- paste('aws s3 cp s3://abv-arrayserver/', s3_loc, 
               ' --profile arrayserver /ui/abv/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorRNAexp/',
               filename, sep = '')
  
  write(cmd,file = '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/bash_cp_cmd.sh', append = T)
  
}

##5. extract count reads from each sample

files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorRNAexp/',
                    pattern = 'xlsx',full.names = T)

names(files) <- stringr::str_split(basename(files), pattern = '_tumor',simplify = T)[,1]

##counts
counts <- purrr::map_df(files, .f = read_excel, .id = "sample") %>% select(1:4) %>%
  tidyr::pivot_wider(names_from = 1, values_from = 4 )

write.csv(counts, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_rawCounts_0827.csv',
          row.names = F)
##tpm
tpm <- purrr::map_df(files, .f = read_excel, .id = "sample") %>% select(1:3,7) %>%
  tidyr::pivot_wider(names_from = 1, values_from = 4 )

write.csv(tpm, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_TPM_0827.csv',
          row.names = F)


##colData

clinical <- read_excel(paste('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/',
                              'PTPN2_Clinical_Metadata_08JUL24_Final.xlsx',sep=''),sheet = 4)
tumor_pairs <- fread('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_pairs_metadata_0827.txt') 
treatment <- fread('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/Book2.txt')


colData <- merge(tumor_pairs, clinical, by.x=c('Patient_ID'), by.y=c('Subject ID')) %>%
  left_join(.,treatment)%>% 
  mutate(accession = paste(batchset,'_RNA_',Accession_Number,sep = '')) %>%
  merge(.,data.frame(accession = colnames(counts[,-1])), by = 'accession')%>%
  arrange(Patient_ID,Treatment) %>%
  mutate(sample_lable = paste(Patient_ID, batchset, sep = '_'))

write.csv(colData, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_colData_0827.csv',
          row.names = F)






