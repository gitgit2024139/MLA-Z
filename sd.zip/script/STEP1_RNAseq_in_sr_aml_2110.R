library(tidyverse)
library(dplyr)
library(readxl)
library(data.table)
library(Biobase)
library(genefilter)
library(Rtsne)
library(ggplot2)
library(gridExtra)
library(pheatmap)
library(gplots)
library(limma)
library(RColorBrewer)
library(reshape)
library(GSVA)
library(qusage)
library(quantiseqr)
library(AnnotationDbi)
library(org.Hs.eg.db)
library(clusterProfiler)


##=
counts <- fread('~/setdb1/raw_data/GTG-2110.exon.gene_id.counts.featurecounts.tsv')
#tpm <- fread('~/setdb1/raw_data/GTG-2110.rnaseqc.gene_tpm.tsv')

colData <- read_excel('~/setdb1/raw_data/GTG-2110_LibraryPrep-Release.xlsx') %>% 
  dplyr::rename('sample_id' = 'Sample ID', 'subject_id' = 'Subject ID') %>%
  separate(col = 'subject_id',into = c('cell_line', 'treatment','time'),sep = ' ') %>%
  separate(col = 'treatment', into = c('dose','compund'), sep = '-') %>%
  separate(col = 'time', into = c('time','replicate'),sep = '-') %>%
  mutate (response = ifelse(cell_line %in% c('KO-52','OCI-M2'), 'non_Responder', 'Responder')) %>% 
  filter(cell_line != 'UHR')

rownames(colData) <- colData$sample_id

###############################################################################################
##1. load
###############################################################################################

counts <- counts %>% column_to_rownames('Geneid')

samples <- intersect(colnames(counts),colData$sample_id)

counts <- counts[,samples]

colData <- colData %>% filter(sample_id %in% samples)

## filter Obtain CPMs
library(edgeR)
library(limma)

myCPM <- cpm(counts)
# Have a look at the output
head(myCPM)
# Which values in myCPM are greater than 0.5?
thresh <- myCPM > 0.5
# This produces a logical matrix with TRUEs and FALSEs
head(thresh)
# Summary of how many TRUEs there are in each row
# There are 11433 genes that have TRUEs in all 12 samples.
table(rowSums(thresh))

# we would like to keep genes that have at least 20% TRUES in each row of thresh
keep <- rowSums(thresh) >= 40
# Subset the rows of countdata to keep the more highly expressed genes
counts.keep <- counts[keep,]
summary(keep)
dim(counts.keep)

#A CPM of 0.5 is used as it corresponds to a count of 10-15 for the library sizes in this data set. If the count is any smaller, it is considered to be very low, indicating that the associated gene is not expressed in that sample. A requirement for expression in two or more libraries is used as each group contains two replicates. This ensures that a gene will be retained if it is only expressed in one group. Smaller CPM thresholds are usually appropriate for larger libraries. As a general rule, a good threshold can be chosen by identifying the CPM that corresponds to a count of 10, which in this case is about 0.5. You should filter with CPMs rather than filtering on the counts directly, as the latter does not account for differences in library sizes between samples.
# Let's have a look and see whether our threshold of 0.5 does indeed correspond to a count of about 10-15
# We will look at the first sample
plot(myCPM[,1],counts[,1])

# Let us limit the x and y-axis so we can actually look to see what is happening at the smaller counts
plot(myCPM[,1],counts[,1],ylim=c(0,50),xlim=c(0,3))
# Add a vertical line at 0.5 CPM
abline(v=0.5,col='blue')
abline(h = 10,col='red')

#Convert counts to DGEList object
#Next we’ll create a DGEList object. This is an object used by edgeR to store count data. It has a number of slots for storing various parameters about the data.
dgeObj <- DGEList(counts.keep)
# have a look at dgeObj
dgeObj
# See what slots are stored in dgeObj
names(dgeObj)
# Library size information is stored in the samples slot
dgeObj$samples

#Quality control
#Now that we have got rid of the lowly expressed genes and have our counts stored in a DGEList object, we can look at a few different plots to check that the data is good quality, and that the samples are as we would expect.
# The names argument tells the barplot to use the sample names on the x-axis
# The las argument rotates the axis names
barplot(dgeObj$samples$lib.size, names=colnames(dgeObj), las=2)
# Add a title to the plot
title("Barplot of library sizes")
#Count data is not normally distributed, so if we want to examine the distributions of the raw counts we need to log the counts. Next we’ll use box plots to check the distribution of the read counts on the log2 scale. 
#We can use the cpm function to get log2 counts per million, which are corrected for the different library sizes. The cpm function also adds a small offset to avoid taking log of zero.
# Get log2 counts per million
logcounts <- cpm(dgeObj,log=TRUE)
# Check distributions of samples using boxplots
boxplot(logcounts, xlab="", ylab="Log2 counts per million",las=2)
# Let's add a blue horizontal line that corresponds to the median logCPM
abline(h=median(logcounts),col="blue")
title("Boxplots of logCPMs (unnormalised)")
#Multidimensional scaling plots
#plotMDS(dgeObj)
# We specify the option to let us plot two plots side-by-sde
par(mfrow=c(1,1))
# Let's set up colour schemes for CellType
# How many cell types and in what order are they stored?
colData$cell_line = factor(colData$cell_line)
## Let's choose purple for basal and orange for luminal
col.cell <- c("purple","orange",'red','blue','green','black','yellow')[colData$cell_line]
data.frame(colData$cell_line,col.cell)

# Redo the MDS with cell type colouring
plotMDS(dgeObj,col=col.cell)
# Let's add a legend to the plot so we know which colours correspond to which cell type
legend("bottomright", 
       inset=c(0,1), xpd=TRUE, horiz=TRUE, bty="n",
       cex=.6,
       fill=c("purple","orange",'red','blue','green','black','yellow'),
       legend=levels(colData$cell_line), title = 'Cell Line')

#Normalisation for composition bias
# Apply normalisation to DGEList object
dgeObj <- calcNormFactors(dgeObj)
par(mfrow=c(1,2))
plotMD(dgeObj,column = 7)
plotMD(logcounts,column = 7)

save(colData,logcounts,dgeObj,file="~/setdb1/analysis/preprocessing.Rdata")

#an ExpressionSet object (from the Biobase package), where the HGNC
#gene symbols are provided in a column of the fData slot - that is specified
#by the column parameter below
library(org.Hs.eg.db)
columns(org.Hs.eg.db)

annots <- AnnotationDbi::select(org.Hs.eg.db, keys=rownames(counts.keep) %>% as.character(),
                                columns=c("SYMBOL",'ENSEMBL'), keytype="ENSEMBL") %>% 
  filter(!duplicated(ENSEMBL))

tumorexp <- ExpressionSet(assayData = (counts.keep) %>%as.matrix,
                          phenoData = AnnotatedDataFrame(colData %>% column_to_rownames('sample_id')),
                          featureData = AnnotatedDataFrame(
                            data.frame(symbol = annots$SYMBOL, 
                                       row.names = annots$ENSEMBL))
)

##log2(+1) converting expression data for TPMs
exprs(tumorexp) <- log2(exprs(tumorexp) + .1)

tumorexp <- tumorexp[,tumorexp$cell_line != 'UHR']

# QC plots
#Plotting some QC plots prior to differential expression analysis. 
par(mfrow=c(1,1))
hist(rowMeans(exprs(tumorexp)))

##Histogram of row vars
hist(rowVars(exprs(tumorexp)))
## Sample expression tSNE

##Subsetting to variable and expressed genes
rnaTUSE <- exprs(tumorexp)[ which(rowMeans(exprs(tumorexp)) > 2.5 & 
                                    rowVars(exprs(tumorexp)) > .15) , ]

##Getting tsne together
set.seed(772)
# tstTSNE <- Rtsne(t(rnaTUSE),
#                  check_duplicates=FALSE,
#                  pca=TRUE,
#                  perplexity=2,
#                  theta=0.5,
#                  dims=2)
##Making a dataframe for plotting
# tstTSNEDF <- as.data.frame(tstTSNE$Y)
# tstTSNEDF$cell_line <- factor(tumorexp$cell_line)
# tstTSNEDF$dose <- factor(tumorexp$dose)
# tstTSNEDF$compund <- factor(tumorexp$compund)
# tstTSNEDF$time <- factor(tumorexp$time)
# tstTSNEDF$response <- factor(tumorexp$response)
# 
## UMAP 
library(uwot)
tstUMAP <- uwot::umap(t(rnaTUSE), n_neighbors = 30, min_dist = 0.3, metric = "euclidean")
##Making a dataframe for plotting
tstUMAPDF <- as.data.frame(tstUMAP)
tstUMAPDF$cell_line <- factor(tumorexp$cell_line)
tstUMAPDF$dose <- factor(tumorexp$dose)
tstUMAPDF$compund <- factor(tumorexp$compund)
tstUMAPDF$time <- factor(tumorexp$time)
tstUMAPDF$response <- factor(tumorexp$response)

##Plotting
ggplot(data = tstUMAPDF, aes(x = V1, y = V2, colour = cell_line)) +
  geom_point()

ggplot(data = tstUMAPDF, aes(x = V1, y = V2, colour = dose)) +
  geom_point()

ggplot(data = tstUMAPDF, aes(x = V1, y = V2, colour = compund)) +
  geom_point()

ggplot(data = tstUMAPDF, aes(x = V1, y = V2, colour = response)) +
  geom_point()

############### Differential expression with edgeR
## Read the counts from the downloaded data
library(edgeR)
library(limma)
library(gplots)
library(org.Hs.eg.db)
load("~/setdb1/analysis/preprocessing.Rdata")

#Create the design matrix
#SETDB1i associated conserve gene sets
#Differential expression: voom
#When the library sizes are quite variable between samples, then the voom approach is theoretically more powerful than limma-trend. In this approach, the voom transformation is applied to the normalized and filtered DGEList object
group = colData$compund
design = model.matrix(~0 + group)
v <- voom(dgeObj, design, plot=TRUE)

#lmFit fits a linear model using weighted least squares for each gene:
fit <- lmFit(v, design)
head(coef(fit))
#Comparisons between groups (log fold-changes) are obtained as contrasts of these fitted linear models:Specify which groups to compare:
contr <- makeContrasts(group1197 - group883, levels = colnames(coef(fit)))
contr
#Estimate contrast for each gene
tmp <- contrasts.fit(fit, contr)
#Empirical Bayes smoothing of standard errors (shrinks standard errors that are much larger or smaller than those from other genes towards the average standard error) 
tmp <- eBayes(tmp)
#What genes are most differentially expressed?
top.table <- topTable(tmp, sort.by = "P", n = Inf)
length(which(top.table$adj.P.Val < 0.05))

#Write top.table to a file
columns(org.Hs.eg.db)
annots <- AnnotationDbi::select(org.Hs.eg.db, keys=rownames(top.table) %>% as.character(),
                                columns=c("SYMBOL",'ENSEMBL','GENENAME','GENETYPE'), keytype="ENSEMBL") %>% 
  filter(!duplicated(ENSEMBL))

final.tbl <- top.table %>% tibble::rownames_to_column(var = 'ENSEMBL') %>% left_join(annots) %>% 
  filter(!is.na(SYMBOL), GENETYPE == 'protein-coding')
write.csv(final.tbl, '~/setdb1/analysis/LIMMA_VOOM_DE_1197vs883.csv',row.names = F)

##Volcano plot
library(ggrepel)
plotABVRES <- final.tbl
plotABVRES$adj.P.Val_l10 <- -log10(plotABVRES$adj.P.Val)
plotABVRES$sig_flag <- "NS"
plotABVRES$sig_flag[ which(abs(plotABVRES$logFC) > 0.3 & plotABVRES$adj.P.Val < 0.2) ] <- "Suggestive"
plotABVRES$sig_flag[ which(abs(plotABVRES$logFC) > .5 & plotABVRES$adj.P.Val < 0.05) ] <- "Significant"

#topGENES
topABVRES <- plotABVRES[ 1:300, ]

##Plotting
ggplot(data = plotABVRES, aes(x = logFC, y = adj.P.Val_l10, fill = sig_flag)) +
  geom_point(size = 1.75, shape = 21) + 
  scale_y_continuous("-log10 (Adjusted P value)") +
  scale_x_continuous("Log fold-change") + 
  scale_fill_manual("Significance", values = c("NS" = "grey40", 
                                               "Suggestive" = "red",
                                               "Significant" = "purple")) + 
  geom_text_repel(data = topABVRES, aes(label = SYMBOL), size = 3, max.overlaps = 20) +
  geom_hline(yintercept = 1.3, linetype = 2) +
  geom_vline(xintercept = -0.3, linetype = 2) +
  geom_vline(xintercept = 0.3, linetype = 2) +
  guides(fill = guide_legend(override.aes = list(size = 7))) +
  theme_bw(base_size = 20) +
  theme(legend.position = "none")

########## compare response vs non response cell lines

group = colData$response
design = model.matrix(~0 + group)
v <- voom(dgeObj, design, plot=TRUE)
fit <- lmFit(v, design)
head(coef(fit))
#Comparisons between groups (log fold-changes) are obtained as contrasts of these fitted linear models:Specify which groups to compare:
contr <- makeContrasts(groupResponder - groupnon_Responder, levels = colnames(coef(fit)))
contr
#Estimate contrast for each gene
tmp <- contrasts.fit(fit, contr)
#Empirical Bayes smoothing of standard errors (shrinks standard errors that are much larger or smaller than those from other genes towards the average standard error) 
tmp <- eBayes(tmp)
#What genes are most differentially expressed?
top.table <- topTable(tmp, sort.by = "P", n = Inf)
length(which(top.table$adj.P.Val < 0.05))

#Write top.table to a file
columns(org.Hs.eg.db)
annots <- AnnotationDbi::select(org.Hs.eg.db, keys=rownames(top.table) %>% as.character(),
                                columns=c("SYMBOL",'ENSEMBL','GENENAME','GENETYPE','ENTREZID'), keytype="ENSEMBL") %>% 
  filter(!duplicated(ENSEMBL))

final.tbl <- top.table %>% tibble::rownames_to_column(var = 'ENSEMBL') %>% left_join(annots) %>% 
  filter(!is.na(SYMBOL), GENETYPE == 'protein-coding')
write.csv(final.tbl, '~/setdb1/analysis/LIMMA_VOOM_DE_RespondervsNonresponder.csv',row.names = F)

##Volcano plot
library(ggrepel)
plotABVRES <- final.tbl
plotABVRES$adj.P.Val_l10 <- -log10(plotABVRES$adj.P.Val)
plotABVRES$sig_flag <- "NS"
plotABVRES$sig_flag[ which(abs(plotABVRES$logFC) > 0.3 & plotABVRES$adj.P.Val < 0.2) ] <- "Suggestive"
plotABVRES$sig_flag[ which(abs(plotABVRES$logFC) > .5 & plotABVRES$adj.P.Val < 0.05) ] <- "Significant"

#topGENES
topABVRES <- plotABVRES[ 1:300, ]

##Plotting
ggplot(data = plotABVRES, aes(x = logFC, y = adj.P.Val_l10, fill = sig_flag)) +
  geom_point(size = 1.75, shape = 21) + 
  scale_y_continuous("-log10 (Adjusted P value)") +
  scale_x_continuous("Log fold-change") + 
  scale_fill_manual("Significance", values = c("NS" = "grey40", 
                                               "Suggestive" = "red",
                                               "Significant" = "purple")) + 
  geom_text_repel(data = topABVRES, aes(label = SYMBOL), size = 3, max.overlaps = 20) +
  geom_hline(yintercept = 1.3, linetype = 2) +
  geom_vline(xintercept = -0.3, linetype = 2) +
  geom_vline(xintercept = 0.3, linetype = 2) +
  guides(fill = guide_legend(override.aes = list(size = 7))) +
  theme_bw(base_size = 20) +
  theme(legend.position = "none")

######## compare responder 1197 vs all other groups

group = paste(colData$response, colData$compund,sep = '_')
group = ifelse(group == 'Responder_1197', group, 'other')
design = model.matrix(~0 + group)
v <- voom(dgeObj, design, plot=TRUE)
fit <- lmFit(v, design)
head(coef(fit))
#Comparisons between groups (log fold-changes) are obtained as contrasts of these fitted linear models:Specify which groups to compare:
contr <- makeContrasts(groupResponder_1197 - groupother, levels = colnames(coef(fit)))
contr
#Estimate contrast for each gene
tmp <- contrasts.fit(fit, contr)
#Empirical Bayes smoothing of standard errors (shrinks standard errors that are much larger or smaller than those from other genes towards the average standard error) 
tmp <- eBayes(tmp)
#What genes are most differentially expressed?
top.table <- topTable(tmp, sort.by = "P", n = Inf)
length(which(top.table$adj.P.Val < 0.05))

#Write top.table to a file
columns(org.Hs.eg.db)
annots <- AnnotationDbi::select(org.Hs.eg.db, keys=rownames(top.table) %>% as.character(),
                                columns=c("SYMBOL",'ENSEMBL','GENENAME','GENETYPE','ENTREZID'), keytype="ENSEMBL") %>% 
  filter(!duplicated(ENSEMBL))

final.tbl <- top.table %>% tibble::rownames_to_column(var = 'ENSEMBL') %>% left_join(annots) %>% 
  filter(!is.na(SYMBOL), GENETYPE == 'protein-coding')
write.csv(final.tbl, '~/setdb1/analysis/LIMMA_VOOM_DE_Responder1197vsother.csv',row.names = F)

##Volcano plot
library(ggrepel)
plotABVRES <- final.tbl
plotABVRES$adj.P.Val_l10 <- -log10(plotABVRES$adj.P.Val)
plotABVRES$sig_flag <- "NS"
plotABVRES$sig_flag[ which(abs(plotABVRES$logFC) > 0.3 & plotABVRES$adj.P.Val < 0.2) ] <- "Suggestive"
plotABVRES$sig_flag[ which(abs(plotABVRES$logFC) > .5 & plotABVRES$adj.P.Val < 0.05) ] <- "Significant"

#topGENES
topABVRES <- plotABVRES[ 1:300, ]

##Plotting
ggplot(data = plotABVRES, aes(x = logFC, y = adj.P.Val_l10, fill = sig_flag)) +
  geom_point(size = 1.75, shape = 21) + 
  scale_y_continuous("-log10 (Adjusted P value)") +
  scale_x_continuous("Log fold-change") + 
  scale_fill_manual("Significance", values = c("NS" = "grey40", 
                                               "Suggestive" = "red",
                                               "Significant" = "purple")) + 
  geom_text_repel(data = topABVRES, aes(label = SYMBOL), size = 3, max.overlaps = 20) +
  geom_hline(yintercept = 1.3, linetype = 2) +
  geom_vline(xintercept = -0.3, linetype = 2) +
  geom_vline(xintercept = 0.3, linetype = 2) +
  guides(fill = guide_legend(override.aes = list(size = 7))) +
  theme_bw(base_size = 20) +
  theme(legend.position = "none")


## heatmap of DE genes
library(ComplexHeatmap)
load("~/setdb1/analysis/preprocessing.Rdata")
final.tbl <- fread('~/setdb1/analysis/LIMMA_VOOM_DE_Responder1197vsother.csv')

test <- colData
test1 <- test[order(test$response, test$cell_line, test$compund),]
rnaLINT <- logcounts[final.tbl$ENSEMBL[1:40],test1$sample_id]

ha = HeatmapAnnotation(
  Compound = test1$compund,cell_line = test1$cell_line,
  response = test1$response#,
  #gp = gpar(col = "black")
)
rownames(rnaLINT) <- final.tbl$SYMBOL[1:40]

Heatmap(t(scale(t(rnaLINT))), name = "Expr", rect_gp = gpar(col = "white", lwd = .2),
        #column_title = "Differential expressed genes by active SETDB1 inhibition in responders",
        top_annotation = ha,
        row_names_gp = gpar(fontsize = 6),
        column_names_gp = gpar(fontsize = 6),
        cluster_columns = F,
        show_column_names = F)

###########
# TOP GO

library(topGO)
library(org.Hs.eg.db)

##Subsetting to only differentially expressed genes
sigDIFF <- plotABVRES[ which(plotABVRES$sig_flag == "Significant"), ]

##Performing GO enrichment analysis 
ensLIST <- na.omit(as.list(org.Hs.egENSEMBL2EG)[plotABVRES$ENSEMBL])
allPRES <- factor(as.numeric(names(ensLIST) %in% sigDIFF$ENSEMBL))
names(allPRES) <- names(ensLIST)

##Making new topGO object
allGOdata = new("topGOdata",
                description = "Analysis of enrichment of differential expression in Responder_1197 vs all others",
                ontology = "BP",
                allGenes = allPRES,
                nodeSize = 50,
                annot = annFUN.org,
                mapping="org.Hs.eg.db",
                ID="Ensembl")

##Running tests. Only doing Fisher, but changing algorithms a bit. Classic is
##the unmodified, elmination only uses the most specific ontology.
allfishClassic <- runTest(allGOdata,
                          algorithm = "classic",
                          statistic = "fisher")

allfishElim <- runTest(allGOdata,
                       algorithm = "elim",
                       statistic = "fisher")

##Outputting result in an interpretable table.
allGORES <- GenTable(allGOdata,
                     FishClassic = allfishClassic,
                     FishElim = allfishElim,
                     orderBy = "FishClassic",
                     ranksOf = "FishElim",
                     topNodes = 50)

##And another version
elimGORES <- GenTable(allGOdata,
                      FishClassic = allfishClassic,
                      FishElim = allfishElim,
                      orderBy = "FishElim",
                      ranksOf = "FishClassic",
                      topNodes = 50)

##And printing
elimGORES

write.csv(elimGORES, '~/setdb1/analysis/topGO_Responder1197vsOthers.csv',row.names = F)

################################################### ssGSEA
## retrieve genes sets by GO_ID

#Option 2: 
library(org.Hs.eg.db)
#retrieved <- AnnotationDbi::select(org.Hs.eg.db, keytype="GO", keys=elimGORES$GO.ID[1:20], columns=c("ENSEMBL",'ONTOLOGY','PATH'))
z <- mapIds(org.Hs.eg.db, keys(org.Hs.eg.db, "GO"), "ENSEMBL", "GO", multiVals = "list")
elimGORES_GO <- elimGORES %>% left_join(data.frame(Term(GOTERM)) %>% tibble::rownames_to_column(var = 'GO.ID'))

#top20 GOBP pathway for ssGSEA
topGO20 <- z[grep(paste(elimGORES$GO.ID[1:20],collapse = '|'), names(z))]  

geneList <- topGO20

##Filtering
gLUSE <- GSVA::filterGeneSets(geneList, 
                              min.sz = 3, 
                              max.sz = 500)

##Scoring via ssGSEA
tpm <- fread('~/setdb1/raw_data/GTG-2110.rnaseqc.gene_tpm.tsv') %>% column_to_rownames(var='Name')
#filter tpm according to raw counts filter criteria
rnaETPM <- tpm[rownames(logcounts), colnames(logcounts)]

allRES <- GSVA::gsva(expr = rnaETPM %>% as.matrix, 
               gset.idx.list = gLUSE,
               method = "ssgsea", 
               ssgsea.norm = F)
GSVA::gsva(gsvaParam(as.matrix(rnaETPM),gLUSE))
allRES_df <- as.data.frame(allRES)

#plotting

## Heatmap of gene sets
annoFULL <- colData
annoFULL$Sample_label <- paste(colData$response,colData$compund,sep = '_')
annoSS <- annoFULL %>% dplyr::select("Sample_label"#, "Mosaic_ID", 
                                     #"Diagnosis", "BOR", 
                                     # "Months on Treatment",
                                     #'Treatment'
)

##Heatmap
pheatmap(allRES_df,
         labels_col = annoFULL$Sample_label,
         show_colnames = TRUE, 
         show_rownames = TRUE)

#boxplot
##  add colData
ssgsea_df <- allRES_df %>% rownames_to_column('GO.ID') %>% 
  pivot_longer(!GO.ID,names_to = 'sample_id',values_to = 'ssGSEAscore') %>% 
  left_join(.,annoFULL) %>% 
  left_join(elimGORES_GO)

ggplot(ssgsea_df,aes(Sample_label,log(ssGSEAscore+2),fill = Sample_label)) +
  geom_jitter(alpha=.1)+
  geom_boxplot(alpha = .5) +
  facet_wrap(~Term.GOTERM.,ncol = 5) +
  theme_classic() +
  theme(axis.text.x = element_blank())+
  labs(x='')

################################################################################## 
#test 2 using clusterprofiler
#################################################################################
library(clusterProfiler)

#data(geneList, package="DOSE")

final.tbl <- fread('~/setdb1/analysis/LIMMA_VOOM_DE_Responder1197vsother.csv')
load('~/setdb1/analysis/preprocessing.Rdata')

geneList_df <- final.tbl %>% arrange(-logFC)
geneList <- geneList_df$logFC
names(geneList) <- geneList_df$ENTREZID

######################## HALLMARKER from MSIGDB
library(msigdbr)
########### HALLMARKER
# m_t2g <- msigdbr(species = "Homo sapiens", category = "H") %>% 
#   dplyr::select(gs_name, entrez_gene,ensembl_gene)
# head(m_t2g)
# #MSigDb over-presentaton analysis HALLMARK
# gene <- names(geneList)[geneList>=2]
# em <- enricher(gene, TERM2GENE=m_t2g)
# em_df <- data.frame(em)
# 
# #12.3.2 MSigDb gene set enrichment analysis HALLMARK
# em2 <- GSEA(geneList, TERM2GENE = m_t2g)
# em2_df <- data.frame(em2)
# 
### GOBP
m_t2g <- msigdbr(species = "Homo sapiens", category = "C5",subcategory = 'GO:BP') %>%
  dplyr::select(gs_name, entrez_gene,ensembl_gene)
head(m_t2g)
#MSigDb over-presentaton analysis GOBO
gene <- names(geneList)[geneList>=2]
em <- enricher(gene, TERM2GENE=m_t2g)
em_df <- data.frame(em)

#12.3.2 MSigDb gene set enrichment analysis GOBP
em2 <- GSEA(geneList, TERM2GENE = m_t2g)
em2_df <- data.frame(em2)

##ploting
dotplot(em2, showCategory=10,font.size = 7) + ggtitle("dotplot for GOBP GSEA") +
  scale_y_discrete(labels=function(x) str_wrap(x, width=5))

## ssGSEA based on top20 GO GSEA from cluster profiler, 
em2_df_ssgsea <- em2_df %>% arrange(qvalue) %>% filter(NES > 0) %>% top_n(50)
z <-em2@geneSets

#filter gobp pathways to only get enrichen terms and the gene entrezid
z_ssgsea_go <- z[grep(paste(em2_df_ssgsea$ID,collapse = '|'), names(z))]  

geneList <- z_ssgsea_go

##Filtering
gLUSE <- GSVA::filterGeneSets(geneList, 
                              min.sz = 3, 
                              max.sz = 500)
##Scoring via ssGSEA
library(org.Hs.eg.db)
tpm <- fread('~/setdb1/raw_data/GTG-2110.rnaseqc.gene_tpm.tsv') %>% column_to_rownames(var='Name')
tpm <- tpm[rownames(logcounts), colnames(logcounts)]

annots <- AnnotationDbi::select(org.Hs.eg.db, keys=rownames(tpm) %>% as.character(),
                                columns=c("SYMBOL",'ENSEMBL','GENENAME','GENETYPE','ENTREZID'), keytype="ENSEMBL") %>% 
  filter(!duplicated(ENTREZID),!is.na(SYMBOL), GENETYPE == 'protein-coding')

#filter tpm according to raw counts filter criteria
rnaETPM <- tpm[annots$ENSEMBL,]
rownames(rnaETPM) <- annots$ENTREZID

allRES <- gsva(expr = rnaETPM %>% as.matrix, 
               gset.idx.list = gLUSE,
               method = "ssgsea", 
               ssgsea.norm = F)

allRES_df <- as.data.frame(allRES)
####################################
#zscore the ssgsea output for comparative analysis
mat = (allRES_df - rowMeans(allRES_df))/(rowSds(as.matrix(allRES_df)))[row(allRES_df)]

saveRDS(mat,'~/setdb1/analysis/clusterprofilter_GOBP_ssGSEA.rds')
###########################################

#plotting
## Heatmap of gene sets
annoFULL <- colData
annoFULL$Sample_label <- paste(colData$response,colData$compund,sep = '_')
annoSS <- annoFULL %>% dplyr::select("Sample_label")

##Heatmap
pheatmap(mat,
         labels_col = annoFULL$Sample_label,
         show_colnames = TRUE, 
         show_rownames = TRUE)

#boxplot
##  add colData
ssgsea_df <- mat[c(7,11,15,19,20),] %>% rownames_to_column('ID') %>% 
  pivot_longer(!ID,names_to = 'sample_id',values_to = 'ssGSEAscore') %>% 
  left_join(.,annoFULL) %>% 
  left_join(em2_df_ssgsea)

library(ggpubr)

ggplot(ssgsea_df,aes(Sample_label,ssGSEAscore,fill = Sample_label)) +
  #geom_jitter(alpha=.1)+
  geom_boxplot(alpha = .5) +
  facet_wrap(~ID,ncol = 5,labeller = label_wrap_gen(width=10)) +
  theme_classic() +
  theme(axis.text.x = element_blank(),
        strip.text = element_text(size=7))+
  labs(x='', y = 'ssGSEA (z-score)') +
  stat_compare_means() +
  stat_compare_means(ref.group = 'Responder_883',label = 'p.signif',label.y = c(2.5,0,.5,.5))


#################################################################################################### 
## Updated analysis for Dom's requests 20250314
#1. differential expressed genes between 1197 vs 883 in each of the 6 cell lines 
#2. top 100 genes up/down in heat map
#3. display the top up and down regulated pathways based on genes up 2fold and down 2 fold or 
#   greater - FDR 0.05 or 0.01 based on what seems more natural in the data.
#4. perform the above analysis from D4 first. and then repeat them in time point D2 and D3
#################################################################################################### 
######## compare differential expressed genes between 1197 vs 883 in each of the 6 cell lines by different time point
# load the data
load('~/setdb1/analysis/preprocessing.Rdata')

colData$cell_line <- gsub('-','_',colData$cell_line)

masterdf <- data.frame(table(colData$cell_line, colData$time))

df <- data.frame()

for ( idx in 1:nrow(masterdf)) {
  
  cell = masterdf[idx,1] %>% as.character()
  day = masterdf[idx,2] %>% as.character()
  
  colData_s = colData %>% filter(cell_line == cell, time == day)
  
  degObj_s = dgeObj[,colData_s$sample_id]
  
  group = paste(colData_s$cell_line, colData_s$compund,sep = '_')
  design = model.matrix(~0 + group)
  v <- voom(degObj_s, design, plot=TRUE)
  fit <- lmFit(v, design)
  head(coef(fit))
  
  ## loop comparison for each cell line active vs inactive
  #Comparisons between groups (log fold-changes) are obtained as contrasts of these fitted linear models:Specify which groups to compare:
  
  x = paste(colnames(coef(fit))[1], '-', colnames(coef(fit))[2])
  
  contr <- makeContrasts(x, levels = colnames(coef(fit)))
  contr
  #Estimate contrast for each gene
  tmp <- contrasts.fit(fit, contr)
  #Empirical Bayes smoothing of standard errors (shrinks standard errors that are much larger or smaller than those from other genes towards the average standard error) 
  tmp <- eBayes(tmp)
  #What genes are most differentially expressed?
  top.table <- topTable(tmp, sort.by = "P", n = Inf)
  length(which(top.table$adj.P.Val < 0.05))
  
  #Write top.table to a file
  columns(org.Hs.eg.db)
  annots <- AnnotationDbi::select(org.Hs.eg.db, keys=rownames(top.table) %>% as.character(),
                                  columns=c("SYMBOL",'ENSEMBL','GENENAME','GENETYPE','ENTREZID'), keytype="ENSEMBL") %>% 
    filter(!duplicated(ENSEMBL))
  
  final.tbl <- top.table %>% tibble::rownames_to_column(var = 'ENSEMBL') %>% left_join(annots) %>% 
    filter(!is.na(SYMBOL), GENETYPE == 'protein-coding') %>% 
    mutate(contrast = colnames(contr), day = day, cell_line = cell)
  
  df <- rbind(df,final.tbl)
}

## save the LIMMA_VOOM_DE_1197vs883_perCellLine_perDay.csv
write.csv(df, '~/setdb1/analysis/LIMMA_VOOM_DE_1197vs883_perCellLine_perDay.csv',row.names = F)


#1. differential expressed genes between 1197 vs 883 in each of the 6 cell lines 
#2. top 100 genes up/down in heat map
#3. display the top up and down regulated pathways based on genes up 2fold and down 2 fold or 
#   greater - FDR 0.05 or 0.01 based on what seems more natural in the data.
#4. perform the above analysis from D4 first. and then repeat them in time point D2 and D3

##1. Volcano plot
library(ggrepel)

masterdf <- data.frame(table(df$contrast,df$day))

pltlist <- list()

for ( i in 1:nrow(masterdf)) {
  
  cell = masterdf[ i ,1] %>% as.character()
  time = masterdf[ i,2] %>% as.character()
  
  df_s = df %>% filter(contrast == cell, day == time)
  
  plotABVRES <- df_s
  plotABVRES$adj.P.Val_l10 <- -log10(plotABVRES$adj.P.Val)
  plotABVRES$sig_flag <- "NS"
  plotABVRES$sig_flag[ which(abs(plotABVRES$logFC) > 0.3 & plotABVRES$adj.P.Val < 0.2) ] <- "Suggestive"
  plotABVRES$sig_flag[ which(abs(plotABVRES$logFC) > .5 & plotABVRES$adj.P.Val < 0.05) ] <- "Significant"
  
  #topGENES
  topABVRES <- plotABVRES[ 1:50, ]
  
  ##Plotting
  pltlist [[ i ]] <- ggplot(data = plotABVRES, aes(x = logFC, y = adj.P.Val_l10, fill = sig_flag)) +
    geom_point(size = 0.75, shape = 21) + 
    scale_y_continuous("-log10 (Adjusted P value)") +
    scale_x_continuous("Log fold-change") + 
    scale_fill_manual("Significance", values = c("NS" = "grey40", 
                                                 "Suggestive" = "red",
                                                 "Significant" = "purple")) + 
    geom_text_repel(data = topABVRES, 
                    aes(label = SYMBOL), size = 1, max.overlaps = 20) +
    geom_hline(yintercept = 1.3, linetype = 2) +
    geom_vline(xintercept = -0.3, linetype = 2) +
    geom_vline(xintercept = 0.3, linetype = 2) +
    guides(fill = guide_legend(override.aes = list(size = 2))) +
    theme_bw(base_size = 5) +
    labs(title = paste(time,cell))
  
}
pdf('test.pdf',width = 14,height = 7)
gridExtra::grid.arrange(grobs = pltlist, ncol = 6)
dev.off()


##2. top 100 genes up/down in Heatmap

df <- read.csv('~/setdb1/analysis/LIMMA_VOOM_DE_1197vs883_perCellLine_perDay.csv')

masterdf <- df %>% group_by(contrast,day,cell_line) %>% 
  summarise(n())

pltlist_hm <- list()

for ( i in 1:nrow(masterdf)) {
  
  cell = masterdf[ i ,3] %>% as.character()
  timepoint = masterdf[ i,2] %>% as.character()
  
  df_s = df %>% filter(cell_line == cell, day == timepoint) %>% 
    filter(adj.P.Val < 0.01) %>% arrange(-logFC)
  
  df_sw = rbind(head(df_s,100),tail(df_s,100))
  
  colData_s = colData %>% filter(cell_line == cell,time == timepoint)
  
  ##Plotting top and bottom 100 genes
  intGenes <- df_sw$ENSEMBL
  
  ##Subsetting to only these genes
  dgeObj_s = dgeObj[intGenes,colData_s$sample_id]
  
  logcounts <- cpm(dgeObj_s,log=TRUE)
  
  annoSS = as.data.frame(colData_s %>% select('cell_line','compund','time'), 
                         row.names = colnames(logcounts))
  
  ##Heatmap
  pheatmap(logcounts,
           labels_row = df_sw$SYMBOL,
           #labels_col = colData_s$sample_id,
           #show_colnames = TRUE, 
           show_rownames = TRUE,
           #color = colorpanel(100, "blue", "white", "red"),
           scale = "row",
           #clustering_distance_rows = "euclidean",
           #clustering_method = "ward.D2",
           cluster_rows = F,
           cluster_cols = F,
           annotation_col = annoSS)
  
  pheatmap(logcounts)
  
}

################################################################################## 
## new request from Wenwen heatmap visualization 20250421
##have a list of genes which are regulated by MYC, would like to get a heatmap from 
#6 cell lines on Day4 treated by 0.3 uM(high dose).
##want to use the genes expression significantly changed after 1197 treatment
##to see if those genes are downregulated by 1197 treatment in responder cell  lines but not 
#changed in non-responder cell lines
#################################################################################
# load the data
load('~/setdb1/analysis/preprocessing.Rdata')

tpm <- fread('~/setdb1/raw_data/GTG-2110.rnaseqc.gene_tpm.tsv') %>% column_to_rownames(var='Name')
tpm <- tpm[rownames(logcounts), colnames(logcounts)]

annots <- AnnotationDbi::select(org.Hs.eg.db, keys=rownames(tpm) %>% as.character(),
                                columns=c("SYMBOL",'ENSEMBL','GENENAME','GENETYPE','ENTREZID'), 
                                keytype="ENSEMBL") %>% 
  filter(!duplicated(ENTREZID),!is.na(SYMBOL)#, GENETYPE == 'protein-coding'
  )

#filter tpm according to ensembl id availability
rnaETPM <- tpm[annots$ENSEMBL,]
rownames(rnaETPM) <- annots$ENTREZID

## expression set
tumorTPM <- ExpressionSet(assayData = rnaETPM %>% as.matrix,
                          phenoData = AnnotatedDataFrame(colData %>% select(1:27) %>% column_to_rownames('sample_id')),
                          featureData = AnnotatedDataFrame(
                            data.frame(annots, row.names = annots$ENTREZID))
)

##log2(+1) converting expression data for TPMs
exprs(tumorTPM) <- log2(exprs(tumorTPM) + 1)
# QC plots
hist(rowMeans(exprs(tumorTPM)))
hist(rowVars(exprs(tumorTPM)))

##Subsetting to variable and expressed genes
rnaTUSE <- exprs(tumorTPM)[ which(rowMeans(exprs(tumorTPM)) > 2.5 & 
                                    rowVars(exprs(tumorTPM)) > 0.15), ]
###########################################
#plotting
##Plotting some relevant genes
intGenes <- fread('~/setdb1/raw_data/MYC_targets.human.tsv')

##Subsetting to only these genes
rnaLINT <- tumorTPM[ which(fData(tumorTPM)$SYMBOL %in% intGenes$Target), which(tumorTPM$dose == '0.3uM' &
                                                                                 tumorTPM$time == 'D4')]


##Peeling off, subsetting annotation data
annoSS <- pData(rnaLINT) %>% dplyr::select(#"Patient_ID", #"Mosaic_ID", 
  "cell_line", "dose", 
  # "Months on Treatment",
  'compund','time',
  'response'
  #,'sample_label' 
)

##Heatmap
library(ComplexHeatmap)

test <- pData(rnaLINT)
test1 <- test[order(test$response, test$cell_line, test$compund),]
rnaLINT <- rnaLINT[,rownames(test1)]

ha = HeatmapAnnotation(
  Dose = rnaLINT$dose, Time = rnaLINT$time,
  Compound = rnaLINT$compund,cell_line = rnaLINT$cell_line,
  response = rnaLINT$response,
  gp = gpar(col = "black")
)
rownames(rnaLINT) <- fData(rnaLINT)$SYMBOL
colnames(rnaLINT) <- paste(test1$cell_line,1:36,sep = '_')

Heatmap(t(scale(t(exprs(rnaLINT)))), name = "Expr", rect_gp = gpar(col = "white", lwd = .2),
        column_title = "MYC targets regulation by SETDB1 inhibition",
        top_annotation = ha,
        row_names_gp = gpar(fontsize = 6),
        column_names_gp = gpar(fontsize = 6),
        cluster_columns = F,
        show_column_names = T)


## 20250505 c-myc target expression in barplot
##Subsetting to only these genes and D4 dose 0.3uM
rnaLINT <- tumorTPM[ which(fData(tumorTPM)$SYMBOL %in% intGenes$Target), which(tumorTPM$dose == '0.3uM' &
                                                                                 tumorTPM$time == 'D4')]
rownames(rnaLINT) <- fData(rnaLINT)$SYMBOL

expr <- exprs(rnaLINT) %>% as.data.frame %>% rownames_to_column('Gene') %>% 
  pivot_longer(-Gene, values_to = 'log2_Expr',names_to = 'sample_id') %>% 
  left_join(pData(rnaLINT) %>% rownames_to_column('sample_id')) %>% 
  mutate(cellline_rep = paste(cell_line,replicate,sep='_'), fill = paste(response,compund,sep='\n'))

expr_order <- expr[order(expr$Gene,expr$response, expr$cell_line, expr$compund),]

pltlist <- list()

for (gene in unique(expr_order$Gene)) {
  
  df <- expr_order %>% filter(Gene == gene)
  
  pltlist[[gene]] <- ggplot(df,aes(x = cellline_rep, y = log2_Expr, fill = fill)) +
    geom_col(position = 'dodge',alpha=1) + theme_classic() +
    theme(axis.text.x = element_text(angle=90,size=7),
          legend.position = 'right') +
    labs(x='',fill='', y = paste(gene,'log2_Expr'))+
    facet_wrap(~response,scales='free_x',ncol=2) +
    theme(legend.key.width = unit(3, "mm"),
          legend.text = element_text(size=7))
}

pdf('~/setdb1/c-myc_expression_barplot.pdf',width = 8, height = 12)
gridExtra::grid.arrange(grobs = pltlist[1:12], ncol = 2)
gridExtra::grid.arrange(grobs = pltlist[13:24], ncol = 2)
gridExtra::grid.arrange(grobs = pltlist[25:36], ncol = 2)
gridExtra::grid.arrange(grobs = pltlist[37:48], ncol = 2)
gridExtra::grid.arrange(grobs = pltlist[49:60], ncol = 2)
gridExtra::grid.arrange(grobs = pltlist[61:72], ncol = 2)
gridExtra::grid.arrange(grobs = pltlist[73:84], ncol = 2)
gridExtra::grid.arrange(grobs = pltlist[85:96], ncol = 2)
dev.off()

##########################################################################################
## new request from Wenwen heatmap visualization 20250603
##a barplot of TERT on all timepoint all dose and all samples separately
#################################################################################
# load the data
library(org.Hs.eg.db)

load('~/setdb1/analysis/preprocessing.Rdata')

tpm <- fread('~/setdb1/raw_data/GTG-2110.rnaseqc.gene_tpm.tsv') %>% column_to_rownames(var='Name')
tpm <- tpm[rownames(logcounts), colnames(logcounts)]

annots <- AnnotationDbi::select(org.Hs.eg.db, keys=rownames(tpm) %>% as.character(),
                                columns=c("SYMBOL",'ENSEMBL','GENENAME','GENETYPE','ENTREZID'), 
                                keytype="ENSEMBL") %>% 
  filter(!duplicated(ENTREZID),!is.na(SYMBOL)#, GENETYPE == 'protein-coding'
  )

#filter tpm according to ensembl id availability
rnaETPM <- tpm[annots$ENSEMBL,]
rownames(rnaETPM) <- annots$ENTREZID

## expression set
tumorTPM <- ExpressionSet(assayData = rnaETPM %>% as.matrix,
                          phenoData = AnnotatedDataFrame(colData),
                          featureData = AnnotatedDataFrame(
                            data.frame(annots, row.names = annots$ENTREZID))
)

##log2(+1) converting expression data for TPMs
exprs(tumorTPM) <- log2(exprs(tumorTPM) + 1)
# QC plots
hist(rowMeans(exprs(tumorTPM)))
hist(rowVars(exprs(tumorTPM)))

##Subsetting to variable and expressed genes
rnaTUSE <- exprs(tumorTPM)[ which(rowMeans(exprs(tumorTPM)) > 2.5 & 
                                    rowVars(exprs(tumorTPM)) > 0.15), ]
###########################################
#plotting
##Plotting some relevant genes
intGenes <- fread('~/setdb1/raw_data/MYC_targets.human.tsv') %>% 
  filter(Target %in% c('TERT'))

##Subsetting to only these genes
rnaLINT <- tumorTPM[ which(fData(tumorTPM)$SYMBOL %in% intGenes$Target), ]


##Peeling off, subsetting annotation data
annoSS <- pData(rnaLINT) %>% dplyr::select(#"Patient_ID", #"Mosaic_ID", 
  "cell_line", "dose", 
  # "Months on Treatment",
  'compund','time',
  'response'
  #,'sample_label' 
)

##Heatmap
library(ComplexHeatmap)

test <- pData(rnaLINT)
test1 <- test[order(test$response, test$cell_line, test$compund),]
rnaLINT <- rnaLINT[,test1$sample_id]

ha = HeatmapAnnotation(
  Dose = rnaLINT$dose, Time = rnaLINT$time,
  Compound = rnaLINT$compund,cell_line = rnaLINT$cell_line,
  response = rnaLINT$response#,
  #gp = gpar(col = "black")
)
rownames(rnaLINT) <- fData(rnaLINT)$SYMBOL
colnames(rnaLINT) <- paste(test1$cell_line,test1$sample_id,sep = '_')

set.seed(42)

pdf('~/setdb1/tertEXPRESSION_HM.pdf',width = 15,height = 5)
Heatmap(t(scale(t(exprs(rnaLINT)))), name = "Expr", rect_gp = gpar(col = "white", lwd = .2),
        column_title = "MYC targets regulation by SETDB1 inhibition",
        top_annotation = ha,
        row_names_gp = gpar(fontsize = 6),
        column_names_gp = gpar(fontsize = 4),
        cluster_columns = F,
        show_column_names = T)
dev.off()

## c-myc target expression in barplot 20250625
##Subsetting to only these genes
rnaLINT <- tumorTPM[ which(fData(tumorTPM)$SYMBOL == 'TERT'), ]
rownames(rnaLINT) <- fData(rnaLINT)$SYMBOL

expr <- exprs(rnaLINT) %>% as.data.frame %>% rownames_to_column('Gene') %>% 
  pivot_longer(-Gene, values_to = 'log2_Expr',names_to = 'sample_id') %>% 
  left_join(pData(rnaLINT) ) %>% 
  mutate(cellline_rep = paste(cell_line,replicate,sep='_'), fill = paste(response,compund,sep='\n'))

expr_order <- expr[order(expr$Gene,expr$response, expr$cell_line, expr$compund),]

## try expand_grid and facet_nested_wrap
pdf('~/setdb1/TERT_expression_barplot_alldose_alltimepoints.pdf', width = 12,height = 10)
ggplot(expr_order %>% mutate (id = paste(time, dose)), 
       aes(x = cellline_rep, y = log2_Expr, fill = fill)) +
    geom_col(position = 'dodge',alpha=1) + theme_classic() +
    theme(axis.text.x = element_text(angle=90,size=7),
          legend.position = 'right') +
    labs(x='',fill='', y = paste(unique(expr_order$Gene),'log2_Expr'))+
    facet_wrap(~response,scales='free_x',ncol=2) +
    theme(legend.key.width = unit(3, "mm"),
          legend.text = element_text(size=7)) +
  facet_wrap(~id + response, scales = 'free_x', nrow = 3)
dev.off()
