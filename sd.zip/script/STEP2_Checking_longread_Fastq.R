library(dplyr)
library(data.table)
library(tidyr)
library(readxl)
library(stringr)

## on cml, find all fastq.gz files and the sizes from long read 2108-Repeat
# find /projects/users/io_group/data/setdb1/fastq/GTG-2108-Repeat/ -type f -name '*.fastq.gz' -exec ls -lh \{\} \; > ~/setdb1/raw_data/2108_repeat_fastq_size.txt
# 2108 long read RNA fastq files#

fastq_size_2108 <- read.table('~/setdb1/raw_data/2108_repeat_fastq_size.txt', sep = '\t', stringsAsFactors = FALSE) %>%
  separate(V1, into = c('v1','filepath'), sep = 'Mar 27 ') %>%
  separate(v1, into = c('v1','size'), sep = 'users') %>%
  separate(filepath, into = c('v2','filepath'), sep = '/projects') %>%
  mutate(filepath = paste('/projects',filepath,sep = ''),
         filetype = basename(filepath),
         suffix = sub(".*\\.(.*)\\..*", "\\1", filetype),
         barcodeID = sub(".*/([^/]+)/[^/]+$", "\\1", filepath),
         qc = sub(".*/([^/]+)/([^/]+)/[^/]+$", "\\1", filepath),
         sample = sub(".*/([^/]+)(/([^/]+)){4}/[^/]+$", "\\1", filepath),
         Match = ifelse(
           str_sub(barcodeID, start = -2) == str_sub(sub(".*-(\\d+)_(.*)+$", "\\1", sample), start = -2) |
             str_sub(barcodeID, start = -2) == str_sub(sub(".*_(\\d+)_(.*)+$", "\\1", sample), start = -2),
           'Match', 'No Match') 
         ) %>% 
  filter(qc == 'fastq_pass', barcodeID != 'unclassified', Match == 'Match')

write.csv(fastq_size_2108[,-c(1,3)],'~/setdb1/raw_data/long_read_fastq_path.csv',row.names = F)


# find /projects/users/io_group/data/setdb1/fastq/GTG-2107/ -type f -name '*.fastq.gz' -exec ls -lh \{\} \; > ~/setdb1/raw_data/2107_fastq_size.txt
# 2107 long read RNA fastq files#

fastq_size_2107 <- read.table('~/setdb1/raw_data/2107_fastq_size.txt', sep = '\t', stringsAsFactors = FALSE) %>%
  separate(V1, into = c('v1','filepath'), sep = 'Mar 27 ') %>%
  separate(v1, into = c('v1','size'), sep = 'users') %>%
  separate(filepath, into = c('v2','filepath'), sep = '/projects') %>%
  mutate(filepath = paste('/projects',filepath,sep = ''),
         filetype = basename(filepath),
         suffix = sub(".*_(R\\d\\..*)\\..*", "\\1", filetype),
         lane = sub(".*_([^_]+)_[^_]+$","\\1",filetype),
         sample = sub("^([^_]+).*", "\\1", filetype)
         ) %>% 
  filter(sample != 'Undetermined') %>% 
  arrange(sample,lane,suffix)

write.csv(fastq_size_2107[,-c(1,3)],'~/setdb1/raw_data/short_read_fastq_path.csv',row.names = F)


## read human GTF to understand ERV numbers
#BiocManager::install("rtracklayer")
library(rtracklayer)

# Path to the GTF.GZ file
file_path <- "~/setdb1/ERV_ref/gencode.v47.annotation.gtf.gz"

# Import the GTF file
gtf_data <- import(file_path, format = "gtf")

# View the first few rows of the data
gtf_data <- data.frame(gtf_data)



