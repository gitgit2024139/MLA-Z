library(tidyverse)
library(dplyr)
library(readxl)
library(data.table)
library(Biobase)
library(genefilter)
library(Rtsne)
library(ggplot2)
library(gridExtra)
library(pheatmap)
library(gplots)
library(limma)
library(RColorBrewer)
library(reshape)
library(GSVA)
library(quantiseqr)
library(ComplexHeatmap)
library(lessR)

#1. filelsit

test124 <- read.table('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/filenames_124_250117.txt',sep = '\t')

test431 <- read.table('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/filenames_431_250117.txt',sep = '\t')

allS3file_tumors <- rbind(test124,test431) %>%
  separate(V1, into = c('v1','filepath'), sep = 'CloudDataRoot') %>% 
  mutate(filepath = paste('CloudDataRoot',filepath,sep = '')) %>%
  mutate(filetype = basename(filepath),
  suffix = lapply(filetype, function(x) {tail(strsplit(x,split = '\\.')[[1]], 1)}
  ) %>% unlist()) %>% 
  
  filter(suffix %in% c('tsv','txt','xlsx')) %>% 
  
  mutate(pipeline = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 1)}
  ) %>% unlist(),
  
  Accession_number = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 2)[2]}
  ) %>% unlist()
  )

#read clinical sample shiping manifest, get paired tumor samples
## batch 5 and 6 MANIFEST
manifest <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/Batch5_6_data_inventory_yz_2025.xlsx', 
                               sheet = 1)%>% 
  mutate(Patient_ID = parse_number(Patient_ID))
colnames(manifest)

colData_56 <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/PTPN2_Clinical_Metadata_08AUG24_Final.xlsx',
                              sheet = 2) 

colData_56 <- manifest %>% left_join(., colData_56 %>% dplyr::rename('Patient_ID' = 'Subject_ID')) 

## BATCH 1-4 MANIFEST
manifest <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/M20_431_and_M20_124_Personalis_Shipment_Summary_6Aug2024_yz_mj.xlsx', 
                               sheet = 4)%>% 
  filter(Batch_Type != 'Gene Expression') %>% ##remove blood samples
  mutate(Accession_number = Accession_Number) %>%
  mutate(Accession_number = ifelse(nchar(Accession_number)==12,
                                   str_sub(Accession_number, end = -3),
                                   Accession_number)) %>% 
  #filter(Cohort =='M20-431') %>% page 3 is M20-431 only
  #filter(Mosaic_ID != 'N/A') %>%
  mutate(Accession_Number = parse_number(Accession_number)) %>% 
  dplyr::select(-Annotation) %>% 
  dplyr::select(Batch_number,Visit,Sample_Type ,Cohort,Patient_ID, Accession_number, Treatment,Mosaic_ID)

colnames(manifest) <- c('Batch','Visit','Sample_Type','Study','Subject_ID','Accession_number','Treatment','Mosaic_ID')

colData_1_4 <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/allS3files_431_124_clinical_1105.csv',stringsAsFactors = F)
colData_1_4$Subject_ID <- as.character(colData_1_4$Subject_ID)
colData_1_4 <- manifest %>% left_join(., colData_1_4 )
colnames(colData_1_4)[5] <- 'Patient_ID'

##dissect to shared columns
colData_1_4 <- colData_1_4 %>% select(intersect(colnames(colData_1_4),colnames(colData_56)))
colData_56 <- colData_56 %>% select(intersect(colnames(colData_1_4),colnames(colData_56)))

## combine 1-6 batch coldata
colData_56$C1D1 <- as.character(colData_56$C1D1)
colData_56$Last_Day_on_Treatment <- as.character(colData_56$Last_Day_on_Treatment)
colData_56$Patient_ID <- as.character(colData_56$Patient_ID)

colData_1_6_total <- dplyr::bind_rows(colData_1_4,colData_56)

colData_1_6_total <- unique(colData_1_6_total)

write.csv(colData_1_6_total, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/coldata_1_6_total.csv', row.names = F)

#2. filter rna_expr files
#filter report
final_list_edit <- allS3file_tumors[grepl(paste(c('rna_gene_expression_report.xlsx'),collapse = '|'),
                                          allS3file_tumors$filetype),]  
##batchset
final_list_edit <- final_list_edit %>% mutate(
  batchset = str_extract(filepath, '[Bb]atch\\d(_\\w+)') %>% 
    lapply(.,function(x) {head(strsplit(x, split = '_7')[[1]],1)[1]}) %>%
    unlist(),
  batchdate = str_extract(filepath, '\\d{4}_\\d{4}'),
  batchtotal = paste(batchset,batchdate,sep = '_')
)

# remove repeated files
test <- final_list_edit %>% group_by(Accession_number) %>% 
  reframe(occurrance = paste(sort(unique(batchtotal)),collapse = ';')) %>% 
  mutate(final_segment = str_extract(occurrance , '[^;]+$'))

final_list_edit <- final_list_edit %>% filter(batchtotal %in% test$final_segment)

test <- final_list_edit %>% group_by(Accession_number) %>% 
  reframe(occurrance = paste(sort(unique(batchtotal)),collapse = '; '))

##3 add metadata

final_list <- final_list_edit %>% left_join(.,colData_1_6_total,by = 'Accession_number')  

final_list <- final_list %>% filter(!duplicated(filetype))

## full manifest doesn't have treatment info
final_list_edit <- final_list[order(final_list$Patient_ID
                                    #final_list$Treatment. #full manifest doesn't have treatment info
),]


##save colData
write.csv(final_list_edit,'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch1_6_forTMBandIFNA_20250505.csv',row.names = F)

##4. download gene expression reports from s3 by print bash command lines and run command lines in terminal

for (i in 1: length(final_list_edit$filepath)) {
  
  s3_loc <- final_list_edit$filepath[i]
  filename <- paste(final_list_edit$batchset[i], final_list_edit$filetype[i],sep = '_')
  
  cmd <- paste('aws s3 cp s3://abv-arrayserver/', s3_loc, 
               ' --profile abbvie-omic-prod /homes/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumor_batch1_6_forTMBandIFNA/', 
               filename,sep = '') 
  ## /homes/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data is the location on aurora, not on magnus
  
  write(cmd,file = '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/bash_cp_cmd_total_forTMBandIFNA.sh', append = T)
  
}

##5. extract count reads from each sample

files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumor_batch1_6_forTMBandIFNA/',
                    pattern = 'xlsx',full.names = T)

names(files) <- stringr::str_extract_all(basename(files), pattern = '\\d+',simplify = T)[,2]

##counts
counts <- purrr::map_df(files, .f = read_excel, .id = "sample") %>% select(1:4) %>%
  tidyr::pivot_wider(names_from = 1, values_from = 4 )

write.csv(counts, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch1_6_counts_forTMBandIFNA_250506.csv',
          row.names = F)
##tpm
tpm <- purrr::map_df(files, .f = read_excel, .id = "sample") %>% select(1:3,7) %>%
  tidyr::pivot_wider(names_from = 1, values_from = 4 )

write.csv(tpm, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch1_6_TPM_forTMBandIFNA_250506.csv',
          row.names = F)

### (IFNA and ) \IFN gammma from RNAseq vs TMB from DNAseq 20250506
#only tmb value
TMB <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch1_6_TMB.csv')
# gene expr
tpm <- fread('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch1_6_TPM_forTMBandIFNA_250506.csv')
colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch1_6_forTMBandIFNA_20250505.csv')
rownames(colData) <- colData$Accession_number

## expressionset
colData <- colData[order(colData$Patient_ID, colData$Treatment),]

tumorTPM <- ExpressionSet(assayData = tpm %>% dplyr::select(-1) %>% 
                            column_to_rownames('NCBI Gene ID') %>% 
                            dplyr::select(rownames(colData)) %>% as.matrix,
                          phenoData = AnnotatedDataFrame(colData),
                          featureData = AnnotatedDataFrame(
                            data.frame(symbol = tpm$`Gene Symbol`, row.names = tpm$`NCBI Gene ID`))
)

##log2(+1) converting expression data for TPMs
exprs(tumorTPM) <- log2(exprs(tumorTPM) + 1)
hist(rowMeans(exprs(tumorTPM)))
hist(rowVars(exprs(tumorTPM)))

##Subsetting to variable and expressed genes
rnaTUSE <- exprs(tumorTPM)[ which(rowMeans(exprs(tumorTPM)) > 2.5 & 
                                    rowVars(exprs(tumorTPM)) > 0.15), ]

##Getting tsne together
set.seed(777)
tstTSNE <- Rtsne(t(rnaTUSE),
                 check_duplicates=FALSE,
                 pca=TRUE,
                 perplexity=2,
                 theta=0.5,
                 dims=2)

##Making a dataframe for plotting
tstTSNEDF <- as.data.frame(tstTSNE$Y)
tstTSNEDF$Patient_ID <- factor(tumorTPM$Patient_ID)
#tstTSNEDF$Mosaic_ID <- factor(tumorTPM$Mosaic_ID)
tstTSNEDF$Treatment <- factor(tumorTPM$Treatment)
tstTSNEDF$Diagnosis <- factor(tumorTPM$Diagnosis)
tstTSNEDF$name <- factor(paste(tumorTPM$Patient_ID,tumorTPM$Treatment, tumorTPM$Diagnosis_edit, sep = '_'))
tstTSNEDF$Cohort <- factor(tumorTPM$Study)
tstTSNEDF$Batch_Type <- factor(tumorTPM$batchset)

##Plotting
ggplot(data = tstTSNEDF, aes(x = V1, y = V2, col = Batch_Type, label = name,shape = Cohort)) +
  #geom_label(size = 4) + 
  ggrepel::geom_label_repel(size = 3) + 
  geom_point(size = 5)+
  scale_x_continuous("tSNE X") +
  scale_y_continuous("tSNE Y") +
  #scale_color_manual(values = c("Archival Pre" = "navy","Fresh Pre" = 'black', 
  #                              "On-Treatment" = "red")) + 
  theme_classic(base_size = 10) +
  theme(plot.title = element_text(hjust = 0.5)) 

##Relabeling featureNames
rnaETPM <- tumorTPM
rnaETPM <- rnaETPM[ duplicated(fData(rnaETPM)$symbol) == FALSE, ]
featureNames(rnaETPM) <- fData(rnaETPM)$symbol

library(GSVA)
##IO atlas core genesets 
geneList <- readRDS('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/core_modules_01052023_rename.rds')
############# all gene sets
#geneList <- readRDS('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/modules_plus_singletons_01052023_rename.rds')

##Filtering
gLUSE <- GSVA::filterGeneSets(geneList, 
                              min.sz = 3, 
                              max.sz = 500)

##Scoring via ssGSEA
allRES <- GSVA::gsva(gsvaParam(as.matrix(rnaETPM),geneList))

annoSS <- pData(rnaETPM) %>% select(#"Diagnosis", 
                                    "BOR", 'Treatment')

##Heatmap
pheatmap(allRES,
         #labels_col = paste(annoFULL$Accession_number),
         show_colnames = TRUE, 
         show_rownames = TRUE,
         annotation_colors = list(#"Diagnosis" =   c("HNSCC" = "magenta",
           #                  "RCC" = "yellow"),
           "BOR" = c("CR" = "red",
                     "PD" = "grey60",
                     "SD" = "green",
                     'NE' = 'black',
                     'PR' = 'purple'),
           "Treatment" = c("Archival Pre" = "grey40","Fresh Pre" = 'grey', 
                           "On-Treatment" = "orange",'Normal-blood' = 'black')),
         
         color = colorpanel(100, "blue", "white", "red"),
         scale = "row",
         cluster_cols = FALSE,
         clustering_distance_rows = "euclidean",
         clustering_method = "ward.D2",
         annotation_col = annoSS,
         fontsize_col = 6.5)

IO_core_gsea <- allRES %>%  as.data.frame()%>% rownames_to_column('pathway') %>%
  pivot_longer(cols = 2:148,names_to = 'Accession_number',values_to = 'ssGSEAscore')

write.csv(IO_core_gsea, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch1_6_io_core_gsea.csv',row.names = F)

#only tmb value
TMB <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch1_6_TMB.csv')

## working table
wdf <- TMB %>% mutate(Accession_number = as.character(Accession_number)) %>% left_join(IO_core_gsea) %>% 
  filter(pathway == 'IFN.response', !is.na(BOR), BOR != 'NE') %>% 
  mutate(TMB_over_median = ifelse(TMBvalue >= median(TMBvalue), 'True','False'),
         IFNresponse_over_median = ifelse(ssGSEAscore >= median(ssGSEAscore), 'True','False'),
         group_BOR = ifelse(BOR %in% c('CR','PR'), 'CR_PR','SD_PD')) %>% 
  group_by(TMB_over_median, IFNresponse_over_median,group_BOR) %>% 
  count() %>% 
  pivot_wider(names_from = 'group_BOR',values_from = 'n') %>% 
  mutate(Ratio = CR_PR/SD_PD )

ggplot(wdf, aes(x = TMB_over_median, y = IFNresponse_over_median, fill = Ratio)) +
  geom_tile(color='white') +
  scale_fill_gradient2(low = 'white',high = 'red')+
  geom_text(aes(label=paste('CR+PR = ',CR_PR,'\n','SD+PD = ',SD_PD,sep='')), size =5)+
  labs(y='IFN gene set score over median', 
       fill = 'Ratio of (CR+PR)/\n(SD+PD)',
       title = 'TMB and IFN score correlation in batch 1-6 tumors')

##########################################################################################################
##### 7. tracking down the archival molecular data
##########################################################################################################

#1. filelsit

illumina124 <- read.table('~/PTPN2i/filenames_124_archives_illumina.txt',sep = '\t')
illumina431 <- read.table('~/PTPN2i/filenames_431_archives_illumina.txt',sep = '\t')

allilluminafile_tumors <- rbind(illumina124,illumina431) %>%
  
  separate(V1, into = c('v1','filepath'), sep = '000000_tmp_personalis') %>% 
  
  mutate(filepath = paste('/Resources/Archives/Illumina/Raw_Data/ILLUMINA_Data_Received/000000_tmp_personalis',filepath,sep = '')) %>%
  
  mutate(filetype = basename(filepath) 
  )

#read clinical sample shiping manifest, get paired tumor samples
## batch 5 and 6 MANIFEST
## BATCH 1-4 MANIFEST
colData_1_6_total <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/coldata_1_6_total.csv',stringsAsFactors = F)

#2. filter dna_statistics files

#filter report
final_list_edit <- allilluminafile_tumors[grepl(paste(c('rna_gene_expression_report.xlsx'
                                                        ),collapse = '|'),
                                          allilluminafile_tumors$filetype),]  
##batchset
final_list_edit <- final_list_edit %>% mutate(
  batchset = str_extract(filepath, '[Bb]atch\\d(_\\w+)') %>% 
    lapply(.,function(x) {head(strsplit(x, split = '_7')[[1]],1)[1]}) %>%
    unlist(),
  batchdate = str_extract(filepath, '\\d{4}_\\d{4}'),
  batchtotal = paste(batchset,batchdate,sep = '_')
) %>%
  mutate(Patient_ID = sapply(str_split(filetype, "_"), 
                             function(x) ifelse(nchar(x[2]) == 5, x[2], NA)),
         Mosaic_ID = sapply(str_split(filetype, "_"), 
                             function(x) ifelse(startsWith(x[3], "ML"), x[3], NA)),
         Accession_number = sapply(str_split(filetype, "_"), 
                                   function(x) ifelse(nchar(x[3]) >= 10, x[3], 
                                                      ifelse(nchar(x[2]) >= 10,x[2],NA))),
         Accession_number = ifelse(nchar(Accession_number)==12,
                                                              str_sub(Accession_number, end = -3),
                                   Accession_number)
        ) 

# remove repeated files
test <- final_list_edit %>% group_by(Patient_ID,Mosaic_ID) %>% 
  reframe(occurrance = paste(sort(unique(batchtotal)),collapse = ';')) %>% 
  mutate(final_segment = str_extract(occurrance,'[^;]+$'))

final_list_edit <- final_list_edit %>% filter(batchtotal %in% test$final_segment)

test <- final_list_edit %>% group_by(Patient_ID,Mosaic_ID) %>% 
  reframe(occurrance = paste(sort(unique(batchtotal)),collapse = '; '))

##3 add metadata
colData_1_6_total$Patient_ID <- as.character(colData_1_6_total$Patient_ID)
colData_1_6_total$Accession_number <- as.character(colData_1_6_total$Accession_number)

final_list <- final_list_edit %>% filter(is.na(Accession_number)) %>% select(-Accession_number) %>% 
  left_join(.,colData_1_6_total %>% select(Patient_ID,Mosaic_ID,Accession_number)) %>%
  rbind(final_list_edit %>% filter(!is.na(Accession_number))) %>% 
  left_join(., colData_1_6_total,by='Accession_number')

final_list <- final_list %>% filter(!duplicated(filetype))

## full manifest doesn't have treatment info
final_list_edit <- final_list[order(final_list$Accession_number),]

##save colData
write.csv(final_list_edit,'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batchIlluminaArchive_forTMBandIFNA_20250506.csv',row.names = F)

##4. download gene expression reports from s3 by print bash command lines and run command lines in terminal

## need to ssh to zhanyx3@ord-docker02 for illumina archival datta

for (i in 1: length(final_list_edit$filepath)) {
  
  s3_loc <- final_list_edit$filepath[i]
  filename <- paste(final_list_edit$batchset[i], final_list_edit$filetype[i],sep = '_')
  
  cmd <- paste(#'aws s3 
               'cp ', 
               s3_loc, 
               ' /homes/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumor_illuminaArchive_forTMBandIFNA/', 
               filename,sep = '') 
  ## /homes/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data is the location on aurora, not on magnus
  
  write(cmd,file = '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/bash_cp_cmd_illuminarchive_forTMBandIFNA.sh', append = T)
  
}

##5. extract count reads from each sample

files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumor_illuminaArchive_forTMBandIFNA/',
                    pattern = 'xlsx',full.names = T)

names(files) <- stringr::str_split(basename(files), pattern = '_tumor',simplify = T)[,1]

##counts
counts <- purrr::map_df(files, .f = read_excel, .id = "sample") %>% select(1:4) %>%
  tidyr::pivot_wider(names_from = 1, values_from = 4 )

write.csv(counts, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_illumina_counts_forTMBandIFNA_250506.csv',
          row.names = F)
##tpm
tpm <- purrr::map_df(files, .f = read_excel, .id = "sample") %>% select(1:3,7) %>%
  tidyr::pivot_wider(names_from = 1, values_from = 4 )

write.csv(tpm, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_illumina_TPM_forTMBandIFNA_250506.csv',
          row.names = F)

### IFN response from RNAseq vs TMB from DNAseq 20250506 batch 1-6
#only tmb value
TMB <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_illuminarchive_TMB.csv')
# gene expr

colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batchIlluminaArchive_forTMB_20250414.csv')

tpm <- fread('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_illumina_TPM_forTMBandIFNA_250506.csv')
idx <- match(colData$Mosaic_ID %>% as.character, 
             stringr::str_extract(colnames(tpm),pattern = 'ML\\d{7}') %>% as.character) %>% na.omit()
tpm_idx <- tpm %>% select(idx)
colnames(tpm_idx) <- stringr::str_extract(colnames(tpm_idx),pattern = 'ML\\d{7}') %>% as.character
rownames(tpm_idx) <- tpm$`NCBI Gene ID`

colData_idx <- colData %>% filter(Mosaic_ID %in% colnames(tpm_idx)) %>% column_to_rownames('Mosaic_ID')

## expressionset
colData_idx <- colData_idx[order(colData_idx$Patient_ID, colData_idx$Treatment),]

tumorTPM <- ExpressionSet(assayData = tpm_idx %>% 
                            dplyr::select(rownames(colData_idx)) %>% as.matrix,
                          phenoData = AnnotatedDataFrame(colData_idx),
                          featureData = AnnotatedDataFrame(
                            data.frame(symbol = tpm$`Gene Symbol`, row.names = tpm$`NCBI Gene ID`))
)

##log2(+1) converting expression data for TPMs
exprs(tumorTPM) <- log2(exprs(tumorTPM) + 1)
hist(rowMeans(exprs(tumorTPM)))
hist(rowVars(exprs(tumorTPM)))

##Subsetting to variable and expressed genes
rnaTUSE <- exprs(tumorTPM)[ which(rowMeans(exprs(tumorTPM)) > 2.5 & 
                                    rowVars(exprs(tumorTPM)) > 0.15), ]

##Getting tsne together
set.seed(777)
tstTSNE <- Rtsne(t(rnaTUSE),
                 check_duplicates=FALSE,
                 pca=TRUE,
                 perplexity=2,
                 theta=0.5,
                 dims=2)

##Making a dataframe for plotting
tstTSNEDF <- as.data.frame(tstTSNE$Y)
tstTSNEDF$Patient_ID <- factor(tumorTPM$Patient_ID)
#tstTSNEDF$Mosaic_ID <- factor(tumorTPM$Mosaic_ID)
tstTSNEDF$Treatment <- factor(tumorTPM$Treatment)
tstTSNEDF$Diagnosis <- factor(tumorTPM$Diagnosis)
tstTSNEDF$name <- factor(paste(tumorTPM$Patient_ID,tumorTPM$Treatment, tumorTPM$Diagnosis_edit, sep = '_'))
tstTSNEDF$Cohort <- factor(tumorTPM$Study)
tstTSNEDF$Batch_Type <- factor(tumorTPM$batchset)

##Plotting
ggplot(data = tstTSNEDF, aes(x = V1, y = V2, col = Batch_Type, label = name,shape = Cohort)) +
  #geom_label(size = 4) + 
  ggrepel::geom_label_repel(size = 3) + 
  geom_point(size = 5)+
  scale_x_continuous("tSNE X") +
  scale_y_continuous("tSNE Y") +
  #scale_color_manual(values = c("Archival Pre" = "navy","Fresh Pre" = 'black', 
  #                              "On-Treatment" = "red")) + 
  theme_classic(base_size = 10) +
  theme(plot.title = element_text(hjust = 0.5)) 

##Relabeling featureNames
rnaETPM <- tumorTPM
rnaETPM <- rnaETPM[ duplicated(fData(rnaETPM)$symbol) == FALSE, ]
featureNames(rnaETPM) <- fData(rnaETPM)$symbol

library(GSVA)
##IO atlas core genesets 
geneList <- readRDS('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/core_modules_01052023_rename.rds')
############# all gene sets
#geneList <- readRDS('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/modules_plus_singletons_01052023_rename.rds')

##Filtering
gLUSE <- GSVA::filterGeneSets(geneList, 
                              min.sz = 3, 
                              max.sz = 500)

##Scoring via ssGSEA
allRES <- GSVA::gsva(gsvaParam(as.matrix(rnaETPM),geneList))

annoSS <- pData(rnaETPM) %>% select(#"Diagnosis", 
  "BOR", 'Treatment')

##Heatmap
pheatmap(allRES,
         show_colnames = TRUE, 
         show_rownames = TRUE,
         annotation_colors = list(#"Diagnosis" =   c("HNSCC" = "magenta",
           #                  "RCC" = "yellow"),
           "BOR" = c("CR" = "red",
                     "PD" = "grey60",
                     "SD" = "green",
                     'NE' = 'black',
                     'PR' = 'purple'),
           "Treatment" = c("Archival Pre" = "grey40","Fresh Pre" = 'grey', 
                           "On-Treatment" = "orange",'Normal-blood' = 'black')),
         
         color = colorpanel(100, "blue", "white", "red"),
         scale = "row",
         cluster_cols = FALSE,
         clustering_distance_rows = "euclidean",
         clustering_method = "ward.D2",
         annotation_col = annoSS,
         fontsize_col = 6.5)

IO_core_gsea <- allRES %>%  as.data.frame()%>% rownames_to_column('pathway') %>%
  pivot_longer(cols = 2:24,names_to = 'Mosaic_ID',values_to = 'ssGSEAscore')

write.csv(IO_core_gsea,'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_illuminarchive_io_core_gsea.csv',row.names = F)

#only tmb value
TMB <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_illuminarchive_TMB.csv')

## working table
wdf_illumina <- TMB %>% mutate(Mosaic_ID = as.character(Mosaic_ID)) %>% left_join(IO_core_gsea) %>% 
  filter(pathway == 'IFN.response', !is.na(BOR), BOR != 'NE') %>% 
  mutate(TMB_over_median = ifelse(TMBvalue >= median(TMBvalue), 'True','False'),
         IFNresponse_over_median = ifelse(ssGSEAscore >= median(ssGSEAscore), 'True','False'),
         group_BOR = ifelse(BOR %in% c('CR','PR'), 'CR_PR','SD_PD')) %>% 
  group_by(TMB_over_median, IFNresponse_over_median,BOR) %>% 
  count() %>% 
  pivot_wider(names_from = 'BOR',values_from = 'n') %>% 
  mutate(Ratio = SD/PD )

ggplot(wdf_illumina, aes(x = TMB_over_median, y = IFNresponse_over_median, fill = Ratio)) +
  geom_tile(color='white') +
  scale_fill_gradient2(low = 'white',high = 'red')+
  geom_text(aes(label=paste('SD = ',SD,'\n','PD = ',PD,sep='')), size =5)+
  labs(y='IFN gene set score over median', 
       fill = 'Ratio of SD/PD',
       title = 'TMB and IFN score correlation in illuminaArchival tumors')

##########################################################################
### IFN response vs mutation TMB in tumor samples 20250520
#########################################################################

IO_core_gsea <- read_csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch1_6_io_core_gsea.csv',
                         col_types = cols(.default = "c"))
## working table
wdf <- read_csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch1_6_TMB.csv',
                col_types = cols(.default = "c")) %>% 
  mutate(Accession_number = as.character(Accession_number)) %>% left_join(IO_core_gsea) %>% 
  filter(pathway == 'IFN.response', !is.na(BOR), BOR != 'NE') %>% 
  mutate(TMB_over_median = ifelse(TMBvalue >= median(TMBvalue), 'True','False'),
         IFNresponse_over_median = ifelse(ssGSEAscore >= median(ssGSEAscore), 'True','False'),
         group_BOR = ifelse(BOR %in% c('CR','PR'), 'CR_PR','SD_PD')) 

## illumina data
IO_core_gsea_illumina <- read_csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_illuminarchive_io_core_gsea.csv',
                         col_types = cols(.default = "c"))

wdf_illumina <- read_csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_illuminarchive_TMB.csv',
                col_types = cols(.default = "c")) %>% 
  mutate(Accession_number = as.character(Accession_number.y)) %>% left_join(IO_core_gsea_illumina) %>% 
  filter(pathway == 'IFN.response', !is.na(BOR), BOR != 'NE') %>% 
  mutate(TMB_over_median = ifelse(TMBvalue >= median(TMBvalue), 'True','False'),
         IFNresponse_over_median = ifelse(ssGSEAscore >= median(ssGSEAscore), 'True','False'),
         group_BOR = ifelse(BOR %in% c('CR','PR'), 'CR_PR','SD_PD')) 

## total working table

names <- intersect(colnames(wdf),colnames(wdf_illumina))

wdf_final <- rbind(wdf[,names], wdf_illumina[,names]) %>% 
  filter(!duplicated(Accession_number))

wdf_final_all <- wdf_final %>% 
  group_by(TMB_over_median, IFNresponse_over_median,group_BOR) %>% 
  count() %>% 
  pivot_wider(names_from = 'group_BOR',values_from = 'n') %>% 
  mutate(Ratio = CR_PR/SD_PD )

ggplot(wdf_final_all, aes(x = TMB_over_median, y = IFNresponse_over_median, fill = Ratio)) +
  geom_tile(color='white') +
  scale_fill_gradient2(low = 'white',high = 'red')+
  geom_text(aes(label=paste('CR+PR = ',CR_PR,'\n','SD+PD = ',SD_PD,sep='')), size =5)+
  labs(y='IFN gene set score over median', 
       fill = 'Ratio of (CR+PR)/\n(SD+PD)',
       title = 'TMB and IFN score correlation in tumors from both trials')

## break down by study 
ggplot(wdf_final %>% group_by(TMB_over_median, IFNresponse_over_median,group_BOR,Study) %>% 
         count() %>% pivot_wider(names_from = 'group_BOR',values_from = 'n') %>% 
         mutate(Ratio = CR_PR/SD_PD ) %>% 
         filter(Study == 'M20-124'), 
       aes(x = TMB_over_median, y = IFNresponse_over_median, fill = Ratio)) +
  geom_tile(color='white') +
  scale_fill_gradient2(low = 'white',high = 'red')+
  geom_text(aes(label=paste('CR+PR = ',CR_PR,'\n','SD+PD = ',SD_PD,sep='')), size =5)+
  labs(y='IFN gene set score over median', 
       fill = 'Ratio of (CR+PR)/\n(SD+PD)',
       title = 'TMB and IFN score correlation in tumors')


