library(dplyr)
library(data.table)
library(tidyr)
library(readxl)
library(stringr)
library(readr)
library(ggplot2)


##aws s3 ls s3://abv-arrayserver/CloudDataRoot/Oncology/Clinical/personalis/M20-431/ 
##--profile arrayserver --recursive --human-readable --summarize > filenames_431.txt

##aws s3 ls s3://abv-arrayserver/CloudDataRoot/Oncology/Clinical/personalis/M20-124/ 
#--profile arrayserver --recursive --human-readable --summarize > filenames_124.txt

file_431 <- read.table('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/filenames_431_250113.txt',
                       sep = '\t') %>% 
  separate(V1, into = c('v1','filepath'), sep = 'CloudDataRoot') %>% 
  mutate(filepath = paste('CloudDataRoot',filepath,sep = '')) %>%
  mutate(filetype = lapply(filepath, function(x) {tail(strsplit(x,split = '/')[[1]], 1)}
  ) %>% unlist(),
  suffix = lapply(filetype, function(x) {tail(strsplit(x,split = '\\.')[[1]], 1)}
  ) %>% unlist(),
  
  pipeline = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 1)}
  ) %>% unlist(),
  
  Accession_Number_original = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 2)[2]}
  ) %>% unlist()
  ) %>%
  mutate(
    batchset = str_extract(filepath, 'Batch\\d(_\\w+)') %>% 
      lapply(.,function(x) {head(strsplit(x, split = '_7')[[1]],1)[1]}) %>%
      unlist(),
    batchdate = str_extract(filepath, '\\d{4}_\\d{4}'),
    batchtotal = paste(batchset,batchdate,sep = '_')
  ) %>% 
  filter(pipeline %in% c('RNA', 'DNA')) %>% 
  filter(!is.na(batchdate))
  

file_124 <- read.table('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/filenames_124_250113.txt',
                       sep = '\t') %>% 
  separate(V1, into = c('v1','filepath'), sep = 'CloudDataRoot') %>% 
  mutate(filepath = paste('CloudDataRoot',filepath,sep = '')) %>% 
  mutate(filetype = lapply(filepath, function(x) {tail(strsplit(x,split = '/')[[1]], 1)}
  ) %>% unlist(),
  suffix = lapply(filetype, function(x) {tail(strsplit(x,split = '\\.')[[1]], 1)}
  ) %>% unlist(),
  
  pipeline = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 1)}
  ) %>% unlist(),
  
  Accession_Number_original = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 2)[2]}
  ) %>% unlist()
  ) %>%
  mutate(
    batchset = str_extract(filepath, 'Batch\\d(_\\w+)') %>% 
      lapply(.,function(x) {head(strsplit(x, split = '_7')[[1]],1)[1]}) %>%
      unlist(),
    batchdate = str_extract(filepath, '\\d{4}_\\d{4}'),
    batchtotal = paste(batchset,batchdate,sep = '_')
  ) %>% 
  filter(pipeline %in% c('RNA','DNA')) %>% 
  filter(!is.na(batchdate))

## sanity check
length(unique(file_431$Accession_Number_original))
#[1] 206

length(unique(file_124$Accession_Number_original))
#[1] 115

## per sample batch date / batchtotal
df431 <- file_431 %>% 
  group_by(Accession_Number_original,
           batchset,
           batchdate,
           batchtotal) %>% 
  reframe(n())

df124 <- file_124 %>% 
  group_by(Accession_Number_original,
           batchset,
           batchdate,
           batchtotal) %>% 
  reframe(n())



#read clinical sample shiping manifest, get paired tumor samples
manifest <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/M20_431_and_M20_124_Personalis_Shipment_Summary_6Aug2024_yz_mj.xlsx', 
                               sheet = 4) %>% 
  mutate(Accession_Number = parse_number(Accession_Number),
         Accession_number = Accession_Number) %>%
  mutate(Accession_number = ifelse(nchar(Accession_number)==12,
                                   str_sub(Accession_number, end = -3),
                                   Accession_number)) %>%
  dplyr::select(-Annotation) %>%
  dplyr::rename('Accession_Number_original' = 'Accession_Number')

table(manifest[!duplicated(manifest$Accession_Number_original),]$Cohort)

## sanity check
#M20-124 M20-431 
#143     242 

# add M20-124 and M20-431 togather
matches_rna <- rbind(file_124,file_431) %>%
  mutate(Accession_Number_original = parse_number(Accession_Number_original))

#filter gene expression,TCT,BCR,MUTATION,copynumber,NEOANTIGEN,IMMUNOGENOMICS

matches_exp_report <- matches_rna[grepl(paste(c('rna_gene_expression_report.xlsx',
                                                "tcr_beta_clone_report.xlsx",
                                                'bcr_heavy_chain_report.xlsx',
                                                'somatic_dna_small_variant_report_preferred.xlsx',
                                                'somatic_dna_gene_cna_report.xlsx',
                                                'neoantigen_statistics.tsv',
                                                'immunogenomics_report.xlsx'),collapse = '|'), 
                                        matches_rna$filetype),]
## add metadata

final_list <- matches_exp_report %>% right_join(manifest) 

#colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch245_colData_0903.csv')
##colData

clinical_124 <- read_excel(paste('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/',
                             'PTPN2_Clinical_Metadata_08AUG24_Final.xlsx',sep=''),sheet = 1)
colnames(clinical_124)[17] <- 'Expansion_Cohort'
clinical_124 <- clinical_124 %>% select(1:15,17,16)
clinical_124$group <- 'M20-124'

clinical_431 <- read_excel(paste('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/',
                                 'PTPN2_Clinical_Metadata_08AUG24_Final.xlsx',sep=''),sheet = 2) %>%
  mutate(group = 'M20-431')

# merge 124 and 431
colnames(clinical_124) <- colnames(clinical_431)
clinical <- rbind(clinical_124,clinical_431)

## total list

total_list <- final_list %>% mutate(Subject_ID = parse_number(Patient_ID)) %>%
  left_join(clinical)

write.csv(total_list, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/final_list_inventory_124_431.csv',row.names = F)

##############################################################################################
## working on totla list
##############################################################################################

total_list <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/final_list_inventory_124_431.csv')

total_list <- total_list %>% 
  mutate(filename = str_extract(total_list$filetype,paste(c('gene_expression',
                                                "tcr",
                                                'bcr',
                                                'somatic_dna_small_variant',
                                                'somatic_dna_gene_cna',
                                                'neoantigen',
                                                'immunogenomics'),collapse = '|')
))


## break down

df <- total_list %>% group_by(Cohort,Subject_ID,Batch_Type, Treatment,Accession_Number_original,
                              Diagnosis_Standardized,Monotherapy_or_Combination,BOR,X484_Dose_.mg.) %>%
  reframe(filenumber = n(),
          filename = paste(sort(unique(filename)),collapse = '; ')) %>%
  mutate(data_availability = ifelse(filenumber == 1, 'No_data_available', 'files_available')) %>%
  filter(!duplicated(Accession_Number_original))

table(df$Cohort,df$data_availability)

df %>% ggplot(aes(x = data_availability,fill = Batch_Type )) +
  geom_bar(position = 'dodge',stat = 'count') +
  theme_classic() +
  facet_wrap(~Cohort,nrow = 1) +
  labs(x='',fill='')

df %>% filter(data_availability == 'files_available',filename!='') %>% 
  ggplot(aes(x = data_availability,fill = as.factor(filename) )) +
  geom_bar(position = 'dodge',stat = 'count',color='black') +
  theme_classic() +
  facet_wrap(~Cohort+Batch_Type,nrow = 1) +
  labs(x='',fill='') +
  theme(legend.position = 'bottom')+
  guides(fill=guide_legend(nrow=4,byrow=T))


## shipment summary 

df %>% 
  ggplot(aes(x = Diagnosis_Standardized,fill = as.factor(Batch_Type) )) +
  geom_bar(position = 'dodge',stat = 'count',color='black') +
  theme_classic() +
  facet_wrap(~Cohort,nrow = 2) +
  labs(x='',fill='') +
  theme(legend.position = 'top',
        axis.text.x = element_text(angle = 90))+
  guides(fill=guide_legend(nrow=1,byrow=F))
  
df %>% filter(data_availability == 'files_available',filename!='') %>% 
  ggplot(aes(x = Diagnosis_Standardized,fill = as.factor(filename) )) +
  geom_bar(position = 'dodge',stat = 'count',color='black') +
  theme_classic() +
  facet_wrap(~Cohort+Batch_Type,nrow = 1,scales = 'free_x') +
  labs(x='',fill='') +
  theme(legend.position = 'top',
        axis.text.x = element_text(angle = 90,size=8))+
  guides(fill=guide_legend(nrow=4,byrow=T))


## shipment summary by mono or combo

df %>% 
  ggplot(aes(x = Monotherapy_or_Combination )) +
  geom_bar(position = 'dodge',stat = 'count',color='black') +
  theme_classic() +
  facet_wrap(~Cohort,nrow = 1,scales = 'free_x') +
  labs(x='',fill='') +
  theme(legend.position = 'top',
        axis.text.x = element_text(angle = 90))+
  guides(fill=guide_legend(nrow=1,byrow=F))

df %>% filter(data_availability == 'files_available',filename!='') %>% 
  ggplot(aes(x = Monotherapy_or_Combination,fill = as.factor(filename) )) +
  geom_bar(position = 'dodge',stat = 'count',color='black') +
  theme_classic() +
  facet_wrap(~Cohort+Batch_Type+Treatment,nrow = 1,scales = 'free_x') +
  labs(x='',fill='') +
  theme(legend.position = 'top',
        axis.text.x = element_text(angle = 90,size=8))+
  guides(fill=guide_legend(nrow=4,byrow=T))

### output individual file type with subjectID

df_avail <- df %>% filter(data_availability == 'files_available')

output <- total_list %>% filter(Accession_Number_original %in% df_avail$Accession_Number_original) %>% 
  select(filepath,filetype,Subject_ID, Cohort,Batch_Type, Accession_Number_original,filename)

table(output$filename)

l <- list(expression = output %>% filter(filename == 'gene_expression'), 
          tcr = output %>% filter(filename == 'tcr'),
          bcr = output %>% filter(filename == 'bcr')
          #,
          #somatic_dna_snv = output %>% filter(filename == 'somatic_dna_small_variant'),
          #somatic_dna_gene_cna = output %>% filter(filename == 'somatic_dna_gene_cna'),
          #immunogenomics = output %>% filter(filename == 'immunogenomics'),
          #neoantigen = output %>% filter(filename == 'neoantigen')
          )

openxlsx::write.xlsx(l, file = "~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/M20_124_M20_431_data_inventory.xlsx")

###20241017 only tumor pairs from M20-124 and M20-431

### output individual file type with subjectID

df_avail_pairs <- df %>% filter(data_availability == 'files_available' &
                                  filename != '')

output <- total_list %>% filter(Accession_Number_original %in% df_avail_pairs$Accession_Number_original) %>% 
  select(filepath,filetype,Subject_ID, Cohort,Batch_Type, Accession_Number_original,filename)

table(output$filename)

l <- list(expression = output %>% filter(filename == 'gene_expression')
          #, 
          #tcr = output %>% filter(filename == 'tcr'),
          #bcr = output %>% filter(filename == 'bcr')
          #,
          #somatic_dna_snv = output %>% filter(filename == 'somatic_dna_small_variant'),
          #somatic_dna_gene_cna = output %>% filter(filename == 'somatic_dna_gene_cna'),
          #immunogenomics = output %>% filter(filename == 'immunogenomics'),
          #neoantigen = output %>% filter(filename == 'neoantigen')
)

openxlsx::write.xlsx(l, file = "~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/M20_124_M20_431_data_inventory_Paul_tumor_expression.xlsx")

table()


### tumor pairs data available 2+6 pairs

### output individual file type with subjectID

df_avail_pairs <- df %>% filter(data_availability == 'files_available' & Batch_Type == 'Tumor/Normal' &
                                  filename != '' &
                                  Subject_ID %in% c('30012','50007','2203',
                                                    '2204', '2207','2209','2501','2801'))

ggplot(df_avail_pairs,aes(Subject_ID, fill = filename)) +
  geom_bar()

   
df_avail_pairs %>% 
  ggplot(aes(x = Subject_ID,fill = as.factor(filename) )) +
  geom_bar(position = 'dodge',stat = 'count',color='black') +
  theme_classic() +
  facet_wrap(~Cohort+Batch_Type,nrow = 1,scales = 'free_x') +
  labs(x='',fill='') +
  theme(legend.position = 'top',
        axis.text.x = element_text(angle = 90,size=8))+
  guides(fill=guide_legend(nrow=1,byrow=T))











