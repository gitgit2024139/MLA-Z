library(tidyverse)
library(dplyr)
library(readxl)
library(data.table)
library(Biobase)
library(genefilter)
library(Rtsne)
library(ggplot2)
library(gridExtra)
library(pheatmap)
library(gplots)
library(limma)
library(RColorBrewer)
library(reshape)
library(GSVA)
library(qusage)
library(quantiseqr)

##M20-431
#counts <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_rawCounts.csv')
tpm <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_TPM.csv')
colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_colData.csv',
                    row.names = 1) %>%
  select(c(1,4,7:9,17,22))

##M20-124 paired tumors
#counts_124 <- readRDS('~/PTPN2i/Kyle_code/all_counts_expset_2024-01-22.rds')
tpm_124 <- readRDS('~/PTPN2i/Kyle_code/all_tpm_expset_2024-01-22.rds')
## As for 579, we have only two pairs (30012 – NSCLC and 50007 – Melanoma)
  
manifest <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/ptpn2i_shipment_manifest.xlsx', 
                               sheet = 4) %>% 
  filter(Cohort == 'M20-124',Annotation == 'PAIR', Visit %in% c('C1D1','C2D1'))

colData_124 <- pData(tpm_124) %>%
  filter(Samp_ID %in% c('30012','50007')) %>%
  mutate(Mosaic_ID = str_extract(rownames(.),pattern = 'ML\\d+')) %>% 
  left_join(.,manifest,by = 'Mosaic_ID') %>%
  mutate(Treatment = ifelse(Visit == 'C1D1','Fresh Pre', 'On-Treatment')) %>%
  select(colnames(colData)) 

rownames(colData_124) <- paste(colData_124$Patient_ID,colData_124$Mosaic_ID,sep='_')

rowData_124 <- fData(tpm_124)
  
tpm_124 <- exprs(tpm_124[,rownames(colData_124)])

## merge exprs & colData
rownames(tpm) <- tpm$NCBI.Gene.ID

tpm_merge <- cbind(tpm[rownames(tpm_124),],tpm_124)
colData_merge <- rbind(colData,colData_124)
colData <- colData_merge

##Making diagnosis a little easier to work around from Kyle's code 20240912
colData$Diagnosis_edit <- colData$Diagnosis
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Breast Cancer (TNBC)", "Breast Cancer"))] <- "Breast"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("TNBC"))] <- "Breast"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Sigmoid colon cancer"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Adenocarcinoma of rectum", "Colon Cancer", "Colorectal Cancer"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Rectal Adenocarcinoma"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("MSI-H CRC"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("MSS CRC"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Malignant neoplasma of tonsil (HNSCC)"))] <- "HNSCC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Pancreatic Cancer"))] <- "Pancreatic"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Malignant Melanoma", "Melanoma"))] <- "Melanoma"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Soft Tissue Sarcoma", "Anaplastic Soft Tissue Sarcoma",
                                                            "Sarcoma", "Retropertioneal Synovial Sarcoma", "Chondrosarcoma",
                                                            "Clear Cell Sarcoma", "Myxoid Liposarcoma"))] <- "Sarcoma"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Urethral", "Urothelial Carcinoma"))] <- "Urothelial"
otherTmrs <- names(which(table(colData$Diagnosis_edit) <= 2))
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% otherTmrs)] <- "Other"


###############################################################################################
##1. load
###############################################################################################

tumorTPM <- ExpressionSet(assayData = tpm_merge %>% dplyr::select(-1) %>% 
                        #column_to_rownames('NCBI.Gene.ID') %>% 
                          dplyr::select(rownames(colData)) %>% as.matrix,
                      phenoData = AnnotatedDataFrame(colData),
                      featureData = AnnotatedDataFrame(
                        data.frame(symbol = rowData_124$external_gene_name, 
                                   row.names = rowData_124$entrezgene_id,
                                   description = rowData_124$description))
                      )

##log2(+1) converting expression data for TPMs
exprs(tumorTPM) <- log2(exprs(tumorTPM) + 1)

# QC plots
#Plotting some QC plots prior to differential expression analysis. 

hist(rowMeans(exprs(tumorTPM)))

##Histogram of row vars
hist(rowVars(exprs(tumorTPM)))

#Potentially an outlier. Checking which genes are over 15. 

intGenes <- which(rowVars(exprs(tumorTPM)) > 15)
intGS <- fData(tumorTPM)$symbol[ which(featureNames(tumorTPM) %in% intGenes)]

print(intGS)


#Alright, some reasonable genes in there (H2BC3 in particular) but others
#not sure why variance so high. Will not exclude, but will monitor for inclusion
#in analysis down the road. 

# Sample distribution
# Now working on sample distribution, specifically to see what the sample-sample
# relationships are. 

## Sample expression tSNE

##Subsetting to variable and expressed genes
rnaTUSE <- exprs(tumorTPM)[ which(rowMeans(exprs(tumorTPM)) > 2.5 & 
                                  rowVars(exprs(tumorTPM)) > 0.15), ]

##Getting tsne together
set.seed(777)
tstTSNE <- Rtsne(t(rnaTUSE),
                 check_duplicates=FALSE,
                 pca=TRUE,
                 perplexity=2,
                 theta=0.5,
                 dims=2)

##Making a dataframe for plotting
tstTSNEDF <- as.data.frame(tstTSNE$Y)
tstTSNEDF$Patient_ID <- factor(tumorTPM$Patient_ID)
tstTSNEDF$Mosaic_ID <- factor(tumorTPM$Mosaic_ID)
tstTSNEDF$Treatment <- factor(tumorTPM$Treatment)
tstTSNEDF$Diagnosis <- factor(tumorTPM$Diagnosis)
tstTSNEDF$Cohort <- factor(tumorTPM$Cohort)

##Plotting
ggplot(data = tstTSNEDF, aes(x = V1, y = V2, col = Treatment, label = Cohort)) +
  geom_label(size = 4) + 
  geom_text(size = 3, aes(y = V2 - 50, label = Patient_ID)) + 
  scale_x_continuous("tSNE X") +
  scale_y_continuous("tSNE Y") +
  scale_color_manual(values = c("Archival Pre" = "navy","Fresh Pre" = 'black', 
                                "On-Treatment" = "red")) + 
  theme_classic(base_size = 10) +
  theme(plot.title = element_text(hjust = 0.5)) + 
  guides(color = guide_none())

## Heatmap of key genes

##Plotting some relevant genes
intGenes <- c("CD274", "CXCL9", "CXCL10", "IFNG", "GZMB", "PRF1", "CD3E", "CD4",
              "CD8A", "NKG7",'NKG2D','TRGV4','TRDV1', "KLRC1", "ARG1", "CLEC9A", "CD68", "CD163",
              "FOXP3", "CTLA4", "ICOS", "HAVCR2", "MKI67", "CENPA")

##Subsetting to only these genes
rnaLINT <- tumorTPM[ which(fData(tumorTPM)$symbol %in% intGenes), ]

##Peeling off, subsetting annotation data
annoSS <- pData(rnaLINT) %>% dplyr::select(#"Patient_ID", #"Mosaic_ID", 
                                    "Diagnosis", "BOR", 
                                     # "Months on Treatment",
                                    'Treatment' )

##Heatmap
pheatmap(exprs(rnaLINT[,rownames(colData[order(colData$Patient_ID,colData$Treatment),])]),
         labels_row = fData(rnaLINT)$symbol,
         labels_col = pData(rnaLINT)$Patient_ID,
         show_colnames = TRUE, 
         show_rownames = TRUE,
         annotation_colors = list("Diagnosis" =   c("HNSCC" = "magenta",
                                                "RCC" = "yellow",
                                                'NSCLC' = 'navy',
                                                'Melanoma' = 'white'),
                                  "BOR" = c("CR" = "red",
                                            "PD" = "grey20",
                                            "SD" = "green"),
                                  "Treatment" = c("Archival Pre" = "grey40","Fresh Pre" = 'grey', 
                                                  "On-Treatment" = "orange")),
         
         color = colorpanel(100, "blue", "white", "red"),
         scale = "row",
         clustering_distance_rows = "euclidean",
         clustering_method = "ward.D2",
         cluster_rows = T,
         cluster_cols = F,
         annotation_col = annoSS)

##Getting clustering
allClust <- hclust(dist(scale(t(exprs(rnaLINT)))), method = "ward.D2")

##assignments
clustAssign <- cutree(allClust, k = 4)

plot(allClust, labels = clustAssign)

# clustEdit <- clustAssign
# clustEdit[which(clustEdit %in% c(1,4))] <- "Inflamed"
# clustEdit[which(clustEdit == 2)] <- "Proliferative/Moderate"
# clustEdit[which(clustEdit == 3)] <- "Cold"

##Saving this real quick
# saveRDS(clustEdit, file = "../results/tme_assignments_2024-02-16.rds")


## Difference in key genes across pre/post samples

##Subsetting to only key genes for the paired samples
# rnaLPAIR <- rnaLINT[ , which(rnaLINT$Samp_ID %in% c("30012", "50007"))]

##Melting expression
rnaLPMELT <- as.data.frame(melt(exprs(rnaLINT), ))
colnames(rnaLPMELT) <- c("gene_id", "sample_id", "expression")

rnaLPMELT <- pData(rnaLINT) %>% rownames_to_column(var = 'sample_id') %>% 
  merge(.,rnaLPMELT) %>% merge(., fData(rnaLINT) %>% rownames_to_column('gene_id'))

## generate 2501 expression df and coldata
# rnaLINT <- tumorTPM
# rnaLPMELT <- as.data.frame(melt(exprs(rnaLINT), ))
# colnames(rnaLPMELT) <- c("gene_id", "sample_id", "expression")
# rnaLPMELT <- pData(rnaLINT) %>% rownames_to_column(var = 'sample_id') %>% 
#   merge(.,rnaLPMELT) %>% merge(., fData(rnaLINT) %>% rownames_to_column('gene_id'))
# 
# rnaLPMELT <- rnaLPMELT %>% filter(Patient_ID == '2501') %>% select(1:3,24:26)
# 
# expdf <- rnaLPMELT %>% select(2,5,6) %>% pivot_wider(names_from = 1, values_from = 2) 
# write.csv(expdf, 'CR_expression_TPM.csv')
# 
# metadf <- rnaLPMELT %>% select(2:4) %>% filter(!duplicated(sample_id))
# write.csv(metadf, 'CR_metadata.csv')


#Now plotting as barplots I guess for now. 

order <- c("MKI67", "CENPA","CD274","CTLA4","CXCL9", "CXCL10", "IFNG", "CD3E", "CD4",
              "CD8A", "NKG7",'NKG2D',"GZMB", "PRF1", "KLRC1", "CLEC9A", "CD68", "CD163","ARG1", 
              "FOXP3", "HAVCR2","ICOS")

ggplot(rnaLPMELT %>% mutate(symbol = factor(symbol,levels = order)), 
       aes(x = Treatment, y = expression, fill = Treatment)) +
  geom_bar(stat = "identity") + 
  facet_grid(Patient_ID ~ symbol) + 
  theme_bw(base_size = 10,base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0, "cm"), 
        axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
        legend.position = 'top',strip.background = element_rect(fill = 'white')) +
  labs(x = '', y = 'Expression log2(tpm + 1)', fill = '') 

#Looks quite good actually. Redoing, but with PTPN2-specific genes attached. 

##Plotting some relevant genes
intGenes <- c("PTPN1", "PTPN2", "JAK1", "JAK3", "STAT1", "STAT3", "STAT5A", "STAT5B")

##Subsetting to only these genes
rnaLINT <- tumorTPM[ which(fData(tumorTPM)$symbol %in% intGenes), ]

##Melting expression
rnaLPMELT <- as.data.frame(melt(exprs(rnaLINT), ))
colnames(rnaLPMELT) <- c("gene_id", "sample_id", "expression")

rnaLPMELT <- pData(rnaLINT) %>% rownames_to_column(var = 'sample_id') %>% 
  merge(.,rnaLPMELT) %>% merge(., fData(rnaLINT) %>% rownames_to_column('gene_id'))

##And plotting
ggplot(rnaLPMELT, aes(x = Treatment, y = expression, fill = Treatment)) +
  geom_bar(stat = "identity") + 
  facet_grid(Patient_ID ~ symbol) + 
  theme_bw(base_size = 10,base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0, "cm"), 
        axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
        legend.position = 'top',strip.background = element_rect(fill = 'white')) +
  labs(x = '', y = 'Expression log2(tpm + 1)', fill = '') 

##20240909 plot top DEG identified from blood samples in 431 cohort

topgene <- read_excel('~/PTPN2i/Kyle_code/combined_ptpn2i_blood_de_results_2024-08-23.xlsx',sheet = 3)
##Plotting some relevant genes
intGenes <- topgene$external_gene_name[1:20]

##Subsetting to only these genes
rnaLINT <- tumorTPM[ which(fData(tumorTPM)$symbol %in% intGenes), ]

##Melting expression
rnaLPMELT <- as.data.frame(melt(exprs(rnaLINT), ))
colnames(rnaLPMELT) <- c("gene_id", "sample_id", "expression")

rnaLPMELT <- pData(rnaLINT) %>% rownames_to_column(var = 'sample_id') %>% 
  merge(.,rnaLPMELT) %>% merge(., fData(rnaLINT) %>% rownames_to_column('gene_id'))

##And plotting

ggplot(rnaLPMELT, aes(x = Treatment, y = expression)) +
  geom_boxplot(aes(fill = Treatment), alpha = .4)+
  geom_line(aes(group = Patient_ID),linetype = 2) + 
  geom_point(size=1.5,shape = 21, aes(fill = Treatment)) +
  facet_wrap(~ symbol,nrow = 3,scales = 'free_x') + 
  theme_bw(base_size = 10,base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0, "cm"), 
        axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
        legend.position = 'right',strip.background = element_rect(fill = 'white')) +
  labs(x = '', y = 'Expression (log2 TPM + 1)', fill = '') 

# no archival pre

ggplot(rnaLPMELT %>% filter(Treatment != 'Archival Pre'), aes(x = Treatment, y = expression)) +
  geom_boxplot(aes(fill = Treatment), alpha = .4)+
  geom_line(aes(group = Patient_ID),linetype = 2) + 
  geom_point(size=1.5,shape = 21, aes(fill = Treatment)) +
  facet_wrap(~ symbol,nrow = 2) + 
  theme_bw(base_size = 10,base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0, "cm"), 
        axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
        legend.position = 'right',strip.background = element_rect(fill = 'white')) +
  labs(x = '', y = 'Expression (log2 TPM + 1)', fill = '') 


# Gene set analysis
## Gene set scoring for sample TME composition
#First calculating TME composition via gene set scores from IO Atlas project. 
#Doing this as a quick first-pass for composition. 

##Relabeling featureNames
rnaETPM <- tumorTPM
rnaETPM <- rnaETPM[ duplicated(fData(rnaETPM)$symbol) == FALSE, ]
featureNames(rnaETPM) <- fData(rnaETPM)$symbol

##Loading gene sets
#library(qusage)
#geneList <-qusage::read.gmt('modules_plus_singletons_01052023_rename.gmt')
#saveRDS(geneList,'modules_plus_singletons_01052023_rename.rds')
#geneList <-qusage::read.gmt('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/core_modules_01052023_rename.gmt')
#saveRDS(geneList,'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/core_modules_01052023_rename.rds')

geneList <- readRDS('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/core_modules_01052023_rename.rds')

##Filtering
gLUSE <- GSVA::filterGeneSets(geneList, 
                        min.sz = 3, 
                        max.sz = 500)

##Scoring via ssGSEA
allRES <- gsva(expr = exprs(rnaETPM), 
               gset.idx.list = gLUSE,
               method = "ssgsea", 
               ssgsea.norm = F)



#Some jank in there, but seems to have run fine. 

saveRDS(allRES, file = "~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/results/core_geneset_gsva.rds")

## Heatmap of gene sets
#Going to use prior heatmap ordering here, with a subset of gene sets. 

##Peeling off, subsetting annotation data
annoFULL <- pData(rnaETPM)
annoFULL$Sample_label <- paste(annoFULL$Patient_ID,annoFULL$Treatment,sep = '_')
annoSS <- annoFULL %>% select("Patient_ID", #"Mosaic_ID", 
  "Diagnosis", "BOR", 
  # "Months on Treatment",
  'Treatment')

##Heatmap
pheatmap(allRES,
         labels_col = annoFULL$Patient_ID,
         show_colnames = TRUE, 
         show_rownames = TRUE,
         annotation_colors = list("Diagnosis" =   c("HNSCC" = "magenta",
                                                    "RCC" = "yellow",
                                                    'NSCLC' = 'navy',
                                                    'Melanoma' = 'white'),
                                  "BOR" = c("CR" = "red",
                                            "PD" = "grey20",
                                            "SD" = "green"),
                                  "Treatment" = c("Archival Pre" = "grey40","Fresh Pre" = 'grey', 
                                                  "On-Treatment" = "orange")),
         
         color = colorpanel(100, "blue", "white", "red"),
         scale = "row",
         cluster_cols = FALSE,
         clustering_distance_rows = "euclidean",
         clustering_method = "ward.D2",
         annotation_col = annoSS)

#corresponds well with the gene-level visualization. Going to save this as well. 

############# other gene sets
##Heatmap
library(msigdbr)

h_gene_sets <- msigdbr(species = "human", category = "H")
#m_df = msigdbr::msigdbr(species = "Homo sapiens", category = "C6")
h_list = split(x = h_gene_sets$gene_symbol, f = h_gene_sets$gs_name)

gLUSE <- GSVA::filterGeneSets(h_list, 
                              min.sz = 3, 
                              max.sz = 500)

##Scoring via ssGSEA
allRES <- gsva(expr = exprs(rnaETPM), 
               gset.idx.list = gLUSE,
               method = "ssgsea", 
               ssgsea.norm = F)

annoFULL <- pData(rnaETPM)
annoFULL$Sample_label <- paste(annoFULL$Patient_ID,annoFULL$Treatment,sep = '_')
annoSS <- annoFULL %>% select("Patient_ID", #"Mosaic_ID", 
                              "Diagnosis", "BOR", 
                              # "Months on Treatment",
                              'Treatment' )

##Heatmap
pheatmap(allRES,
         labels_col = annoFULL$Patient_ID,
         show_colnames = TRUE, 
         show_rownames = TRUE,
         annotation_colors = list("Diagnosis" =   c("HNSCC" = "magenta",
                                                    "RCC" = "yellow",
                                                    'NSCLC' = 'navy',
                                                    'Melanoma' = 'white'),
                                  "BOR" = c("CR" = "red",
                                            "PD" = "grey20",
                                            "SD" = "green"),
                                  "Treatment" = c("Archival Pre" = "grey40","Fresh Pre" = 'grey', 
                                                  "On-Treatment" = "orange")),
         
         color = colorpanel(100, "blue", "white", "red"),
         scale = "row",
         cluster_cols = FALSE,
         clustering_distance_rows = "euclidean",
         clustering_method = "ward.D2",
         annotation_col = annoSS,
         fontsize = 8)

#corresponds well with the gene-level visualization. Going to save this as well. 

##########################
## using quantiseqr to deconvolute cell type composition in bulkRNAsq
library(AnnotationDbi)
library(org.Hs.eg.db)

#an ExpressionSet object (from the Biobase package), where the HGNC
#gene symbols are provided in a column of the fData slot - that is specified
#by the column parameter below

##checked no duplicated genes
tpm <- tpm_merge
duplicated(rownames(tpm)) %>% sum()
colData <- colData_merge

## try annotationdb 
columns(org.Hs.eg.db)
keytypes(org.Hs.eg.db)

annots <- select(org.Hs.eg.db, keys=tpm$NCBI.Gene.ID %>% as.character(),
                 columns=c("SYMBOL",'ENTREZID'), keytype="ENTREZID")
  
resultTable <- merge(annots,tpm, by.x="ENTREZID", by.y=2)

# entrezID matches with NCBI id
all(annots$ENTREZID %in% tpm$NCBI.Gene.ID)
#[1] TRUE

#but symbol doesn't match gene symbol in all cases
all(resultTable$SYMBOL %in% resultTable$`Gene Symbol`)
#[1] FALSE

# no symbol genes from annotationdbi
test <- resultTable %>% filter(is.na(resultTable$SYMBOL))
dim(test)[1]

exprTPM <- resultTable %>% filter(!is.na(resultTable$SYMBOL)) %>% 
  column_to_rownames('SYMBOL') %>% dplyr::select(-c(1:2))

colnam<- colData_merge

exprTPM <- exprTPM[,rownames(colnam)]
#colnames(exprTPM) <- colnam$complexname

composition <- quantiseqr::run_quantiseq(
  expression_data = exprTPM,
  signature_matrix = "TIL10",
  is_arraydata = FALSE,
  is_tumordata = TRUE,
  scale_mRNA = TRUE,
  column = 'symbol'
)

quantiplot(composition)

## use ggplot for cell composition, remove Other cells

composition_gg <- composition %>% pivot_longer(cols = 2:12) %>% 
  filter(name != 'Other') %>%
  dplyr::rename('cell_type' = 'name', 'Fraction' = 'value') %>%
  merge(.,colData_merge %>% mutate(accession = rownames(.)), by.x = 'Sample', by.y = 'accession')

composition_gg %>% ggplot(aes(x = Treatment, y = Fraction, fill=cell_type)) +
  geom_bar(stat = 'identity',color='black') +
  facet_wrap(~Patient_ID ,nrow = 1,scales = 'free_x') +
  scale_fill_brewer(palette = "Paired") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_text(angle = 90),
        strip.background = element_rect(fill = 'white')) +
  labs(x='')

##20240924 DEG analysis ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
library(edgeR)

##M20-431
counts <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_rawCounts.csv')
colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_colData.csv',
                    row.names = 1) %>%
  dplyr::select(c(1,4,7:9,17,22)) %>%
  mutate(Treatment = gsub(' ','.',Treatment)) %>%
  mutate(Treatment = gsub('-','.',Treatment))

##M20-124 paired tumors
counts_124 <- readRDS('~/PTPN2i/Kyle_code/all_counts_expset_2024-01-22.rds')
## As for 579, we have only two pairs (30012 – NSCLC and 50007 – Melanoma)

manifest <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/ptpn2i_shipment_manifest.xlsx', 
                               sheet = 4) %>% 
  filter(Cohort == 'M20-124',Annotation == 'PAIR', Visit %in% c('C1D1','C2D1'))

colData_124 <- pData(counts_124) %>%
  filter(Samp_ID %in% c('30012','50007')) %>%
  mutate(Mosaic_ID = str_extract(rownames(.),pattern = 'ML\\d+')) %>% 
  left_join(.,manifest,by = 'Mosaic_ID') %>%
  mutate(Treatment = ifelse(Visit == 'C1D1','Fresh.Pre', 'On.Treatment')) %>%
  dplyr::select(colnames(colData)) 

rownames(colData_124) <- paste(colData_124$Patient_ID,colData_124$Mosaic_ID,sep='_')

rowData_124 <- fData(counts_124)

counts_124 <- exprs(counts_124[,rownames(colData_124)])

rownames(counts) <- counts$NCBI.Gene.ID

## merge exprs & colData

counts_merge <- cbind(counts[rownames(counts_124),],counts_124)
colData_merge <- rbind(colData,colData_124)
colData <- colData_merge

##
expCOUNT <- counts_merge

cleanDGE <- DGEList(counts=expCOUNT %>% dplyr::select(-c(1:2)) %>% 
          #column_to_rownames('Gene.Symbol') %>% 
          dplyr::select(rownames(colData_merge)), 
        samples = colData_merge,
        group=factor(colData_merge$Treatment))

cleanDGE <- calcNormFactors(cleanDGE)  


##https://ucdavis-bioinformatics-training.github.io/2018-June-RNA-Seq-Workshop/thursday/DE.html

snames <- colnames(cleanDGE) # Sample names
snames

time <- cleanDGE$samples$Treatment
time
cultivar <- cleanDGE$samples$Patient_ID
cultivar

#Create a new variable “group” that combines cultivar and time

group <- interaction(time)
group

#3. Voom transformation and calculation of variance weight
# keep same filtering as tpm expressionset
keep <- which(rowMeans(cpm(cleanDGE)) > 2.5 &
                rowVars(cpm(cleanDGE)) > 0.15)
d <- cleanDGE[keep,]
dim(d)

d$samples$lib.size <- colSums(d$counts)
d$samples

d <- calcNormFactors(d)
d

plotMDS(d, method = 'logFC', col=as.numeric(d$samples$Patient_ID))
legend("bottomleft", as.character(unique(d$samples$Patient_ID)), col=1:6, pch=20)

#Specify the model to be fitted. We do this before using voom since voom uses variances of the model residuals (observed - fitted)
mm <- model.matrix(~0 + group)

#The above specifies a model where each coefficient corresponds to a group mean
y <- voom(d, mm, plot = T)

#lmFit fits a linear model using weighted least squares for each gene:

fit <- lmFit(y, mm)
head(coef(fit))

#Comparisons between groups (log fold-changes) are obtained as contrasts of these fitted linear models:

#Specify which groups to compare:
#Comparison between times 6 and 9 for cultivar I5 contr <- makeContrasts(groupI5.9 - groupI5.6, levels = colnames(coef(fit)))

contr <- makeContrasts(groupOn.Treatment - groupFresh.Pre, levels = colnames(coef(fit)))
contr

#Estimate contrast for each gene

tmp <- contrasts.fit(fit, contr)

#Empirical Bayes smoothing of standard errors (shrinks standard errors that are much larger or smaller than those from other genes towards the average standard error) (see https://www.degruyter.com/doi/10.2202/1544-6115.1027)

tmp <- eBayes(tmp)

#What genes are most differentially expressed?

top.table <- topTable(tmp, sort.by = "P", n = Inf)
head(top.table, 20)

length(which(top.table$adj.P.Val < 0.05))

top.table$entrezgene_id <- rownames(top.table)
top.table <- top.table %>% mutate(entrezgene_id = as.integer(entrezgene_id))

top.table <- top.table %>% left_join(., rowData_124, by = 'entrezgene_id')

top.table.pval <- top.table %>% filter(P.Value < 0.05)

#write.table(top.table, file = "time9_v_time6_I5.txt", row.names = F, sep = "\t", quote = F)

###########################
###### patient by patinet doesn't work
###########################

############################
###### pick 2204, 2207, 2801, 50007
###########################

test <- cleanDGE[,which(cleanDGE$samples$Patient_ID %in% c('2204','2207','50007'))]

time <- test$samples$Treatment
time
cultivar <- cleanDGE$samples$Patient_ID
cultivar

#Create a new variable “group” that combines cultivar and time

group <- interaction(time)
group

#3. Voom transformation and calculation of variance weight
# keep same filtering as tpm expressionset
keep <- which(rowMeans(cpm(test)) > 2.5 &
                rowVars(cpm(test)) > 0.15)
d <- test[keep,]
dim(d)

d$samples$lib.size <- colSums(d$counts)
d$samples

d <- calcNormFactors(d)
d

plotMDS(d, method = 'logFC', col=as.numeric(d$samples$Patient_ID))
#legend("bottomleft", as.character(unique(d$samples$Patient_ID)), col=1:6, pch=20)

#Specify the model to be fitted. We do this before using voom since voom uses variances of the model residuals (observed - fitted)
mm <- model.matrix(~0 + group)

#The above specifies a model where each coefficient corresponds to a group mean
y <- voom(d, mm, plot = T)

#lmFit fits a linear model using weighted least squares for each gene:

fit <- lmFit(y, mm)
head(coef(fit))

#Comparisons between groups (log fold-changes) are obtained as contrasts of these fitted linear models:

#Specify which groups to compare:
#Comparison between times 6 and 9 for cultivar I5 contr <- makeContrasts(groupI5.9 - groupI5.6, levels = colnames(coef(fit)))

contr <- makeContrasts(groupOn.Treatment - groupFresh.Pre, levels = colnames(coef(fit)))
contr

#Estimate contrast for each gene

tmp <- contrasts.fit(fit, contr)

#Empirical Bayes smoothing of standard errors (shrinks standard errors that are much larger or smaller than those from other genes towards the average standard error) (see https://www.degruyter.com/doi/10.2202/1544-6115.1027)

tmp <- eBayes(tmp)

#What genes are most differentially expressed?

top.table <- topTable(tmp, sort.by = "P", n = Inf)
head(top.table, 20)

length(which(top.table$adj.P.Val < 0.05))

top.table$entrezgene_id <- rownames(top.table)
top.table <- top.table %>% mutate(entrezgene_id = as.integer(entrezgene_id))

top.table <- top.table %>% left_join(., rowData_124, by = 'entrezgene_id')

top.table.pval <- top.table %>% filter(P.Value < 0.05)

library(ggrepel)

##First a quick volcano plot
plotABVRES <- top.table
plotABVRES$P.Val_l10 <- -log10(plotABVRES$P.Value)
plotABVRES$sig_flag <- "NS"
plotABVRES$sig_flag[ which(abs(plotABVRES$logFC) > 0.1 & plotABVRES$adj.P.Val < 0.2) ] <- "Suggestive"
plotABVRES$sig_flag[ which(abs(plotABVRES$logFC) > 0.2 & plotABVRES$adj.P.Val < 0.05) ] <- "Significant"

#topGENES
topABVRES <- plotABVRES[ 1:300, ]

##Plotting
gmVol <- ggplot(data = plotABVRES, aes(x = logFC, y = P.Val_l10, fill = sig_flag)) +
  geom_point(size = 1.75, shape = 21) + 
  scale_y_continuous("Adjusted P value") +
  scale_x_continuous("Log fold-change") + 
  scale_fill_manual("Significance", values = c("NS" = "grey40", 
                                               "Suggestive" = "red",
                                               "Significant" = "purple")) + 
  geom_text_repel(data = topABVRES, aes(label = external_gene_name), size = 3, max.overlaps = 20) +
  geom_hline(yintercept = 1.3, linetype = 2) +
  geom_vline(xintercept = -0.1, linetype = 2) +
  geom_vline(xintercept = 0.1, linetype = 2) +
  guides(fill = guide_legend(override.aes = list(size = 6))) +
  theme_bw(base_size = 15) 

gmVol

## 20240925 #topGENES plot top DEG identified from here
write.csv(plotABVRES, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/DEG_8tumorpairs_OnvsPreTreatment.csv')

topABVRES_20 <- plotABVRES[ 1:30, ]

intGenes <- topABVRES_20$external_gene_name[1:30]

##Subsetting to only these genes
rnaLINT <- tumorTPM[ which(fData(tumorTPM)$symbol %in% intGenes), ]

##Melting expression
rnaLPMELT <- as.data.frame(melt(exprs(rnaLINT), ))
colnames(rnaLPMELT) <- c("gene_id", "sample_id", "expression")

rnaLPMELT <- pData(rnaLINT) %>% rownames_to_column(var = 'sample_id') %>% 
  merge(.,rnaLPMELT) %>% merge(., fData(rnaLINT) %>% rownames_to_column('gene_id'))


# no archival pre

ggplot(rnaLPMELT %>% filter(Treatment != 'Archival Pre'), aes(x = Treatment, y = expression)) +
  geom_boxplot(aes(fill = Treatment), alpha = .4)+
  geom_line(aes(group = Patient_ID),linetype = 2) + 
  geom_point(size=1.5,shape = 21, aes(fill = Treatment)) +
  facet_wrap(~ symbol,nrow = 2) + 
  theme_bw(base_size = 10,base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0, "cm"), 
        axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
        legend.position = 'right',strip.background = element_rect(fill = 'white')) +
  labs(x = '', y = 'Expression (log2 TPM + 1)', fill = '') 

### GOntology analysis

library(clusterProfiler)
library(org.Hs.eg.db)
library(msigdbr)
library(ReactomePA)

msigdbr_show_species()

df <- topABVRES

# over representation analysis

unique_genes_sample <- df 


gene.df <- bitr(unique_genes_sample$external_gene_name, fromType = "SYMBOL",
                toType = c(#"ENSEMBL", 
                  "ENTREZID"),
                OrgDb = org.Hs.eg.db) 

#GO ORA
ego <- enrichGO(gene          = gene.df$SYMBOL,
                universe      = plotABVRES$external_gene_name%>%unique,
                OrgDb         = org.Hs.eg.db,
                ont           = "BP",
                pAdjustMethod = "BH",
                pvalueCutoff  = 0.01,
                qvalueCutoff  = 0.05,
                readable      = TRUE,
                keyType = 'SYMBOL')

head(ego)
dotplot(ego, showCategory=20) + ggtitle("GO pathway enrichment")

#KEGG ORA
kk <- enrichKEGG(gene         = gene.df$ENTREZID,
                 organism     = 'hsa',
                 pvalueCutoff = 0.05)
head(kk)
dotplot(kk, showCategory=30,font.size = 9) + ggtitle("KEGG pathway enrichment")

#WIKIPathway ORA
wp <- enrichWP(gene.df$ENTREZID, organism = "Homo sapiens") 
head(wp)
dotplot(wp, showCategory=30) + ggtitle("Wikipathway enrichment")

#Reactome ORA
x <- enrichPathway(gene=gene.df$ENTREZID, pvalueCutoff = 0.05, readable=TRUE)
head(x)
dotplot(x, showCategory=30) + ggtitle("Reactome pathway enrichment")


m_t2g <- msigdbr(species = "Homo sapiens", category = "C5",subcategory = 'MF') %>% 
  dplyr::select(gs_name, human_gene_symbol)

em <- enricher(unique_genes_sample$Gene.Symbol, TERM2GENE=m_t2g)
head(em)

dotplot(em, showCategory=30,font.size=9) + ggtitle("Gene Ontology molecular function pathway enrichment")



