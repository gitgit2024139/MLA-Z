library(dplyr)
library(data.table)
library(tidyr)
library(readxl)
library(stringr)
library(readr)
library(ggplot2)


##aws s3 ls s3://abv-arrayserver/CloudDataRoot/Oncology/Clinical/personalis/M20-431/ 
##--profile arrayserver --recursive --human-readable --summarize > filenames_431.txt

##aws s3 ls s3://abv-arrayserver/CloudDataRoot/Oncology/Clinical/personalis/M20-124/ 
#--profile arrayserver --recursive --human-readable --summarize > filenames_124.txt

file_431 <- read.table('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/filenames_431.txt',
                       sep = '\t') %>% 
  separate(V1, into = c('v1','filepath'), sep = 'CloudDataRoot') %>% 
  mutate(filepath = paste('CloudDataRoot',filepath,sep = '')) %>%
  mutate(filetype = lapply(filepath, function(x) {tail(strsplit(x,split = '/')[[1]], 1)}
  ) %>% unlist(),
  suffix = lapply(filetype, function(x) {tail(strsplit(x,split = '\\.')[[1]], 1)}
  ) %>% unlist(),
  
  pipeline = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 1)}
  ) %>% unlist(),
  
  Accession_Number_original = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 2)[2]}
  ) %>% unlist()
  )

file_124 <- read.table('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/filenames_124.txt',
                       sep = '\t') %>% 
  separate(V1, into = c('v1','filepath'), sep = 'CloudDataRoot') %>% 
  mutate(filepath = paste('CloudDataRoot',filepath,sep = '')) %>% 
  mutate(filetype = lapply(filepath, function(x) {tail(strsplit(x,split = '/')[[1]], 1)}
  ) %>% unlist(),
  suffix = lapply(filetype, function(x) {tail(strsplit(x,split = '\\.')[[1]], 1)}
  ) %>% unlist(),
  
  pipeline = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 1)}
  ) %>% unlist(),
  
  Accession_Number_original = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 2)[2]}
  ) %>% unlist()
  )

## sanity check
length(unique(file_431$Accession_Number_original))
#[1] 206

length(unique(file_124$Accession_Number_original))
#[1] 115

#read clinical sample shiping manifest, get paired tumor samples
manifest <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/M20_431_and_M20_124_Personalis_Shipment_Summary_6Aug2024_yz_mj.xlsx', 
                               sheet = 4) %>% 
  mutate(Accession_Number = parse_number(Accession_Number),
         Accession_number = Accession_Number) %>%
  mutate(Accession_number = ifelse(nchar(Accession_number)==12,
                                   str_sub(Accession_number, end = -3),
                                   Accession_number)) %>%
  dplyr::select(-Annotation) %>%
  dplyr::rename('Accession_Number_original' = 'Accession_Number')

## sanity check
table(manifest[!duplicated(manifest$Accession_Number_original),]$Cohort)
#M20-124 M20-431 
#143     242 

# add M20-124 and M20-431 togather
matches_rna <- rbind(file_124,file_431) %>%
  mutate(Accession_Number_original = parse_number(Accession_Number_original))

#save total files so far 20241105
write.csv(matches_rna, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/allS3files_431_124_1105.csv',row.names = F)
write.csv(manifest,'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/allS3files_431_124_manifest_1105.csv',row.names = F)

#filter gene expression,TCT,BCR,MUTATION,copynumber,NEOANTIGEN,IMMUNOGENOMICS

matches_exp_report <- matches_rna[grepl(paste(c('rna_gene_expression_report.xlsx'),collapse = '|'), 
                                        matches_rna$filetype),]
##save all the expression report path
write.csv(matches_exp_report, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/expression_report_124_431_list_1105.csv',row.names = F)

## add metadata
final_list <- matches_exp_report %>% left_join(manifest) 

##colData

clinical_124 <- read_excel(paste('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/',
                             'PTPN2_Clinical_Metadata_08AUG24_Final.xlsx',sep=''),sheet = 1)
colnames(clinical_124)[17] <- 'Expansion_Cohort'
clinical_124 <- clinical_124 %>% dplyr::select(1:15,17,16)
clinical_124$group <- 'M20-124'

clinical_431 <- read_excel(paste('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/',
                                 'PTPN2_Clinical_Metadata_08AUG24_Final.xlsx',sep=''),sheet = 2) %>%
  mutate(group = 'M20-431')

# merge 124 and 431
colnames(clinical_124) <- colnames(clinical_431)
clinical <- rbind(clinical_124,clinical_431)
write.csv(clinical,'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/allS3files_431_124_clinical_1105.csv',row.names = F)

## total list

total_list <- final_list %>% mutate(Subject_ID = parse_number(Patient_ID)) %>%
  left_join(clinical) %>% 
  filter(!duplicated(Accession_Number_original))

write.csv(total_list, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/final_list_GEX_124_431_1030.csv',row.names = F)

##############################################################################################
## 1. working on RCC list
##############################################################################################
RCC <- clinical %>% filter(Diagnosis_Standardized == 'RCC') %>% 
  mutate(Patient_ID = as.character(Subject_ID))

RCC_list <- manifest %>% left_join(RCC) %>% 
  filter(Diagnosis_Standardized == 'RCC') %>% 
  filter(Sample_Type == 'Tissue') %>%
  mutate(Treatment = ifelse(is.na(Treatment), Visit, Treatment)) %>%
  filter(Treatment != 'On-Treatment')

#sanity check
table(RCC_list$Cohort)
#M20-124 M20-431 
#     3      8

matches_exp_report <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/expression_report_124_431_list_1105.csv')

final_list <- matches_exp_report %>% 
  mutate(Accession_number = as.character(Accession_Number_original)) %>% 
  right_join(., RCC_list) %>% 
  filter(!duplicated(Accession_number)) %>% 
  filter(!(is.na(filepath)))

## batchset
final_list_edit <- final_list %>% mutate(
  batchset = str_extract(filepath, '[Bb]atch\\d(_\\w+)') %>%
    lapply(.,function(x) {head(strsplit(x, split = '_7')[[1]],1)[1]}) %>%
    unlist(),
  batchdate = str_extract(filepath, '\\d{4}_\\d{4}'),
  batchtotal = paste(batchset,batchdate,sep = '_')
)

write.csv(final_list_edit, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/final_RCC_list.csv',row.names = F)

##############################################################################################
## 2. download gene expression reports from s3 by print bash command lines and run command lines in terminal
##############################################################################################

for (i in 1: length(final_list_edit$filepath)) {
  
  s3_loc <- final_list_edit$filepath[i]
  filename <- paste(final_list_edit$batchset[i], final_list_edit$filetype[i],sep = '_')
  
  cmd <- paste('aws s3 cp s3://abv-arrayserver/', s3_loc,
               ' --profile arrayserver /ui/abv/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_rccRNAexp/',
               filename,sep = '')
  
  write(cmd,file = '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/bash_cp_cmd_rccGEX.sh', append = T)
  
}

#7. rbind snv files
files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_rccRNAexp/',
                    pattern = 'xlsx',
                    full.names = T)

names(files) <- stringr::str_extract(basename(files), pattern = 'RNA_\\d{10}')

##counts
counts <- purrr::map_df(files, .f = read_excel, .id = "sample") %>% dplyr::select(1:4) %>%
  tidyr::pivot_wider(names_from = 1, values_from = 4 )

write.csv(counts, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_RCC_counts_124_431_1030.csv',
          row.names = F)

##tpm
tpm <- purrr::map_df(files, .f = read_excel, .id = "sample") %>% dplyr::select(1:3,7) %>%
  tidyr::pivot_wider(names_from = 1, values_from = 4 )

write.csv(tpm, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_RCC_TPM_124_431_1030.csv',
          row.names = F)


##############################################################################################
## 3. download gene expression reports from s3 by print bash command lines and run command lines in terminal
##############################################################################################











