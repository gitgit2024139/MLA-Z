library(tidyverse)
library(dplyr)
library(readxl)
library(data.table)
library(Biobase)
library(genefilter)
library(Rtsne)
library(ggplot2)
library(gridExtra)
library(pheatmap)
library(gplots)
library(limma)
library(RColorBrewer)
library(reshape)
library(GSVA)
library(quantiseqr)
library(ComplexHeatmap)
library(lessR)

### collate the TPM values for the following genes across all tumor samples that yielded RNAseq data 
#(baseline only + all pairs) for both M20-124 and -431 studies.
#need values for the following genes in an excel file:
# 1) CD11b, CD14, CD68, CD80, CD86, CD163, CD206, ARG1 and NOS2
# 2)  get the z-scores associated with the M1 and M2 phenotypes.

##extract tumor colData
colData1 <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch1_6_forTMBandIFNA_20250505.csv')
colData2 <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batchIlluminaArchive_forTMBandIFNA_20250506.csv')
cols <- intersect(colnames(colData1),colnames(colData2))

colData_total <- rbind(colData1 %>% select(cols), colData2 %>% select(cols)) %>% 
  filter(!duplicated(Accession_number)) %>% mutate(Accession_number = as.character(Accession_number))

tumor_combined <- read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/final_list_inventory_124_431_table_PN_20241115.xlsx',
                             sheet = 1) %>% filter(Batch_Type == 'Tumor/Normal') %>% 
  filter(Sample_Type %in% c('Tissue'))

target_tumor_exp <- tumor_combined %>% left_join(colData_total #%>% select(filepath,filetype,Accession_number)
                                                 , 
                                                 by = 'Accession_number') %>% 
  filter(!duplicated(Accession_number)) %>% filter(!is.na(filepath))

write.csv(target_tumor_exp,'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_combined_colData_forM1M2Macrophage_250529.csv',row.names = F)

# get filepath from downloaded files
files <- c(list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumor_batch1_6_forTMBandIFNA/',
                      pattern = 'xlsx',full.names = T),
           list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumor_illuminaArchive_forTMBandIFNA/',
                      pattern = 'xlsx',full.names = T)) 

final_files <- data.frame(localpath = files) %>% 
  mutate(filename = basename(localpath),
         filetype = str_extract(filename, "RNA_[0-9_]+.*")) %>% 
  right_join(target_tumor_exp)

# gene expr
files <- final_files$localpath

names(files) <- final_files$Accession_number

##tpm
tpm <- purrr::map_df(files, .f = read_excel, .id = "sample") %>% select(1:3,7) %>%
  tidyr::pivot_wider(names_from = 1, values_from = 4 )

write.csv(tpm, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_combined_TPM_forM1M2Macrophage_250529.csv',
          row.names = F)

## expressionset
tpm <- fread('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_combined_TPM_forM1M2Macrophage_250529.csv')
colData <- fread('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_combined_colData_forM1M2Macrophage_250529.csv')

colData <- colData[order(colData$Patient_ID, colData$Treatment.x),]
colData <- colData %>% mutate(accession = Accession_number) %>% column_to_rownames('accession')
colData$Cohort <- ifelse(colData$Cohort == 'M20_124','M20-124',
                         ifelse(colData$Cohort == 'M20_431','M20-431',colData$Cohort))

tumorTPM <- ExpressionSet(assayData = tpm %>% dplyr::select(-1) %>% 
                            column_to_rownames('NCBI Gene ID') %>% 
                            dplyr::select(rownames(colData)) %>% as.matrix,
                          phenoData = AnnotatedDataFrame(colData),
                          featureData = AnnotatedDataFrame(
                            data.frame(symbol = tpm$`Gene Symbol`, row.names = tpm$`NCBI Gene ID`))
)

##log2(+1) converting expression data for TPMs
exprs(tumorTPM) <- log2(exprs(tumorTPM) + 1)
hist(rowMeans(exprs(tumorTPM)))
hist(rowVars(exprs(tumorTPM)))

##Subsetting to variable and expressed genes
rnaTUSE <- exprs(tumorTPM)[ which(rowMeans(exprs(tumorTPM)) > 2.5 & 
                                    rowVars(exprs(tumorTPM)) > 0.15), ]

##Getting tsne together
set.seed(777)
tstTSNE <- Rtsne(t(rnaTUSE),
                 check_duplicates=FALSE,
                 pca=TRUE,
                 perplexity=2,
                 theta=0.5,
                 dims=2)

##Making a dataframe for plotting
tstTSNEDF <- as.data.frame(tstTSNE$Y)
tstTSNEDF$Patient_ID <- factor(tumorTPM$Patient_ID)
#tstTSNEDF$Mosaic_ID <- factor(tumorTPM$Mosaic_ID)
tstTSNEDF$Treatment <- factor(tumorTPM$Treatment.x)
tstTSNEDF$Diagnosis <- factor(tumorTPM$Diagnosis)
tstTSNEDF$Cohort <- factor(tumorTPM$Study)
tstTSNEDF$Batch <- factor(tumorTPM$Batch)

##Plotting
ggplot(data = tstTSNEDF, aes(x = V1, y = V2, col = Batch, label = Diagnosis,shape = Cohort)) +
  #geom_label(size = 4) + 
  ggrepel::geom_label_repel(size = 3) + 
  geom_point(size = 5)+
  scale_x_continuous("tSNE X") +
  scale_y_continuous("tSNE Y") +
  #scale_color_manual(values = c("Archival Pre" = "navy","Fresh Pre" = 'black', 
  #                              "On-Treatment" = "red")) + 
  theme_classic(base_size = 10) +
  theme(plot.title = element_text(hjust = 0.5)) 

##Relabeling featureNames
rnaETPM <- tumorTPM
rnaETPM <- rnaETPM[ duplicated(fData(rnaETPM)$symbol) == FALSE, ]
featureNames(rnaETPM) <- fData(rnaETPM)$symbol

library(GSVA)
##IO atlas core genesets 
geneList <- readRDS('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/core_modules_01052023_rename.rds')
############# all gene sets
#geneList <- readRDS('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/modules_plus_singletons_01052023_rename.rds')

##Filtering
gLUSE <- GSVA::filterGeneSets(geneList, 
                              min.sz = 3, 
                              max.sz = 500)

##Scoring via ssGSEA
allRES <- GSVA::gsva(gsvaParam(as.matrix(rnaETPM),geneList))

annoSS <- pData(rnaETPM) %>% select(#"Diagnosis", 
                                    "BOR", 'Treatment.x')

##Heatmap
pheatmap(allRES,
         #labels_col = paste(annoFULL$Accession_number),
         show_colnames = TRUE, 
         show_rownames = TRUE,
         annotation_colors = list(#"Diagnosis" =   c("HNSCC" = "magenta",
           #                  "RCC" = "yellow"),
           "BOR" = c("CR" = "red",
                     "PD" = "grey60",
                     "SD" = "green",
                     'NE' = 'black',
                     'PR' = 'purple'),
           "Treatment" = c("Archival Pre" = "grey40","Fresh Pre" = 'grey', 
                           "On-Treatment" = "orange",'Normal-blood' = 'black')),
         
         color = colorpanel(100, "blue", "white", "red"),
         scale = "row",
         cluster_cols = FALSE,
         clustering_distance_rows = "euclidean",
         clustering_method = "ward.D2",
         annotation_col = annoSS,
         fontsize_col = 6.5)

IO_core_gsea <- allRES %>%  as.data.frame()%>% rownames_to_column('pathway') %>%
  pivot_longer(cols = 2:148,names_to = 'Accession_number',values_to = 'ssGSEAscore')

write.csv(IO_core_gsea, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch1_6_io_core_gsea.csv',row.names = F)


##Plotting some relevant genes
intGenes <- c("ITGAM", "CD14", "CD68", "CD80", "CD86", "CD163", "MRC1", "ARG1","NOS2")

##20250702 updates retrieve the TPM values for CD8A and CD3 for all the paired biopsies, CD4 and FoxP3

intGenes <- c("CD3G", "CD3D", "CD3E", "CD247", "CD8A", "CD4", "FOXP3")

##Subsetting to only these genes
rnaLINT <- tumorTPM[ which(fData(tumorTPM)$symbol %in% intGenes), ]

## extract log2 TPM+1
test <- rnaLINT@assayData$exprs %>% t
# rownames(test) <- rnaLINT@featureData@data$symbol
# colnames(test) <- paste(rnaLINT$Accession_number,rnaLINT$Patient_ID, rnaLINT$Visit.x,sep = '_')
colnames(test) <- rnaLINT@featureData@data$symbol
test <- test %>% as.data.frame %>% 
  mutate(Patient_ID = rnaLINT$Patient_ID, Visit = rnaLINT$Visit.x)

##extract target gene tpm
tpm_intgene <- tpm %>% filter(tpm$`Gene Symbol` %in% intGenes) %>% 
  column_to_rownames('Gene Symbol') %>% select(-1) %>% select(colnames(rnaLINT)) %>% t %>%
  as.data.frame %>% 
  mutate(Patient_ID = rnaLINT$Patient_ID, Visit = rnaLINT$Visit.x)

pairs <- tpm_intgene %>% group_by(Patient_ID) %>% reframe(count = n()) %>% 
  filter(count > 1)

tpm_intgene_pair <- tpm_intgene[tpm_intgene$Patient_ID %in% pairs$Patient_ID,]

library(xlsx)

# write.xlsx(tpm_intgene %>%as.data.frame , 
#            file="~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_combined_M1M2Macrophage_9genes_250529.xlsx", 
#            sheetName="TPM value", row.names=T)
# 
# write.xlsx(test %>% as.data.frame , 
#            file="~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_combined_M1M2Macrophage_9genes_250529.xlsx", 
#            sheetName="log2 TPM + 1", row.names=T, append = T)

write.xlsx(tpm_intgene %>%as.data.frame , 
           file="~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_combined_Tcellphenotype_7genes_250702.xlsx", 
           sheetName="TPM value", row.names=T)

write.xlsx(tpm_intgene_pair %>% as.data.frame , 
           file="~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_combined_Tcellphenotype_7genes_250702.xlsx", 
           sheetName="TPM value for paired biopsies", row.names=T, append = T)

rnaLINT$sample_label <- paste(rnaLINT$Patient_ID, rnaLINT$Treatment,sep = '_')

##Peeling off, subsetting annotation data
annoSS <- pData(rnaLINT) %>% dplyr::select( "BOR", 'Treatment.x')

##Heatmap
ComplexHeatmap::pheatmap(exprs(rnaLINT),
                         labels_row = fData(rnaLINT)$symbol,
                         #labels_col = pData(rnaLINT)$sample_label,
                         show_colnames = TRUE, 
                         show_rownames = TRUE,
                         annotation_colors = list(#"Diagnosis" =   c("HNSCC" = "magenta",
                           #              "RCC" = "yellow"),
                           "BOR" = c("CR" = "red",
                                     "PD" = "grey60",
                                     "SD" = "green",
                                     'NE' = 'black',
                                     'PR' = 'purple'),
                           "Treatment" = c("Archival Pre" = "grey40","Fresh Pre" = 'grey', 
                                           "On-Treatment" = "orange")),
                         
                         color = colorpanel(100, "blue", "white", "red"),
                         scale = "row",
                         clustering_distance_rows = "euclidean",
                         clustering_method = "ward.D2",
                         cluster_rows = T,
                         cluster_cols = F,
                         annotation_col = annoSS )


##########################
## using quantiseqr to deconvolute cell type composition in bulkRNAsq
library(AnnotationDbi)
library(org.Hs.eg.db)

#an ExpressionSet object (from the Biobase package), where the HGNC
#gene symbols are provided in a column of the fData slot - that is specified
#by the column parameter below

##checked no duplicated genes
tpm <- read_csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_combined_TPM_forM1M2Macrophage_250529.csv') 
tpm <- tpm[,c(1:2,match(colnames(tumorTPM),colnames(tpm)))]

## try annotationdb 
columns(org.Hs.eg.db)
keytypes(org.Hs.eg.db)

annots <- AnnotationDbi::select(org.Hs.eg.db, keys=tpm$`NCBI Gene ID` %>% as.character(),
                 columns=c("SYMBOL",'ENTREZID'), keytype="ENTREZID")

resultTable <- merge(annots,tpm, by.x="ENTREZID", by.y='NCBI Gene ID')

# entrezID matches with NCBI id
all(annots$ENTREZID %in% tpm$`NCBI Gene ID`)
#[1] TRUE

#but symbol doesn't match gene symbol in all cases
all(resultTable$SYMBOL %in% resultTable$`Gene Symbol`)
#[1] FALSE

# no symbol genes from annotationdbi
test <- resultTable %>% filter(is.na(resultTable$SYMBOL))
dim(test)[1]

exprTPM <- resultTable %>% filter(!is.na(resultTable$SYMBOL)) %>% 
  column_to_rownames('SYMBOL') %>% dplyr::select(-c(1:2))

#colnames(exprTPM) <- colnam$complexname

composition <- quantiseqr::run_quantiseq(
  expression_data = exprTPM,
  signature_matrix = "TIL10",
  is_arraydata = FALSE,
  is_tumordata = TRUE,
  scale_mRNA = TRUE,
  column = 'symbol'
)

quantiplot(composition)

## use ggplot for cell composition, remove Other cells

composition_gg <- composition %>% pivot_longer(cols = 2:12) %>% 
  filter(name != 'Other') %>%
  dplyr::rename('cell_type' = 'name', 'Fraction' = 'value') %>%
  merge(.,pData(tumorTPM) %>% mutate(Sample = paste(rownames(.))), by.x = 'Sample', by.y = 'Sample') %>% 
  mutate(name = paste(Patient_ID, Treatment.x))

composition_gg %>% 
  mutate (BOR = factor(BOR, levels = c('CR','PR','SD','PD','NE'))) %>% 
  ggplot(aes(x = name, y = Fraction, fill=cell_type)) +
  geom_bar(stat = 'identity',color='black') +
  facet_wrap(~BOR ,nrow = 2,scales = 'free_x') +
  scale_fill_brewer(palette = "Paired") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_text(angle = 90,size=7),
        strip.background = element_rect(fill = 'white')) +
  labs(x='')

deconv.macro <- composition_gg %>% 
  filter(composition_gg$cell_type %in% c('Macrophages.M1','Macrophages.M2')) %>% 
  dplyr::select(1:3,6,8)

write.csv(deconv.macro, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_combined_celltypedeconv_forM1M2Macrophage_250529.csv',row.names = F)
