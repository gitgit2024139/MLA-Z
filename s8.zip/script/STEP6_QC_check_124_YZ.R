library(tidyverse)
library(dplyr)
library(readxl)
library(data.table)
library(Biobase)
library(genefilter)
library(Rtsne)
library(ggplot2)
library(gridExtra)
library(pheatmap)
library(gplots)
library(limma)
library(RColorBrewer)
library(reshape)
library(GSVA)
library(qusage)
library(quantiseqr)
library(ComplexHeatmap)
library(readr)

##aws s3 ls s3://abv-arrayserver/CloudDataRoot/Oncology/Clinical/personalis/M20-431/ 
##--profile arrayserver --recursive --human-readable --summarize > filenames_431.txt

##aws s3 ls s3://abv-arrayserver/CloudDataRoot/Oncology/Clinical/personalis/M20-124/ 
#--profile arrayserver --recursive --human-readable --summarize > filenames_124.txt

file_124 <- read.table('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/filenames_124.txt',
                       sep = '\t') %>% 
  separate(V1, into = c('v1','filepath'), sep = 'CloudDataRoot') %>% 
  mutate(filepath = paste('CloudDataRoot',filepath,sep = '')) %>% 
  mutate(filetype = lapply(filepath, function(x) {tail(strsplit(x,split = '/')[[1]], 1)}
  ) %>% unlist(),
  suffix = lapply(filetype, function(x) {tail(strsplit(x,split = '\\.')[[1]], 1)}
  ) %>% unlist(),
  
  pipeline = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 1)}
  ) %>% unlist(),
  
  Accession_Number_original = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 2)[2]}
  ) %>% unlist()
  )

#read clinical sample shiping manifest, get paired tumor samples
manifest <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/M20_431_and_M20_124_Personalis_Shipment_Summary_6Aug2024_yz_mj.xlsx', 
                               sheet = 4) %>% 
  mutate(Accession_Number = parse_number(Accession_Number),
         Accession_number = Accession_Number) %>%
  mutate(Accession_number = ifelse(nchar(Accession_number)==12,
                                   str_sub(Accession_number, end = -3),
                                   Accession_number)) %>%
  dplyr::select(-Annotation) %>%
  dplyr::rename('Accession_Number_original' = 'Accession_Number') %>% 
  filter(Cohort == 'M20-124')

table(manifest[!duplicated(manifest$Accession_Number_original),]$Cohort)

# M20-124 
#143 

#2. filter wes files

#filter report
matches_qc_report <- file_124[grepl('dna_statistics.tsv', 
                                    file_124$filetype),]  


##3 add metadata

## full manifest doesn't have treatment info
#clinical_124 <- read_excel(paste('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/',
#                                 'PTPN2_Clinical_Metadata_08AUG24_Final.xlsx',sep=''),sheet = 1)

# personalis_124_paul_personalis <- read_excel(paste('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/',
# 'M20_124_Slide_Shipment_Mosaic_to_Personalis_09.07.2023_paul.xlsx',sep = ''),sheet = 1,skip = 15)

# Paul's molecular profiling clinical data
# molecular_124_paul <- read_excel(paste('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/',
# 'M20_124_Clinical_Metadata_for_Molecular_Profiling_paul.xlsx',sep = ''),sheet = 1) %>% 
#   dplyr::rename( 'Mosaic_ID' = '...1') %>% 
#   separate('Mosaic_ID', into = c('pid','Mosaic_ID'),sep = '_',extra = 'drop') %>% 
#   left_join(manifest %>% select(Accession_Number_original,Accession_number,Mosaic_ID), by = 'Mosaic_ID') 

clinical_124 <- read_excel(paste('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/',
                                'PTPN2_Clinical_Metadata_08AUG24_Final.xlsx',sep=''),sheet = 1)
colnames(clinical_124)[1] <- 'Patient_ID'

total_list <- matches_qc_report %>% 
  mutate(Accession_Number_original = parse_number(Accession_Number_original)) %>%
  left_join(manifest,by = 'Accession_Number_original') %>% 
  mutate(Patient_ID = parse_number(Patient_ID)) %>%
  left_join(clinical_124, by = 'Patient_ID')

final_list_edit <- total_list %>% 
  mutate( batchset = str_extract(filepath, '[Bb]atch\\d(_\\w+)') %>% 
            lapply(.,function(x) {head(strsplit(x, split = '_7')[[1]],1)[1]}) %>%
            unlist()
  ) %>% filter(!duplicated(Accession_Number_original))

colData <- manifest %>% mutate(Patient_ID = parse_number(Patient_ID)) %>%
  left_join(clinical_124, by = 'Patient_ID')

write.csv(colData, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/M20_124_colData_1029.csv',row.names = F)


##4. download gene expression reports from s3 by print bash command lines and run command lines in terminal

for (i in 1: length(final_list_edit$filepath)) {
  
  s3_loc <- final_list_edit$filepath[i]
  filename <- paste(final_list_edit$batchset[i], final_list_edit$filetype[i],sep = '_')
  
  cmd <- paste('aws s3 cp s3://abv-arrayserver/', s3_loc, 
               ' --profile arrayserver /ui/abv/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorQC/', 
               filename,sep = '')
  
  write(cmd,file = '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/bash_cp_cmd_QC_124.sh', append = T)
  
}

##5. downlaod files from s3 to HPC from command line

##6. qc files

files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorQC',
                    #pattern = 'somatic_dna_small_variant_report_preferred',
                    #pattern = '.tsv',
                    full.names = T)

names(files) <- stringr::str_split(basename(files), pattern = '_statistics',simplify = T)[,1]

test <- data.frame(sample = names(files), filepath = files) %>% 
  mutate(Accession_number = str_extract(sample, '\\d{10}'),
         batchset = str_split(sample, pattern = paste(c('_RNA','_DNA'), collapse = '|'), simplify = T)[,1]) %>% 
  filter(batchset != 'Batch2_SET_A_TO') %>% 
  filter(batchset != 'Batch5_TO') %>% 
  filter(Accession_number %in% final_list_edit$Accession_Number_original)

test2 = test %>% group_by(Accession_number) %>% reframe(n())

files <- test$filepath
names(files) <- stringr::str_split(basename(files), pattern = '_statistics',simplify = T)[,1]

## compiling the master data frame
# df<-read.delim(files[1], header = FALSE, sep = "\t", quote = "\"",
#            dec = ".", fill = TRUE, comment.char = "#", col.names = c("V1","V2","V3","V4","V5"))

counts <- purrr::map_df(files, function(x) {
                                      read.delim(x, header = FALSE, 
                                                 sep = "\t", quote = "\"",
                                                 dec = ".", fill = TRUE, comment.char = "#", 
                                                 col.names = c("V1","V2","V3","V4","V5"))
                                   }, .id = "sample") %>%
  left_join(.,test) %>% 
  filter(!is.na(batchset))

# write.csv(counts, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_somaticSNV_0827.csv',
#           row.names = F)
write.csv(counts, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_124_QCsummary_1030.csv',
          row.names = F)


###############################################################################################
#1. QC
###############################################################################################

counts_qc <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_124_QCsummary_1030.csv')

# working table

counts_qc_df <- counts_qc %>%
                     filter(V1 %in% 
                              c('Average base quality','Total reads','Percent contamination in Normal',
                                'Percent contamination in Tumor','Average read depth',
                                'Percent mapped reads','Somatic variants per Mb','Non-synonymous Somatic Variants per Mb',
                                'Number of expressed genes')) %>% 
  mutate(pipeline = str_extract(sample, '[DR]NA'))


##1. total reads

counts_qc_df %>% 
  filter(V1 == 'Total reads', pipeline == 'DNA')%>% 
  pivot_longer(cols = c('V2','V3')) %>% 
  mutate(name = ifelse(name == 'V2','Normal DNA','Tumor DNA')) %>% 
  mutate(value = parse_number(value))%>%
  ggplot(aes(x = sample,y=value, color=name)) +
  geom_point(shape=1,size=1) + 
  facet_wrap(~name,nrow = 2,scales = 'free') +
  scale_color_brewer(palette = "Set2") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_blank(),
        strip.background = element_rect(fill = 'white')) +
  labs(x='',color = '', y = 'Total Reads') 

##2. Average base quality

counts_qc_df %>% 
  filter(V1 == 'Average base quality', pipeline == 'DNA')%>% 
  pivot_longer(cols = c('V2','V3')) %>% 
  mutate(name = ifelse(name == 'V2','Normal DNA','Tumor DNA')) %>% 
  mutate(value = parse_number(value))%>%
  ggplot(aes(x = sample,y=value, fill=name)) +
  geom_bar(stat = 'identity',alpha=.5) + 
  facet_wrap(~name,nrow = 2,scales = 'free') +
  scale_fill_brewer(palette = "Set1") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_blank(),
        strip.background = element_rect(fill = 'white')) +
  labs(x='',color = '', y = 'Average base quality') 

##3. Average read depth

counts_qc_df %>% 
  filter(V1 == 'Average read depth', pipeline == 'DNA')%>% 
  pivot_longer(cols = c('V2','V3')) %>% 
  mutate(name = ifelse(name == 'V2','Normal DNA','Tumor DNA')) %>% 
  mutate(value = parse_number(value))%>%
  ggplot(aes(x = sample,y=value, color=name)) +
  geom_point(shape=10,size=2) + 
  facet_wrap(~name,nrow = 2,scales = 'free') +
  scale_color_brewer(palette = "Dark2") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_blank(),
        strip.background = element_rect(fill = 'white')) +
  labs(x='',color = '', y = 'Average read depth') 


##4. Percent mapped reads

counts_qc_df %>% 
  filter(V1 == 'Percent mapped reads', pipeline == 'DNA')%>% 
  pivot_longer(cols = c('V2','V3')) %>% 
  mutate(name = ifelse(name == 'V2','Normal DNA','Tumor DNA')) %>% 
  mutate(value = parse_number(value))%>%
  ggplot(aes(x = name,y=value, fill=name)) +
  geom_boxplot(alpha=.5)  +
  scale_fill_brewer(palette = "Accent") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_blank(),
        strip.background = element_rect(fill = 'white'),
        legend.position = 'bottom') +
  labs(x='',fill = '', y = 'Percent mapped reads') 

##5. Non-synonymous Somatic Variants per Mb

TMB <- counts_qc_df %>% 
  filter(V1 == 'Non-synonymous Somatic Variants per Mb', pipeline == 'DNA')%>% 
  pivot_longer(cols = c('V2','V3')) %>% 
  mutate(name = ifelse(name == 'V2','SNVs','Indels')) %>% 
  mutate(value = parse_number(value)) 

colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/M20_124_colData_1029.csv')

TMB_final <- TMB %>% left_join(colData, by = 'Accession_number') %>% 
  filter(!duplicated(Accession_number))

write.csv(TMB_final,'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_124_TMB.csv',row.names = F)

## filter for PMED-DS team 20241030

TMB_final_ds <- TMB_final %>% 
  select(2,6,10,13,15,20) %>% 
  dplyr::rename('TMB' = 'value')

write.csv(TMB_final_ds,'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_124_TMB_for_DSteam.csv',row.names = F)





TMB %>%
  ggplot(aes(x = name,y=value, fill=name)) +
  geom_boxplot(alpha=.5) +
  scale_fill_brewer(palette = "Pastel1") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_blank(),
        strip.background = element_rect(fill = 'white'),
        legend.position = 'bottom') +
  labs(x='',fill = '', y = 'TMB (Number of Mutations/Mb)') 


##6. Number of expressed genes
counts_qc_df %>% 
  filter(pipeline == 'RNA', V1 %in% 
  c('Total reads','Average base quality','Percent mapped reads','Number of expressed genes'))%>% 
  mutate(V2 = parse_number(V2))%>%
  ggplot(aes(x = sample,y=V2, fill=V1)) +
  geom_bar(stat = 'identity') + 
  facet_wrap(~V1,nrow = 2,scales = 'free') +
  scale_fill_brewer(palette = "Set2") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_blank(),
        strip.background = element_rect(fill = 'white'),
        legend.position = 'none') +
  labs(x='',fill = '') 

# get the sample names
