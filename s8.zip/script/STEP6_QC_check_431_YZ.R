library(tidyverse)
library(dplyr)
library(readxl)
library(data.table)
library(Biobase)
library(genefilter)
library(Rtsne)
library(ggplot2)
library(gridExtra)
library(pheatmap)
library(gplots)
library(limma)
library(RColorBrewer)
library(reshape)
library(GSVA)
library(qusage)
library(quantiseqr)
library(ComplexHeatmap)
library(readr)

### filter to retain SetB and 0817_TN data when having overlaps for tumor analysis

file_431 <- read.table('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/filenames_431_0823.txt',
                       sep = '\t') %>% 
  separate(V1, into = c('v1','filepath'), sep = 'CloudDataRoot') %>% 
  mutate(filepath = paste('CloudDataRoot',filepath,sep = '')) 

#read clinical sample shiping manifest, get paired tumor samples
manifest <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/ptpn2i_shipment_manifest.xlsx', 
                               sheet = 4) %>% 
  filter(Batch_Type != 'Gene Expression') ##remove blood samples

manifest_order <- manifest[order(manifest$Patient_ID,manifest$Sample_Type),] %>% 
  mutate(Accession_number = Accession_Number) %>%
  mutate(Accession_number = ifelse(nchar(Accession_number)==12,
                                   str_sub(Accession_number, end = -3),
                                   Accession_number)) ##remove 2 additional digits from accession number
  #separate(Accession_number, c('Accession_number','suffix'),sep = '27')

matches <- file_431[grepl(paste(manifest_order$Accession_number, collapse="|"), 
                          file_431$filepath), ] %>%
  mutate(filetype = lapply(filepath, function(x) {tail(strsplit(x,split = '/')[[1]], 1)}
  ) %>% unlist(),
  suffix = lapply(filetype, function(x) {tail(strsplit(x,split = '\\.')[[1]], 1)}
  ) %>% unlist(),
  
  pipeline = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 1)}
  ) %>% unlist(),
  
  Accession_number = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 2)[2]}
  ) %>% unlist()
  )

##save 6 tumor pairs all type files

write.csv(matches, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/allS3files_0827.csv',row.names = F)

#2. filter wes files

#filter gene expression report
matches_qc_report <- matches[grepl(paste(c('dna_statistics','rna_statistics'),collapse = '|'), 
                                   matches$filetype),]  
# %>% filter(suffix == 'json',pipeline == 'DNA')

##3 add metadata

final_list <- matches_qc_report %>% dplyr::select(filepath,filetype,Accession_number) %>% 
  merge(.,manifest_order,by.x = 'Accession_number',by.y = 'Accession_number'  )  %>% 
  filter(Mosaic_ID != 'N/A')

## full manifest doesn't have treatment info
final_list_edit <- final_list[order(final_list$Patient_ID
                                    #final_list$Treatment. #full manifest doesn't have treatment info
                                    ),]
##batchset
final_list_edit <- final_list_edit %>% 
  mutate( batchset = str_extract(filepath, 'Batch\\d(_\\w+)') %>% 
      lapply(.,function(x) {head(strsplit(x, split = '_7')[[1]],1)[1]}) %>%
      unlist()
  )

table(final_list_edit$batchset)

## manifest filter samples

manifest_order <- manifest_order %>% 
                  filter(Cohort =='M20-431') %>%
                  filter(Mosaic_ID != 'N/A')

final_list_edit <- final_list_edit[grepl(paste(manifest_order$Accession_number,collapse = '|'), 
                                         final_list_edit$Accession_number),]

df <- final_list_edit[grepl(paste(c('_statistics.tsv'),collapse = '|'), 
                                         final_list_edit$filepath),]

##4. download gene expression reports from s3 by print bash command lines and run command lines in terminal

for (i in 1: length(df$filepath)) {
  
  s3_loc <- df$filepath[i]
  filename <- paste(df$batchset[i], df$filetype[i],sep = '_')
  
  cmd <- paste('aws s3 cp s3://abv-arrayserver/', s3_loc, 
               ' --profile arrayserver /ui/abv/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorQC/', 
               filename,sep = '')
  
  write(cmd,file = '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/bash_cp_cmd_QC.sh', append = T)
  
}

##5. downlaod files from s3 to HPC from command line

##6. qc files

files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorQC',
                    #pattern = 'somatic_dna_small_variant_report_preferred',
                    #pattern = '.tsv',
                    full.names = T)

names(files) <- stringr::str_split(basename(files), pattern = '_statistics',simplify = T)[,1]

test <- data.frame(sample = names(files)) %>% 
  mutate(Accession_number = str_extract(sample, '\\d{10}'),
         batchset = str_split(sample, pattern = paste(c('_RNA','_DNA'), collapse = '|'), simplify = T)[,1]) %>% 
  filter(batchset != 'Batch2_SET_A_TO') %>% 
  filter(batchset != 'Batch5_TO')

test2 = test %>% group_by(Accession_number) %>% reframe(n())

## compiling the master data frame
# df<-read.delim(files[1], header = FALSE, sep = "\t", quote = "\"",
#            dec = ".", fill = TRUE, comment.char = "#", col.names = c("V1","V2","V3","V4","V5"))

counts <- purrr::map_df(files, function(x) {
                                      read.delim(x, header = FALSE, 
                                                 sep = "\t", quote = "\"",
                                                 dec = ".", fill = TRUE, comment.char = "#", 
                                                 col.names = c("V1","V2","V3","V4","V5"))
                                   }, .id = "sample") %>%
  left_join(.,test) %>% 
  filter(!is.na(batchset))

# write.csv(counts, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_somaticSNV_0827.csv',
#           row.names = F)
write.csv(counts, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_QCsummary_0827.csv',
          row.names = F)


###############################################################################################
#0. check if tumorDNAseq available samples are in QC passed list
###############################################################################################
QC_pass <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_QCsummary_0827.csv')
tumorDNAseq <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_inDNApipeline_ForImage_0903.csv')

match(tumorDNAseq$Accession_number,QC_pass$Accession_number%>%unique) %>% length()
## ALL the tumor DNA samples accession are in the QC passed accession list. Save to pull Images from these samples

###############################################################################################
#1. QC
###############################################################################################

counts_qc <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_QCsummary_0827.csv')

# working table

counts_qc_df <- counts_qc %>%
                     filter(V1 %in% 
                              c('Average base quality','Total reads','Percent contamination in Normal',
                                'Percent contamination in Tumor','Average read depth',
                                'Percent mapped reads','Somatic variants per Mb','Non-synonymous Somatic Variants per Mb',
                                'Number of expressed genes')) %>% 
  mutate(pipeline = str_extract(sample, '[DR]NA'))


##1. total reads

counts_qc_df %>% 
  filter(V1 == 'Total reads', pipeline == 'DNA')%>% 
  pivot_longer(cols = c('V2','V3')) %>% 
  mutate(name = ifelse(name == 'V2','Normal DNA','Tumor DNA')) %>% 
  mutate(value = parse_number(value))%>%
  ggplot(aes(x = sample,y=value, color=name)) +
  geom_point(shape=1,size=1) + 
  facet_wrap(~name,nrow = 2,scales = 'free') +
  scale_color_brewer(palette = "Set2") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_blank(),
        strip.background = element_rect(fill = 'white')) +
  labs(x='',color = '', y = 'Total Reads') 

##2. Average base quality

counts_qc_df %>% 
  filter(V1 == 'Average base quality', pipeline == 'DNA')%>% 
  pivot_longer(cols = c('V2','V3')) %>% 
  mutate(name = ifelse(name == 'V2','Normal DNA','Tumor DNA')) %>% 
  mutate(value = parse_number(value))%>%
  ggplot(aes(x = sample,y=value, fill=name)) +
  geom_bar(stat = 'identity',alpha=.5) + 
  facet_wrap(~name,nrow = 2,scales = 'free') +
  scale_fill_brewer(palette = "Set1") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_blank(),
        strip.background = element_rect(fill = 'white')) +
  labs(x='',color = '', y = 'Average base quality') 

##3. Average read depth

counts_qc_df %>% 
  filter(V1 == 'Average read depth', pipeline == 'DNA')%>% 
  pivot_longer(cols = c('V2','V3')) %>% 
  mutate(name = ifelse(name == 'V2','Normal DNA','Tumor DNA')) %>% 
  mutate(value = parse_number(value))%>%
  ggplot(aes(x = sample,y=value, color=name)) +
  geom_point(shape=10,size=2) + 
  facet_wrap(~name,nrow = 2,scales = 'free') +
  scale_color_brewer(palette = "Dark2") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_blank(),
        strip.background = element_rect(fill = 'white')) +
  labs(x='',color = '', y = 'Average read depth') 


##4. Percent mapped reads

counts_qc_df %>% 
  filter(V1 == 'Percent mapped reads', pipeline == 'DNA')%>% 
  pivot_longer(cols = c('V2','V3')) %>% 
  mutate(name = ifelse(name == 'V2','Normal DNA','Tumor DNA')) %>% 
  mutate(value = parse_number(value))%>%
  ggplot(aes(x = name,y=value, fill=name)) +
  geom_boxplot(alpha=.5)  +
  scale_fill_brewer(palette = "Accent") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_blank(),
        strip.background = element_rect(fill = 'white'),
        legend.position = 'bottom') +
  labs(x='',fill = '', y = 'Percent mapped reads') 

##5. Non-synonymous Somatic Variants per Mb

TMB <- counts_qc_df %>% 
  filter(V1 == 'Non-synonymous Somatic Variants per Mb', pipeline == 'DNA')%>% 
  pivot_longer(cols = c('V2','V3')) %>% 
  mutate(name = ifelse(name == 'V2','SNVs','Indels')) %>% 
  mutate(value = parse_number(value))

write.csv(TMB,'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch245_TMB.csv',row.names = F)

TMB %>%
  ggplot(aes(x = name,y=value, fill=name)) +
  geom_boxplot(alpha=.5) +
  scale_fill_brewer(palette = "Pastel1") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_blank(),
        strip.background = element_rect(fill = 'white'),
        legend.position = 'bottom') +
  labs(x='',fill = '', y = 'TMB (Number of Mutations/Mb)') 


##6. Number of expressed genes
counts_qc_df %>% 
  filter(pipeline == 'RNA', V1 %in% 
  c('Total reads','Average base quality','Percent mapped reads','Number of expressed genes'))%>% 
  mutate(V2 = parse_number(V2))%>%
  ggplot(aes(x = sample,y=V2, fill=V1)) +
  geom_bar(stat = 'identity') + 
  facet_wrap(~V1,nrow = 2,scales = 'free') +
  scale_fill_brewer(palette = "Set2") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_blank(),
        strip.background = element_rect(fill = 'white'),
        legend.position = 'none') +
  labs(x='',fill = '') 

# get the sample names
