library(tidyverse)
library(dplyr)
library(readxl)
library(data.table)
library(Biobase)
library(genefilter)
library(Rtsne)
library(ggplot2)
library(gridExtra)
library(pheatmap)
library(gplots)
library(limma)
library(RColorBrewer)
library(reshape)
library(GSVA)
library(quantiseqr)
library(ComplexHeatmap)
library(lessR)

##########################################################################################
### 1. file list on s3 and from shipment manifest
##########################################################################################

total_files <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/allS3files_431_124_1105.csv')
manifest <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/allS3files_431_124_manifest_1105.csv')
clinical <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/allS3files_431_124_clinical_1105.csv')

## filter total_files to only include dna snp report
final_list_df <- NULL

anno <- data.frame(files = c('somatic_dna_small_variant_report_preferred.xlsx'
                             ,'rna_gene_expression_report.xlsx',
                             'tcr_beta_clone_report.xlsx',
                             'bcr_heavy_chain_report.xlsx',
                             'somatic_dna_gene_cna_report.xlsx',
                             'neoantigen_statistics.tsv',
                             'immunogenomics_report.xlsx'),
                   abbre = c('SNP','GEX','TCR','BCR','CNA','NEOANTIGEN','IMMUNOGENOMICS'))
  
  for (i in 1:nrow(anno)) {
  
  files_i = anno$files[i]
  abbre_i = anno$abbre[i]
    
  total_files_fil <- total_files %>% 
    filter(grepl(files_i,filepath))
  
  working_df <- manifest %>% left_join(total_files_fil) %>% 
    mutate(Subject_ID = as.character(Patient_ID)) %>% 
    left_join(clinical %>% mutate(Subject_ID = as.character(Subject_ID)))
  
  final_list_edit <- working_df %>% mutate(
    batchset = str_extract(filepath, 'Batch\\d(_\\w+)') %>% 
      lapply(.,function(x) {head(strsplit(x, split = '_7')[[1]],1)[1]}) %>%
      unlist(),
    batchdate = str_extract(filepath, '\\d{4}_\\d{4}'),
    batchtotal = paste(batchset,batchdate,sep = '_'),
    filegroup = paste(abbre_i)
  )
  
  ## table view
  
  final_list_df_tbl_exp <- final_list_edit %>% 
    group_by(Batch_Type,Patient_ID,Accession_Number_original,Accession_number,
             Sample_Type,Visit,Cohort,Treatment,filegroup) %>% 
    reframe(batches = paste(unique(batchdate),collapse = ' ;'),
            file_batch = paste(filegroup,batches, sep = ' : '),
            upi = paste(Accession_number,
                        file_batch)) %>%
    filter(!duplicated(upi)) %>% 
    mutate(upi = ifelse( batches == 'NA', 'NA',upi)) %>%
    select(-c('batches',
              'file_batch'))
  
  final_list_df <- rbind(final_list_df, final_list_df_tbl_exp)
  
  rm(total_files_fil, working_df, final_list_edit,final_list_df_tbl_exp)
}

## table view

final_tbl <- final_list_df %>% 
  pivot_wider(names_from = filegroup, values_from = upi)

#df <- apply(final_tbl,2,as.character)

#combine with shipment manifest to check which sample has data delivery
test <- manifest %>% 
  left_join(final_tbl)

#avoid scientific annotation
test = mutate_if(test,is.numeric, as.character)

write.csv(test, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/final_list_inventory_124_431_table_1107.csv',row.names = F)

## plot

test <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/final_list_inventory_124_431_table_1107.csv')

test_gg <- test %>% pivot_longer(cols = 11:17) %>% 
  separate(value,into = c('number','batches'),sep = ':') 

test_gg_gb <- test_gg %>% filter(!is.na(batches)) %>% 
  group_by(Accession_Number_original) %>% 
  reframe(count = paste(unique(name), collapse = ' ;'),
          batches = unique(batches),
          upi = paste(count, batches, sep = ' :')) %>%
  filter(!duplicated(Accession_Number_original))

manifest <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/allS3files_431_124_manifest_1105.csv')

test_gg_gb_plt <- manifest %>% left_join(test_gg_gb) %>% 
  group_by(Batch_Type,Cohort,count,batches) %>% 
  reframe(name = n())


test_gg_gb_plt%>% 
  ggplot(aes(batches,name,fill = count,label = name)) +
  geom_col(position = 'dodge',color='black') +
  facet_wrap( ~ Batch_Type + Cohort ,scales = 'free') +
  theme_classic() +
  theme(axis.text.x = element_text(angle=90,size=7,hjust = 1)) +
  geom_text(size = 3,aes(y = name+3),angle=0, hjust = 0,
            position = position_dodge(width = .9)) +
  labs(x='',fill='')
  
  











