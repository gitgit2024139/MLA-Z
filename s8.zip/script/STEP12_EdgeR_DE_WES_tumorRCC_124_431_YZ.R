library(tidyverse)
library(dplyr)
library(readxl)
library(data.table)
library(Biobase)
library(genefilter)
library(Rtsne)
library(ggplot2)
library(gridExtra)
library(pheatmap)
library(gplots)
library(limma)
library(RColorBrewer)
library(reshape)
library(GSVA)
library(quantiseqr)
library(ComplexHeatmap)
library(lessR)

counts <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_RCC_counts_124_431_1030.csv')
tpm <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_RCC_TPM_124_431_1030.csv')
colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_RCC_124_431_colData_1030.csv')

colData <- colData %>% mutate (Accession_Number = paste('RNA_',Accession_number,sep = '')) %>%
  column_to_rownames('Accession_Number')


##Making diagnosis a little easier to work around from Kyle's code 20240912
colData$Diagnosis_edit <- colData$Diagnosis
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Breast Cancer (TNBC)", "Breast Cancer"))] <- "Breast"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("TNBC"))] <- "Breast"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Sigmoid colon cancer"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Adenocarcinoma of rectum", "Colon Cancer", "Colorectal Cancer"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Rectal Adenocarcinoma"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("MSI-H CRC"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("MSS CRC"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Malignant neoplasma of tonsil (HNSCC)"))] <- "HNSCC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Pancreatic Cancer"))] <- "Pancreatic"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Malignant Melanoma", "Melanoma"))] <- "Melanoma"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Soft Tissue Sarcoma", "Anaplastic Soft Tissue Sarcoma",
                                                            "Sarcoma", "Retropertioneal Synovial Sarcoma", "Chondrosarcoma",
                                                            "Clear Cell Sarcoma", "Myxoid Liposarcoma"))] <- "Sarcoma"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Urethral", "Urothelial Carcinoma"))] <- "Urothelial"
otherTmrs <- names(which(table(colData$Diagnosis_edit) <= 2))
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% otherTmrs)] <- "Other"

###############################################################################################
##1. load
###############################################################################################

##Loading RDS object with non-normalized counts and TPMs
counts
tpm
##Adding on pre/post for the two paired samples since that wasn't done in the 
colData <- colData[order(colData$Patient_ID, colData$Treatment),]
##expressionsets

tumorTPM <- ExpressionSet(assayData = tpm %>% dplyr::select(-1) %>% 
                            column_to_rownames('NCBI.Gene.ID') %>% 
                            dplyr::select(rownames(colData)) %>% as.matrix,
                          phenoData = AnnotatedDataFrame(colData),
                          featureData = AnnotatedDataFrame(
                            data.frame(symbol = tpm$Gene.Symbol, row.names = tpm$NCBI.Gene.ID))
)

## only analyze 484+579 baseline RCCs 20241105
rcc_list <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/final_RCC_list.csv')

tumorTPM <- tumorTPM[, tumorTPM$Accession_number %in% rcc_list$Accession_number]

tumorTPM <- tumorTPM[,c(5,6,1,4,2,3,7,8)]

tumorTPM$Treatment[8] <- 'Archival Pre'


##save expressionset for tumor subtyping work
# pData(tumorTPM) <- data.frame(BOR = tumorTPM$BOR, Diagnosis = tumorTPM$Diagnosis,
#                               Visit = tumorTPM$Visit, Batch_Type = tumorTPM$Batch_Type,
#                               Patient_ID = tumorTPM$Patient_ID, Cohort = tumorTPM$Cohort,
#                               Accession = tumorTPM$Accession_number)

## save for Liqian's tumor subtyping work 20241030
#saveRDS(tumorTPM, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/ccRCC_expressionset.rds')

## 20250210 IO atlas subtyping

IOatlas <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/final_RCC_list_IOatlas.csv')

IOatlas <- IOatlas[1:8,]

IOatlas %>% ggplot(aes(IO_Atlas.Assignment,fill = BOR)) +
  geom_bar() +
  ggtitle('New IO subtype assignment') +
  theme_classic()




##log2(+1) converting expression data for TPMs
exprs(tumorTPM) <- log2(exprs(tumorTPM) + 1)

# QC plots
#Plotting some QC plots prior to differential expression analysis. 

hist(rowMeans(exprs(tumorTPM)))

##Histogram of row vars
hist(rowVars(exprs(tumorTPM)))

#Potentially an outlier. Checking which genes are over 15. 

intGenes <- which(rowVars(exprs(tumorTPM)) >5)
intGS <- fData(tumorTPM)$symbol[ which(featureNames(tumorTPM) %in% intGenes)]

print(intGS)

#Alright, some reasonable genes in there (H2BC3 in particular) but others
#not sure why variance so high. Will not exclude, but will monitor for inclusion
#in analysis down the road. 

# Sample distribution
# Now working on sample distribution, specifically to see what the sample-sample
# relationships are. 

## Sample expression tSNE

##Subsetting to variable and expressed genes
rnaTUSE <- exprs(tumorTPM)[ which(rowMeans(exprs(tumorTPM)) > 2.5 & 
                                  rowVars(exprs(tumorTPM)) > 0.15), ]

##Getting tsne together
set.seed(777)
tstTSNE <- Rtsne(t(rnaTUSE),
                 check_duplicates=FALSE,
                 pca=TRUE,
                 perplexity=2,
                 theta=0.5,
                 dims=2)

##Making a dataframe for plotting
tstTSNEDF <- as.data.frame(tstTSNE$Y)
tstTSNEDF$Patient_ID <- factor(tumorTPM$Patient_ID)
tstTSNEDF$Mosaic_ID <- factor(tumorTPM$Mosaic_ID)
tstTSNEDF$Treatment <- factor(tumorTPM$Visit)
tstTSNEDF$Diagnosis <- factor(tumorTPM$Diagnosis_edit)
tstTSNEDF$name <- factor(paste(tumorTPM$Patient_ID,tumorTPM$Treatment, tumorTPM$Diagnosis_edit, sep = '_'))
tstTSNEDF$Cohort <- factor(tumorTPM$Cohort)
tstTSNEDF$Batch_Type <- factor(tumorTPM$Batch_Type)


##Plotting
ggplot(data = tstTSNEDF, aes(x = V1, y = V2, col = Batch_Type, label = name,shape = Cohort)) +
  #geom_label(size = 4) + 
  ggrepel::geom_label_repel(size = 3) + 
  geom_point(size = 5)+
  scale_x_continuous("tSNE X") +
  scale_y_continuous("tSNE Y") +
  #scale_color_manual(values = c("Archival Pre" = "navy","Fresh Pre" = 'black', 
  #                              "On-Treatment" = "red")) + 
  theme_classic(base_size = 10) +
  theme(plot.title = element_text(hjust = 0.5)) 

## Heatmap of key genes

##Plotting some relevant genes
intGenes <- c("CD274", "CXCL9", "CXCL10", "IFNG", "GZMB", "PRF1", "CD3E", "CD4",
              "CD8A", "NKG7",'NKG2D','TRGV4','TRDV1', "KLRC1", "ARG1", "CLEC9A", "CD68", "CD163",
              "FOXP3", "CTLA4", "ICOS", "HAVCR2", "MKI67", "CENPA")

##Subsetting to only these genes
rnaLINT <- tumorTPM[ which(fData(tumorTPM)$symbol %in% intGenes), ]
rnaLINT$sample_label <- paste(rnaLINT$Patient_ID, rnaLINT$Treatment,sep = '_')

##Peeling off, subsetting annotation data
annoSS <- pData(rnaLINT) %>% dplyr::select(#"Patient_ID", #"Mosaic_ID", 
                                    "Diagnosis", "BOR", 
                                     # "Months on Treatment",
                                    'Treatment'
                                    #,'sample_label' 
                                    )

##Heatmap
ComplexHeatmap::pheatmap(exprs(rnaLINT),
         labels_row = fData(rnaLINT)$symbol,
         labels_col = pData(rnaLINT)$sample_label,
         show_colnames = TRUE, 
         show_rownames = TRUE,
         annotation_colors = list(#"Diagnosis" =   c("HNSCC" = "magenta",
                                  #              "RCC" = "yellow"),
                                  "BOR" = c("CR" = "red",
                                            "PD" = "grey60",
                                            "SD" = "green",
                                            'NE' = 'black',
                                            'PR' = 'purple'),
                                  "Treatment" = c("Archival Pre" = "grey40","Fresh Pre" = 'grey', 
                                                  "On-Treatment" = "orange")),
         
         color = colorpanel(100, "blue", "white", "red"),
         scale = "row",
         clustering_distance_rows = "euclidean",
         clustering_method = "ward.D2",
         cluster_rows = T,
         cluster_cols = F,
         annotation_col = annoSS )

##Getting clustering
allClust <- hclust(dist(scale(t(exprs(rnaLINT)))), method = "ward.D2")

##assignments
clustAssign <- cutree(allClust, k = 4)

plot(allClust, labels = clustAssign)

# clustEdit <- clustAssign
# clustEdit[which(clustEdit %in% c(1,4))] <- "Inflamed"
# clustEdit[which(clustEdit == 2)] <- "Proliferative/Moderate"
# clustEdit[which(clustEdit == 3)] <- "Cold"


## Difference in key genes across pre/post samples
##Melting expression
rnaLPMELT <- as.data.frame(melt(exprs(rnaLINT), ))
colnames(rnaLPMELT) <- c("gene_id", "sample_id", "expression")

rnaLPMELT <- pData(rnaLINT) %>% rownames_to_column(var = 'sample_id') %>% 
  merge(.,rnaLPMELT) %>% merge(., fData(rnaLINT) %>% rownames_to_column('gene_id'))

#Now plotting as barplots I guess for now. 

order <- c("MKI67", "CENPA","CD274","CTLA4","CXCL9", "CXCL10", "IFNG", "CD3E", "CD4",
              "CD8A", "NKG7",'NKG2D',"GZMB", "PRF1", "KLRC1", "CLEC9A", "CD68", "CD163","ARG1", 
              "FOXP3", "HAVCR2","ICOS")

ggplot(rnaLPMELT %>% mutate(symbol = factor(symbol,levels = order)), 
       aes(x = Treatment, y = expression, fill = Treatment)) +
  geom_bar(stat = "identity") + 
  facet_grid(Patient_ID ~ symbol) + 
  theme_bw(base_size = 10,base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0, "cm"), 
        axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
        legend.position = 'top',strip.background = element_rect(fill = 'white')) +
  labs(x = '', y = 'Expression log2(tpm + 1)', fill = '') 

#Looks quite good actually. Redoing, but with PTPN2-specific genes attached. 

##Plotting some relevant genes
intGenes <- c("PTPN1", "PTPN2", "JAK1", "JAK3", "STAT1", "STAT3", "STAT5A", "STAT5B")

##Subsetting to only these genes
rnaLINT <- tumorTPM[ which(fData(tumorTPM)$symbol %in% intGenes), ]

##Melting expression
rnaLPMELT <- as.data.frame(melt(exprs(rnaLINT), ))
colnames(rnaLPMELT) <- c("gene_id", "sample_id", "expression")

rnaLPMELT <- pData(rnaLINT) %>% rownames_to_column(var = 'sample_id') %>% 
  merge(.,rnaLPMELT) %>% merge(., fData(rnaLINT) %>% rownames_to_column('gene_id'))

##And plotting
ggplot(rnaLPMELT, aes(x = Treatment, y = expression, fill = Treatment)) +
  geom_bar(stat = "identity") + 
  facet_grid(Patient_ID ~ symbol) + 
  theme_bw(base_size = 10,base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0, "cm"), 
        axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
        legend.position = 'top',strip.background = element_rect(fill = 'white')) +
  labs(x = '', y = 'Expression log2(tpm + 1)', fill = '') 

##20240909 Plotting some relevant genes
intGenes <- c("ANKRD9", "TCF3", "RAP1GAP","ARG2")

##Subsetting to only these genes
rnaLINT <- tumorTPM[ which(fData(tumorTPM)$symbol %in% intGenes), ]

##Melting expression
rnaLPMELT <- as.data.frame(melt(exprs(rnaLINT), ))
colnames(rnaLPMELT) <- c("gene_id", "sample_id", "expression")

rnaLPMELT <- pData(rnaLINT) %>% rownames_to_column(var = 'sample_id') %>% 
  merge(.,rnaLPMELT) %>% merge(., fData(rnaLINT) %>% rownames_to_column('gene_id'))

##And plotting
ggplot(rnaLPMELT, aes(x = Treatment, y = expression)) +
  geom_boxplot(aes(fill = Treatment), alpha = .4)+
  geom_line(aes(group = Patient_ID),linetype = 2) + 
  geom_point(size=2,shape = 21, aes(fill = Treatment)) +
  facet_wrap(~ symbol,nrow = 1) + 
  theme_bw(base_size = 10,base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0, "cm"), 
        axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
        legend.position = 'right',strip.background = element_rect(fill = 'white')) +
  labs(x = '', y = 'Expression (log2 TPM + 1)', fill = '') 


# Gene set analysis
## Gene set scoring for sample TME composition
#First calculating TME composition via gene set scores from IO Atlas project. 
#Doing this as a quick first-pass for composition. 

##Relabeling featureNames
rnaETPM <- tumorTPM
rnaETPM <- rnaETPM[ duplicated(fData(rnaETPM)$symbol) == FALSE, ]
featureNames(rnaETPM) <- fData(rnaETPM)$symbol

##Loading gene sets
#library(qusage)
#geneList <-qusage::read.gmt('modules_plus_singletons_01052023_rename.gmt')
#saveRDS(geneList,'modules_plus_singletons_01052023_rename.rds')
#geneList <-qusage::read.gmt('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/core_modules_01052023_rename.gmt')
#saveRDS(geneList,'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/core_modules_01052023_rename.rds')

geneList <- readRDS('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/core_modules_01052023_rename.rds')

##Filtering
gLUSE <- GSVA::filterGeneSets(geneList, 
                        min.sz = 3, 
                        max.sz = 500)

##Scoring via ssGSEA
allRES <- gsva(expr = exprs(rnaETPM), 
               gset.idx.list = gLUSE,
               method = "ssgsea", 
               ssgsea.norm = F)



#Some jank in there, but seems to have run fine. 

#saveRDS(allRES, file = "~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/results/core_geneset_gsva_41tumors.rds")

## Heatmap of gene sets
#Going to use prior heatmap ordering here, with a subset of gene sets. 

##Peeling off, subsetting annotation data
annoFULL <- pData(rnaETPM)
annoSS <- annoFULL %>% dplyr::select(#"Patient_ID", #"Mosaic_ID", 
  "Diagnosis", "BOR", 
  # "Months on Treatment",
  'Treatment' )

##Heatmap
pheatmap(allRES,
         labels_col = paste(annoFULL$Patient_ID, annoFULL$Treatment,sep="_"),
         show_colnames = TRUE, 
         show_rownames = TRUE,
         annotation_colors = list(#"Diagnosis" =   c("HNSCC" = "magenta",
                                  #                  "RCC" = "yellow"),
                                  "BOR" = c("CR" = "red",
                                            "PD" = "grey60",
                                            "SD" = "green",
                                            'NE' = 'black',
                                            'PR' = 'purple'),
                                  "Treatment" = c("Archival Pre" = "grey40","Fresh Pre" = 'grey', 
                                                  "On-Treatment" = "orange")),
         
         color = colorpanel(100, "blue", "white", "red"),
         scale = "row",
         cluster_cols = FALSE,
         clustering_distance_rows = "euclidean",
         clustering_method = "ward.D2",
         annotation_col = annoSS)

#corresponds well with the gene-level visualization. Going to save this as well. 

############# all gene sets
##Heatmap
geneList <- readRDS('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/modules_plus_singletons_01052023_rename.rds')
gLUSE <- GSVA::filterGeneSets(geneList, 
                              min.sz = 3, 
                              max.sz = 500)

##Scoring via ssGSEA
allRES <- gsva(expr = exprs(rnaETPM), 
               gset.idx.list = gLUSE,
               method = "ssgsea", 
               ssgsea.norm = F)

#saveRDS(allRES, file = "~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/results/all_geneset_gsva_41tumors.rds")

annoFULL <- pData(rnaETPM)
annoSS <- annoFULL %>% select(#"Patient_ID", #"Mosaic_ID", 
                              "Diagnosis", "BOR", 
                              # "Months on Treatment",
                              'Treatment')

##Heatmap
pheatmap(allRES,
         labels_col = paste(annoFULL$Patient_ID, annoFULL$Treatment,sep="_"),
         show_colnames = TRUE, 
         show_rownames = TRUE,
         annotation_colors = list(#"Diagnosis" =   c("HNSCC" = "magenta",
                                  #                  "RCC" = "yellow"),
                                  "BOR" = c("CR" = "red",
                                            "PD" = "grey60",
                                            "SD" = "green",
                                            'NE' = 'black',
                                            'PR' = 'purple'),
                                  "Treatment" = c("Archival Pre" = "grey40","Fresh Pre" = 'grey', 
                                                  "On-Treatment" = "orange")),
         
         color = colorpanel(100, "blue", "white", "red"),
         scale = "row",
         cluster_cols = FALSE,
         clustering_distance_rows = "euclidean",
         clustering_method = "ward.D2",
         annotation_col = annoSS)

#corresponds well with the gene-level visualization. Going to save this as well. 

########################################################################################################################################################
## 2024-11-14 Andy Minn ISG gene sets
########################################################################################################################################################

## 1. ISG signatures (IFNα and IFNγ hallmark gene sets) ‘Clinical and molecular features of acquired resistance to immunotherapy in non-small cell lung cancer’ Literature 
library(msigdbr)

h_gene_sets = msigdbr(species = "human", category = "H") %>% 
  filter(grepl('INTERFERON',gs_name)) %>% 
  group_by(gs_name) %>% filter(!duplicated(gene_symbol))

##Plotting some relevant genes
intGenes <- h_gene_sets %>% filter(gs_name == 'HALLMARK_INTERFERON_GAMMA_RESPONSE') %>% pull(gene_symbol) %>% sample(50)
intGenes <- h_gene_sets %>% filter(gs_name == 'HALLMARK_INTERFERON_ALPHA_RESPONSE') %>% pull(gene_symbol)
intGenes <- c('ADAR','CNTFR','CREB1','CREB3','CRLF2','CSF2RA','CSF3R','CXCL10','EBI3','F3','IFI16','IFI27',
              'IFI30','IFI35','IFI44','IFI44L','IFI6','IFIH1','IFIT1','IFIT1B','IFIT2','IFIT3','IFITM1','IFITM2',
              'IFNA1','IFNA14','IFNA2','IFNA21','IFNA4','IFNA5','IFNA6','IFNA8','IFNAR1','IFNAR2','IFNB1','IFNE','IFNG','IFNGR1',
              'IFNGR2','IFNK','IFNW1','IFRD1','IFRD2','IL10RA','IL10RB','IL11RA','IL12A','IL12B','IL13RA1','IL15','IL20RA','IL20RB',
              'IL21R','IL22RA2','IL28A','IL28RA','IL29','IL2RB','IL2RG','IL31RA','IL3RA','IL4R','IL5RA','IL6','IL6R','IL7R','IL9R','IRF1',
              'IRF2','IRF2BP1','IRF2BP2','IRF3','IRF4','IRF5','IRF6','IRF7','IRF8','IRF9','IRGM','ISG15','JAK1','JAK2','LEPR','MPL','MX1',
              'OAS1','PIAS1','PIAS4','PIK3CA','PRKCD','PSME1','PYHIN1','SOCS1','SOCS3','SP110','STAT1','STAT2','STAT3','STAT4','TBX21','TYK2')
intGenes <- c('IFNGR1','IFNGR2','IFNAR1','IFNAR2','STAT1','STAT2','IRF9','JAK1','JAK2','TYK2','B2M')             

##Subsetting to only these genes
rnaLINT <- tumorTPM[ which(fData(tumorTPM)$symbol %in% intGenes), ]
rnaLINT$sample_label <- paste(rnaLINT$Patient_ID, rnaLINT$Treatment,sep = '_')

##Peeling off, subsetting annotation data
annoSS <- pData(rnaLINT) %>% dplyr::select(#"Patient_ID", #"Mosaic_ID", 
  "Diagnosis", "BOR", 
  # "Months on Treatment",
  'Treatment'
  #,'sample_label' 
)

##Heatmap
ComplexHeatmap::pheatmap(exprs(rnaLINT),
                         labels_row = fData(rnaLINT)$symbol,
                         labels_col = pData(rnaLINT)$sample_label,
                         show_colnames = TRUE, 
                         show_rownames = TRUE,
                         annotation_colors = list(#"Diagnosis" =   c("HNSCC" = "magenta",
                           #              "RCC" = "yellow"),
                           "BOR" = c("CR" = "red",
                                     "PD" = "grey60",
                                     "SD" = "green",
                                     'NE' = 'black',
                                     'PR' = 'purple'),
                           "Treatment" = c("Archival Pre" = "grey40","Fresh Pre" = 'grey', 
                                           "On-Treatment" = "orange")),
                         
                         color = colorpanel(100, "blue", "white", "red"),
                         scale = "row",
                         clustering_distance_rows = "euclidean",
                         clustering_method = "ward.D2",
                         cluster_rows = T,
                         cluster_cols = F,
                         annotation_col = annoSS,
                         fontsize_row = 10)

## GSVA for different IFN gene sets
ISG_RS <-c('IFI27','IRF7','USP18','BST2','CXCL10','DDX60','HERC6','HLA-B','HLA-G','IFI35','IFI44','IFI44L','IFIT1','IFIT3',
           'ISG15','LGALS3BP','LY6E','MX1','MX2','OAS3','OASL','PLSCR1','STAT1','TRIM14','HSD17B1','OAS1','CA2','CCNA1','CXCL1',
           'GALC','IFI6','IFITM1','LAMP3','MCL1','RO6O1','SLC6A15','THBS1','TIMP3')

IFNG_GS <-c('TNFSF10','IRF9','PSMB9','EPSTI1','PARP12','TRIM25','LAP3','CASP7','UPP1','B2M','IRF4','SRI','NFKBIA','IFIT2','OAS2',
            'TAP1','EIF2AK2','RSAD2','IRF1','XAF1','SP110','PSMB8','IFITM3','GBP4','IRF8','PML','IFIH1','UBE2L6','ADAR','STAT2',
            'CXCL9','IL10RA','PLA2G4A','TRIM21','PTGS2','C1S','DDX58','IL15','NLRC5','NMI','IDO1','PSMB10','CXCL11','ITGB7',
            'SAMHD1','CMPK2','SAMD9L','RTP4','PTPN2','PARP14','TNFAIP2','IFITM2','SOCS1','CASP1','ICAM1','WARS','PSME1','ISG20',
            'IRF2','FCGR1A','MARCH1','SOCS3','JAK2','HLA-DMA','TNFAIP6','TRIM26','VCAM1','CD274','CIITA','NAMPT','SELP','GPR18',
            'FPR1','PRIC285','PSME2','SERPING1','CCL5','RNF31','SOD2','PSMA3','RNF213','PELI1','CFB','CD86','TXNIP','HLA-DQA1',
            'GCH1','PNP','CCL7','PTPN6','SPPL2A','IL4R','PNPT1','DHX58','BTG1','CASP8','IFI30','CCL2','FGL2','SECTM1','IL15RA',
            'CD40','TRAFD1','HLA-DRB1','GBP6','LCP2','MT2A','RIPK1','KLRK1','PSMB2','TDRD7','HIF1A','EIF4E3','VAMP8','PFKP','CD38',
            'ZBP1','BANK1','TOR1B','RBCK1','PED4B','MVP','IL7','BPGM','FTSJD2','AUTS2','RIPK2','CD69','MYD88','PSMA2','PIM1','NOD1',
            'CFH','TAPBP','SLC25A28','PTPN1','TNFAIP3','SSPN','NUP93','MTHFD2','CDKN1A','NFKB1','BATF2','LATS2','IRF5','SLAMF7',
            'ISOC1','P2RY14','STAT3','NCOA3','HLA-A','IL6','GZMA','IFNAR2','CD74','RAPGEF6','CASP4','FAS','OGFR','ARL4A','LYSMD2',
            'CSF2RB','ST3GAL5','C1R','CASP3','CMKLR1','METTL7B','ST8SIA4','XCL1','IL2RB','VAMP5','IL18BP','ZNFX1','ARID5B','APOL6','STAT4')

IFNG_27667683 <- c('ADAR','CNTFR','CREB1','CREB3','CRLF2','CSF2RA','CSF3R','CXCL10','EBI3','F3','IFI16','IFI27',
                   'IFI30','IFI35','IFI44','IFI44L','IFI6','IFIH1','IFIT1','IFIT1B','IFIT2','IFIT3','IFITM1','IFITM2',
                   'IFNA1','IFNA14','IFNA2','IFNA21','IFNA4','IFNA5','IFNA6','IFNA8','IFNAR1','IFNAR2','IFNB1','IFNE','IFNG','IFNGR1',
                   'IFNGR2','IFNK','IFNW1','IFRD1','IFRD2','IL10RA','IL10RB','IL11RA','IL12A','IL12B','IL13RA1','IL15','IL20RA','IL20RB',
                   'IL21R','IL22RA2','IL28A','IL28RA','IL29','IL2RB','IL2RG','IL31RA','IL3RA','IL4R','IL5RA','IL6','IL6R','IL7R','IL9R','IRF1',
                   'IRF2','IRF2BP1','IRF2BP2','IRF3','IRF4','IRF5','IRF6','IRF7','IRF8','IRF9','IRGM','ISG15','JAK1','JAK2','LEPR','MPL','MX1',
                   'OAS1','PIAS1','PIAS4','PIK3CA','PRKCD','PSME1','PYHIN1','SOCS1','SOCS3','SP110','STAT1','STAT2','STAT3','STAT4','TBX21','TYK2')

IFNG_31398344 <- c('IFNGR1','IFNGR2','IFNAR1','IFNAR2','STAT1','STAT2','IRF9','JAK1','JAK2','TYK2','B2M')             

IFNG_hallmark <- h_gene_sets %>% filter(gs_name == 'HALLMARK_INTERFERON_GAMMA_RESPONSE') %>% pull(gene_symbol)
IFNA_hallmark <- h_gene_sets %>% filter(gs_name == 'HALLMARK_INTERFERON_ALPHA_RESPONSE') %>% pull(gene_symbol)


geneList <- list('ISG_RS' = ISG_RS,
               'IFNG_GS' = IFNG_GS,
               'IFNG_27667683' = IFNG_27667683,
               'IFNG_31398344' = IFNG_31398344,
               'IFNG_hallmark' = IFNG_hallmark,
               'IFNA_hallmark' = IFNA_hallmark)



gLUSE <- GSVA::filterGeneSets(geneList, 
                              min.sz = 3, 
                              max.sz = 500)

##Scoring via ssGSEA
allRES <- gsva(expr = exprs(rnaETPM), 
               gset.idx.list = gLUSE,
               method = "ssgsea", 
               ssgsea.norm = F)

#saveRDS(allRES, file = "~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/results/all_geneset_gsva_41tumors.rds")

annoFULL <- pData(rnaETPM)
annoSS <- annoFULL %>% select(#"Patient_ID", #"Mosaic_ID", 
  "Diagnosis", "BOR", 
  # "Months on Treatment",
  'Treatment')

##Heatmap
pheatmap(allRES,
         labels_col = paste(annoFULL$Patient_ID, annoFULL$Treatment,sep="_"),
         show_colnames = TRUE, 
         show_rownames = TRUE,
         annotation_colors = list(#"Diagnosis" =   c("HNSCC" = "magenta",
           #                  "RCC" = "yellow"),
           "BOR" = c("CR" = "red",
                     "PD" = "grey60",
                     "SD" = "green",
                     'NE' = 'black',
                     'PR' = 'purple'),
           "Treatment" = c("Archival Pre" = "grey40","Fresh Pre" = 'grey', 
                           "On-Treatment" = "orange")),
         
         color = colorpanel(100, "blue", "white", "red"),
         scale = "row",
         cluster_cols = FALSE,
         clustering_distance_rows = "euclidean",
         clustering_method = "ward.D2",
         annotation_col = annoSS)


##########################
## using quantiseqr to deconvolute cell type composition in bulkRNAsq
library(AnnotationDbi)
library(org.Hs.eg.db)

#an ExpressionSet object (from the Biobase package), where the HGNC
#gene symbols are provided in a column of the fData slot - that is specified
#by the column parameter below

##checked no duplicated genes
tpm <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_RCC_TPM_124_431_1030.csv') 

tpm <- tpm[,c(1:2,match(colnames(tumorTPM),colnames(tpm)))]


## try annotationdb 
columns(org.Hs.eg.db)
keytypes(org.Hs.eg.db)

annots <- select(org.Hs.eg.db, keys=tpm$NCBI.Gene.ID %>% as.character(),
                 columns=c("SYMBOL",'ENTREZID'), keytype="ENTREZID")
  
resultTable <- merge(annots,tpm, by.x="ENTREZID", by.y='NCBI.Gene.ID')

# entrezID matches with NCBI id
all(annots$ENTREZID %in% tpm$NCBI.Gene.ID)
#[1] TRUE

#but symbol doesn't match gene symbol in all cases
all(resultTable$SYMBOL %in% resultTable$`Gene Symbol`)
#[1] FALSE

# no symbol genes from annotationdbi
test <- resultTable %>% filter(is.na(resultTable$SYMBOL))
dim(test)[1]

exprTPM <- resultTable %>% filter(!is.na(resultTable$SYMBOL)) %>% 
  column_to_rownames('SYMBOL') %>% dplyr::select(-c(1:2))

#colnames(exprTPM) <- colnam$complexname

composition <- quantiseqr::run_quantiseq(
  expression_data = exprTPM,
  signature_matrix = "TIL10",
  is_arraydata = FALSE,
  is_tumordata = TRUE,
  scale_mRNA = TRUE,
  column = 'symbol'
)

quantiplot(composition)

## use ggplot for cell composition, remove Other cells

composition_gg <- composition %>% pivot_longer(cols = 2:12) %>% 
  filter(name != 'Other') %>%
  dplyr::rename('cell_type' = 'name', 'Fraction' = 'value') %>%
  merge(.,pData(tumorTPM) %>% mutate(Sample = paste(rownames(.))), by.x = 'Sample', by.y = 'Sample') %>% 
  mutate(name = paste(Subject_ID, Treatment))

composition_gg %>% 
  mutate (BOR = factor(BOR, levels = c('CR','PR','SD','PD','NE'))) %>% 
  ggplot(aes(x = name, y = Fraction, fill=cell_type)) +
  geom_bar(stat = 'identity',color='black') +
  facet_wrap(~BOR ,nrow = 1,scales = 'free_x') +
  scale_fill_brewer(palette = "Paired") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_text(angle = 90),
        strip.background = element_rect(fill = 'white')) +
  labs(x='')
  
##########################################################################################
### 2. MIRACLE scores
#https://github.com/tolgaturan-github/Miracle
#Briefly, the cohorts where immune infiltrate has good prognosis association as well as the ones with opposite prognosis association are used as training sets. 
#The markers generated by the training samples are used to calculate single-sample GeneSet Enrichment (ssGSE) scores and mathematical ratio of ssGSE scores of 
#good prognosis cohorts to worse prognosis cohorts gives Miracle Score.
#########################################################################################################
library(devtools)
# install_github("miccec/yaGST")
# install_github("tolgaturan-github/Miracle")
library(survival)
library(ggplot2)
library(Miracle)
data("SURV_BLCA","TCGA_BLCA_EDASeq_norm",package="Miracle") 
head(SURV_BLCA)
TCGA_BLCA_EDASeq_norm[1:5, 1:5]

#Calculate ICR and Miracle Scores and merge with survival data:
TCGA_ICR_and_miracle_scores<-Calculate_Miracle(TCGA_BLCA_EDASeq_norm, "ens")
head(TCGA_ICR_and_miracle_scores)
all(rownames(TCGA_ICR_and_miracle_scores)==SURV_BLCA[,1])
TCGA_BLCA_Miracle_SURV<-cbind(SURV_BLCA, TCGA_ICR_and_miracle_scores)
head(TCGA_BLCA_Miracle_SURV)
#Calculate Survival association of ICR in TCGA_BLCA Cohort:
coxph(Surv(Time, Status)~ICR, data=TCGA_BLCA_Miracle_SURV)
#Calculate Response association of Miracle in GSE91061:
t.test(Miracle~Response, data=GSE91061_Miracle_Response)
#Visualize Miracle Association with Response in GSE91061:
ggplot(GSE91061_Miracle_Response, aes(x=Response, y=Miracle, colour=Response))+
  geom_boxplot(outlier.shape=NA)+geom_jitter(shape=16, position=position_jitter(0.2))

## test in 8 ccRCC samples
mtx <- exprs(tumorTPM)
colData <- pData(tumorTPM)

ccRCC_ICR_and_miracle_scores<-Calculate_Miracle(mtx, "entrez")
head(ccRCC_ICR_and_miracle_scores)
all(rownames(ccRCC_ICR_and_miracle_scores)==rownames(colData))

ccRCC_Miracle_SURV<-cbind(ccRCC_ICR_and_miracle_scores, colData)
head(ccRCC_Miracle_SURV)
#Calculate Survival association of ICR in TCGA_BLCA Cohort:
#coxph(Surv(Time, Status)~ICR, data=ccRCC_Miracle_SURV)
#Calculate Response association of Miracle in GSE91061:
#t.test(Miracle~BOR, data=ccRCC_Miracle_SURV)

#Visualize Miracle Association with Response in GSE91061:
ccRCC_Miracle_SURV <- ccRCC_Miracle_SURV %>% mutate(name = paste(Subject_ID, Treatment))

ggplot(ccRCC_Miracle_SURV, aes(x=BOR, y=Miracle, colour=BOR,label = name))+
  geom_boxplot(outlier.shape=NA)+
  ggrepel::geom_label_repel()+
  geom_jitter(shape=16, position=position_jitter(0.2))+
  theme_classic()

write.csv(ccRCC_Miracle_SURV, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/ccRCC_MIRACLEscore.csv',row.names = F)

##########################################################################################
### 3. mutation heatmaps for genes associated with IO atlas 4 groups and prognosis
##########################################################################################
rcc_list <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/ccRCC_MIRACLEscore.csv')
total_files <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/allS3files_431_124_1105.csv')
manifest <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/allS3files_431_124_manifest_1105.csv')
clinical <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/allS3files_431_124_clinical_1105.csv')

working_df <- manifest %>% left_join(total_files) %>% 
  mutate(Subject_ID = as.character(Patient_ID)) %>% 
  left_join(clinical %>% mutate(Subject_ID = as.character(Subject_ID))) %>%
  filter(!is.na(filepath)) %>%
  filter(Sample_Type == 'Tissue') %>%
  filter(suffix == 'xlsx',pipeline == 'DNA', Diagnosis_Standardized == 'RCC') %>%
  mutate(Treatment = ifelse(is.na(Treatment),Visit,Treatment)) %>%
  filter(Treatment != 'On-Treatment') %>%
  filter(grepl('somatic_dna_small_variant_report_preferred', filetype)) %>%
  filter(!duplicated(Accession_number))


final_list_edit <- working_df %>% mutate(
  batchset = str_extract(filepath, 'Batch\\d(_\\w+)') %>% 
    lapply(.,function(x) {head(strsplit(x, split = '_7')[[1]],1)[1]}) %>%
    unlist(),
  batchdate = str_extract(filepath, '\\d{4}_\\d{4}'),
  batchtotal = paste(batchset,batchdate,sep = '_')
)

### download script
for (i in 1: length(final_list_edit$filepath)) {
  
  s3_loc <- final_list_edit$filepath[i]
  filename <- paste(final_list_edit$batchset[i], final_list_edit$filetype[i],sep = '_')
  
  cmd <- paste('aws s3 cp s3://abv-arrayserver/', s3_loc, 
               ' --profile arrayserver /ui/abv/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_rccDNAmut/', 
               filename,sep = '')
  
  write(cmd,file = '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/bash_cp_cmd_rcc_dna.sh', append = T)
  
}

##7. rbind snv files
files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_rccDNAmut/',
                    pattern = 'xlsx',
                    full.names = T)

names(files) <- stringr::str_split(basename(files), pattern = '_somatic_dna',simplify = T)[,1]

counts <- purrr::map_df(files, .f = read_excel, .id = "sample")


write.csv(counts, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_rcc_tumorSNV_1105.csv',
          row.names = F)

###############################################################################################
#1. somatic mutation proportion
###############################################################################################
#tumorSNV, somaticSNV

#counts <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_tumorSNV_0827.csv')
counts_somatic <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_rcc_tumorSNV_1105.csv')
colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/ccRCC_MIRACLEscore.csv')
colData$Diagnosis_edit <- colData$Diagnosis

counts_somatic <- counts_somatic %>%
  mutate(Accession_number = str_extract(sample,'\\d{10}') %>%
           parse_number(.))
# all variants including intronic/synonymous
counts_somaticSNV_allVar <- left_join(counts_somatic,colData,by = 'Accession_number') %>% 
  separate(col = Variant.Effect,into = c('Variant.Effect'),sep = '\\+',extra = 'drop')

########################################################################################################################################
## function to draw the oncoplot
draw_oncoprint <- function(f,number_of_genes = n, genelist = x) {
  
  unique_genes_sample <- f %>% 
    filter(!is.na(Transcript.Biotype))%>% 
    group_by(Gene.Symbol) %>%
    reframe(Variant.Type = paste(unique(Variant.Type) %>% sort, collapse = ';') , 
            occurrance = n(),
            nsample = length(unique(sample)))
  
  # select the top 10 most mutated genes
  
  if (!is.na(number_of_genes)) {
    
    n = number_of_genes
    
    top50genes_df <- unique_genes_sample %>% arrange(-occurrance) %>%
      slice_head(n = n)
    
    column_title = paste("Top ",n," hotspot Mutation heatmap for M20-431 tumors",sep = '')
    
  } else {
    
    x = genelist
    
    # select the top 10 most mutated genes
    top50genes_df <- unique_genes_sample %>% 
      filter(Gene.Symbol %in% x)
    
    n = length(top50genes_df$Gene.Symbol)
    
    column_title = paste("PTPN2-JAK-STAT pathway Mutation heatmap for M20-431 tumors",sep = '')
    
  }
  
  table(top50genes_df$Variant.Type) %>% sort()
  
  top50genes <- top50genes_df %>% pull(Gene.Symbol)
  top50genes
  # get the sample names
  sample_order = f %>% group_by(Diagnosis_edit,Patient_ID,Treatment) %>%
    reframe(sample = unique(sample),BOR = unique(BOR),
            Accession_Number = unique(Accession_number)) %>%
    mutate(name = paste(Patient_ID,Treatment,sep = '_')) 
  
  samplenames <- sample_order$sample
  samplenames
  # initialize a gene by sample matrix
  mat <- matrix("", 
                ncol=length(samplenames), 
                nrow=length(top50genes), 
                dimnames=list(top50genes, samplenames))
  
  # go through all genes and change the entry to "MUT" if a gene is mutated in a particular sample
  for(gene in top50genes){
    # get the samples that have a mutation in the gene
    mutated_samples <- df %>% 
      #select(sample,Gene.Symbol,Variant.Type)%>%
      filter(Gene.Symbol == gene)
    
    # set the entries in the matrix to "MUT"
    for (smp in mutated_samples$sample) {
      mat[gene, smp] <- as.character(paste(mutated_samples[mutated_samples[,"sample"] == smp, 
                                                           "Variant.Type"] %>%
                                             unique %>% sort, collapse = ';'))
    }
  }
  
  #change column name to better understandable name
  colnames(mat) == sample_order$sample
  colnames(mat) = sample_order$name
  
  # inspect
  table(top50genes_df$Variant.Type) %>% sort()
  
  
  alter_fun = list(
    background = function(x, y, w, h) 
      grid.rect(x, y, w*0.9, h*0.9, gp = gpar(fill = "#CCCCCC", col = NA)),
    
    #square
    SNV = function(x, y, w, h) 
      grid.rect(x, y, w*0.9, h*0.9, gp = gpar(fill = "#4DAC26", col = NA)),
    
    #half square
    INDEL = function(x, y, w, h) {
      grid.polygon(
        unit.c(x + 0.5*w, x + 0.5*w, x - 0.5*w), 
        unit.c(y + 0.5*h, y - 0.5*h, y + 0.5*h),
        gp = gpar(fill = '#D01C8B', col = "white"))
    },
    
    # dots
    MNV = function(x, y, w, h) 
      grid.points(x, y, pch = 16,
                  gp = gpar(fontsize = 8))
    #,
    # crossed lines
    # MNV = function(x, y, w, h) {
    #   grid.segments(x - w*0.4, y - h*0.4, x + w*0.4, y + h*0.4, 
    #                 gp = gpar(lwd = 2,col='black'))
    #   grid.segments(x + w*0.4, y - h*0.4, x - w*0.4, y + h*0.4, 
    #                 gp = gpar(lwd = 2,col='black'))
    # }
  )
  
  test_alter_fun(alter_fun)
  
  #column_title = paste("Top ",n," hotspot Mutation heatmap for M20-431 tumors",sep = '')
  heatmap_legend_param = list(title = "Alteration", 
                              at = c("INDEL", "SNV",
                                     "MNV"), 
                              labels = c("INDEL", "SNV",
                                         "MNV"),legend_direction = 'horizontal')
  
  # TMB <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch245_TMB.csv') %>%
  #   filter(name =='SNVs') %>% 
  #   merge(.,sample_order, by.x = 'Accession_number',by.y = 'Accession_Number') %>%
  #   merge(.,colData)
  # 
  ##match second vector to first vector
  # TMB <- TMB[match(sample_order$Accession_Number,TMB$Accession_number),]
  # identical(TMB$Accession_number,sample_order$Accession_Number)
  # 
  
  draw(oncoPrint(mat,
                 alter_fun = alter_fun, col = c(SNV = "#4DAC26", INDEL = "#D01C8B",MNV='black'), 
                 remove_empty_columns = F, remove_empty_rows = F,
                 pct_side = "right", row_names_side = "left",
                 column_title = column_title, 
                 #show_heatmap_legend=F,
                 row_names_gp = gpar(fontsize = 8.5),
                 column_names_gp = gpar(fontsize = 8.5),
                 show_column_names = T,
                 column_order = sample_order$name,
                 top_annotation = HeatmapAnnotation(
                   cbar = anno_oncoprint_barplot(),
                   # TMB = anno_points(TMB$value),
                   Treatment = sample_order$Treatment,
                   Diagnosis = sample_order$Diagnosis_edit,
                   BOR = sample_order$BOR,
                   simple_anno_size = unit(3, "mm"),
                   col = list(Treatment = c("Archival Pre" = "grey40","Fresh Pre" = 'grey', 
                                            "On-Treatment" = "orange"),
                              "BOR" = c("CR" = "red",
                                        "PD" = "grey60",
                                        "SD" = "green",
                                        'NE' = 'black',
                                        'PR' = 'purple')),
                   annotation_name_gp= gpar(fontsize = 8)),
                 left_annotation =  rowAnnotation(
                   rbar = anno_oncoprint_barplot(
                     axis_param = list(direction = "reverse"))),
                 right_annotation = NULL
  ),
  heatmap_legend_side = "left"
  )
  
}
## end of function


##4) top 20 mutated genes + mutations related to resistance to ICI

genes <- c('PBRM1','PTEN','TP53','BAP1','VHL')

df <- counts_somaticSNV_allVar

draw_oncoprint(f = df, genelist = genes,number_of_genes = NA)















