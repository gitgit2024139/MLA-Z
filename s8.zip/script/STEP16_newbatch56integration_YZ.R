library(tidyverse)
library(dplyr)
library(readxl)
library(data.table)
library(Biobase)
library(genefilter)
library(Rtsne)
library(ggplot2)
library(gridExtra)
library(pheatmap)
library(gplots)
library(limma)
library(RColorBrewer)
library(reshape)
library(GSVA)
library(quantiseqr)
library(ComplexHeatmap)
library(lessR)

### filter to retain SetB and 0817_TN data when having overlaps for tumor analysis

#1. filelsit

test124 <- read.table('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/filenames_124_250117.txt',sep = '\t')

test431 <- read.table('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/filenames_431_250117.txt',sep = '\t')

allS3file_tumors <- rbind(test124,test431) %>%
  separate(V1, into = c('v1','filepath'), sep = 'CloudDataRoot') %>% 
  mutate(filepath = paste('CloudDataRoot',filepath,sep = '')) %>%
  mutate(filetype = lapply(filepath, function(x) {tail(strsplit(x,split = '/')[[1]], 1)}
  ) %>% unlist(),
  suffix = lapply(filetype, function(x) {tail(strsplit(x,split = '\\.')[[1]], 1)}
  ) %>% unlist(),
  
  pipeline = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 1)}
  ) %>% unlist(),
  
  Accession_number = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 2)[2]}
  ) %>% unlist()
  )

#read clinical sample shiping manifest, get paired tumor samples
manifest <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/Batch5_6_data_inventory_yz_2025.xlsx', 
                               sheet = 1)%>% 
  mutate(Patient_ID = parse_number(Patient_ID))

manifest$Treatment[9] = 'On-Treatment'

colData <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/PTPN2_Clinical_Metadata_08AUG24_Final.xlsx',
                              sheet = 2) 

colData <- manifest %>% left_join(., colData %>% dplyr::rename('Patient_ID' = 'Subject_ID'))


#2. filter RNAseq files

matches_exp_report <- allS3file_tumors[grepl('rna_gene_expression_report', 
                                             allS3file_tumors$filetype),] %>%
  filter(suffix == 'xlsx', pipeline == 'RNA') 

##3 add metadata

final_list <- matches_exp_report %>% dplyr::select(filepath,filetype,Accession_number) %>% 
  merge(.,colData,by.x = 'Accession_number',by.y = 'Accession_number'  )  

final_list_edit <- final_list[order(final_list$Patient_ID, 
                                    final_list$Treatment),]

final_list_edit <- final_list_edit %>% mutate(
  batchset = str_extract(filepath, 'Batch\\d(_\\w+)') %>% 
    lapply(.,function(x) {head(strsplit(x, split = '_7')[[1]],1)[1]}) %>%
    unlist(),
  batchdate = str_extract(filepath, '\\d{4}_\\d{4}'),
  batchtotal = paste(batchset,batchdate,sep = '_')
)

test <- final_list_edit %>% group_by(Accession_number) %>% 
  reframe(occurrance = paste(sort(unique(batchtotal)),collapse = '; '))

final_list_edit <- final_list_edit %>% filter(batchtotal != 'Batch5_TO_0721_2024')

final_list_edit <- final_list_edit%>% 
  mutate(accession = paste(batchset,'_RNA_',Accession_number,sep = '')) %>%
  merge(.,data.frame(accession = colnames(counts[,-1])), by = 'accession')%>%
  arrange(Patient_ID,Treatment) %>%
  mutate(sample_lable = paste(Patient_ID, batchset, sep = '_'))

##save colData
write.csv(final_list_edit,'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch56_colData_250210.csv',row.names = F)

#write.csv(final_list_edit,'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_inDNApipeline_ForImage_0903.csv')
##4. download gene expression reports from s3 by print bash command lines and run command lines in terminal

for (i in 1: length(final_list_edit$filepath)) {
  
  s3_loc <- final_list_edit$filepath[i]
  filename <- paste(final_list_edit$batchset[i], final_list_edit$filetype[i],sep = '_')
  
  cmd <- paste('aws s3 cp s3://abv-arrayserver/', s3_loc, 
               ' --profile abbvie-omic-prod /ui/abv/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorRNAexp_batch56/', 
               filename,sep = '')
  
  write(cmd,file = '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/bash_cp_cmd_RNA_batch56.sh', append = T)
  
}

##5. downlaod files from s3 to HPC from command line

##7. rbind neoantigen files
files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorRNAexp_batch56/',
                    pattern = 'xlsx',
                    full.names = T)

names(files) <- stringr::str_split(basename(files), pattern = '_tumor',simplify = T)[,1]

counts <- purrr::map_df(files, .f = read_excel, .id = "sample")

##counts
counts <- purrr::map_df(files, .f = read_excel, .id = "sample") %>% select(1:4) %>%
  tidyr::pivot_wider(names_from = 1, values_from = 4 )

write.csv(counts, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch56_counts_250210.csv',
          row.names = F)
##tpm
tpm <- purrr::map_df(files, .f = read_excel, .id = "sample") %>% select(1:3,7) %>%
  tidyr::pivot_wider(names_from = 1, values_from = 4 )

write.csv(tpm, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch56_TPM_250210.csv',
          row.names = F)

