library(tidyverse)
library(dplyr)
library(readxl)
library(data.table)
library(Biobase)
library(genefilter)
library(Rtsne)
library(ggplot2)
library(gridExtra)
library(pheatmap)
library(gplots)
library(limma)
library(RColorBrewer)
library(reshape)
library(GSVA)
library(ComplexHeatmap)
library(lessR)

### filter to retain SetB and 0817_TN data when having overlaps for tumor analysis

#1. filelsit
allS3file_tumors <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/allS3files_0827.csv')

#read clinical sample shiping manifest, get paired tumor samples
manifest <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/M20_431_and_M20_124_Personalis_Shipment_Summary_6Aug2024_yz_mj.xlsx', 
                               sheet = 3)%>% 
  filter(Batch_Type != 'Gene Expression') %>% ##remove blood samples
  mutate(Accession_number = Accession_Number) %>%
  mutate(Accession_number = ifelse(nchar(Accession_number)==12,
                                   str_sub(Accession_number, end = -3),
                                   Accession_number)) %>% 
  #filter(Cohort =='M20-431') %>% page 3 is M20-431 only
  filter(Mosaic_ID != 'N/A') %>%
  mutate(Accession_Number = parse_number(Accession_number)) %>% 
  dplyr::select(-Annotation)

colData <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/PTPN2_Clinical_Metadata_08AUG24_Final.xlsx',
                              sheet = 2) 

colData <- manifest %>% left_join(., colData %>% dplyr::rename('Patient_ID' = 'Subject_ID'))

#2. filter wes files

matches_wes_report <- allS3file_tumors[grepl('somatic_dna_gene_cna_report', 
                                             allS3file_tumors$filetype),] %>%
  filter(suffix == 'xlsx',pipeline == 'DNA')

##3 add metadata

final_list <- matches_wes_report %>% dplyr::select(filepath,filetype,Accession_number) %>% 
  merge(.,colData,by.x = 'Accession_number',by.y = 'Accession_number'  )  %>% 
  filter(Mosaic_ID != 'N/A')

final_list_edit <- final_list[order(final_list$Patient_ID, 
                                    final_list$Treatment),]

final_list_edit <- final_list_edit %>% mutate(
  batchset = str_extract(filepath, 'Batch\\d(_\\w+)') %>% 
    lapply(.,function(x) {head(strsplit(x, split = '_7')[[1]],1)[1]}) %>%
    unlist(),
  batchdate = str_extract(filepath, '\\d{4}_\\d{4}'),
  batchtotal = paste(batchset,batchdate,sep = '_')
)

test <- final_list_edit %>% group_by(Accession_number) %>% 
  reframe(occurrance = paste(sort(unique(batchtotal)),collapse = '; '))

final_list_edit <- final_list_edit[grepl(paste(c('Batch2_Set_A__0812_2024',
                                                 'Batch2_SetB_0807_2024',
                                                 'Batch2_SetB_0809_2024', 
                                                 'Batch4_0711_2024',
                                                 'Batch5_TN_0816_2024',
                                                 'Batch2_Set_A__0812_2024'),collapse = '|'), 
                                         final_list_edit$batchtotal),]

#write.csv(final_list_edit,'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_inDNApipeline_ForImage_0903.csv')
##4. download gene expression reports from s3 by print bash command lines and run command lines in terminal

for (i in 1: length(final_list_edit$filepath)) {
  
  s3_loc <- final_list_edit$filepath[i]
  filename <- paste(final_list_edit$batchset[i], final_list_edit$filetype[i],sep = '_')
  Patient_ID <- final_list_edit$Patient_ID[i]
  
  ## total 41 tumors
  cmd <- paste('aws s3 cp s3://abv-arrayserver/', s3_loc, 
               ' --profile arrayserver /ui/abv/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorDNAcnv/', 
               filename,sep = '')
  
  write(cmd,file = '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/bash_cp_cmd_dna_cnv_xlsx.sh', append = T)
  
  ## 6 pairs
  if (Patient_ID %in% c( '2203','2204','2207','2209','2501','2801')) {
    cmd <- paste('aws s3 cp s3://abv-arrayserver/', s3_loc, 
                 ' --profile arrayserver /ui/abv/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorDNAcnv/', 
                 filename,sep = '')
    
    write(cmd,file = '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/bash_cp_cmd_dna_cnv_6pairs.sh', append = T)
  }
}

##5. downlaod files from s3 to HPC from command line

#### Check if files have content before bind
# has_content <- function(filename) {
#   con <- file(filename, "r")
#   num_lines <- length(readLines(con, n = 2))
#   close(con)
#   return(num_lines > 1)
# }
# 
# read_batch <- function(input) {
#   fread(input, colClasses=c("Chromosome"="character"))
# }
# 
# files <- Filter(has_content, files)

####

##7. rbind cnv files
files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorDNAcnv',
                    #pattern = 'tsv',
                    full.names = T)


names(files) <- stringr::str_split(basename(files), pattern = '.xlsx',simplify = T)[,1]

counts <- purrr::map_df(files, .f = read_excel, .id = "sample",)

write.csv(counts, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_2501onlyCNV.csv',
          row.names = F)

###############################################################################################
#1. CNV proportion
###############################################################################################

#counts <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_tumorSNV_0827.csv')
counts_cnv<- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_2501onlyCNV.csv')
colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch245_colData_0903.csv')

##Making diagnosis a little easier to work around from Kyle's code 20240912
colData$Diagnosis_edit <- colData$Diagnosis
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Breast Cancer (TNBC)", "Breast Cancer"))] <- "Breast"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("TNBC"))] <- "Breast"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Sigmoid colon cancer"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Adenocarcinoma of rectum", "Colon Cancer", "Colorectal Cancer"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Rectal Adenocarcinoma"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("MSI-H CRC"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("MSS CRC"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Malignant neoplasma of tonsil (HNSCC)"))] <- "HNSCC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Pancreatic Cancer"))] <- "Pancreatic"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Malignant Melanoma", "Melanoma"))] <- "Melanoma"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Soft Tissue Sarcoma", "Anaplastic Soft Tissue Sarcoma",
                                                          "Sarcoma", "Retropertioneal Synovial Sarcoma", "Chondrosarcoma",
                                                          "Clear Cell Sarcoma", "Myxoid Liposarcoma"))] <- "Sarcoma"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Urethral", "Urothelial Carcinoma"))] <- "Urothelial"
otherTmrs <- names(which(table(colData$Diagnosis_edit) <= 2))
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% otherTmrs)] <- "Other"

#working table

counts_cnv<- counts_cnv %>%
                     mutate(Accession_number = str_extract(sample,'\\d{10}') %>%
                              parse_number(.))

counts_cnv <- left_join(counts_cnv,colData,by = 'Accession_number') 

## top 10 CNV from TCGA RCC 

genes <- c('BTNL8','DOC3','FGFR4','CREBRF','PRELID1','NSD1','TMED9','DUSP1')

counts_cnv_gene <- counts_cnv %>% filter(Gene.Symbol %in% genes)
## no overlap

