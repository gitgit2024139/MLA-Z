library(tidyverse)
library(dplyr)
library(readxl)
library(data.table)
library(Biobase)
library(genefilter)
library(Rtsne)
library(ggplot2)
library(gridExtra)
library(pheatmap)
library(gplots)
library(limma)
library(RColorBrewer)
library(reshape)
library(GSVA)
library(quantiseqr)
library(ComplexHeatmap)
library(lessR)

#1. filelsit

test124 <- read.table('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/filenames_124_250117.txt',sep = '\t')

test431 <- read.table('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/filenames_431_250117.txt',sep = '\t')

allS3file_tumors <- rbind(test124,test431) %>%
  separate(V1, into = c('v1','filepath'), sep = 'CloudDataRoot') %>% 
  mutate(filepath = paste('CloudDataRoot',filepath,sep = '')) %>%
  mutate(filetype = basename(filepath),
  suffix = lapply(filetype, function(x) {tail(strsplit(x,split = '\\.')[[1]], 1)}
  ) %>% unlist()) %>% 
  
  filter(suffix %in% c('tsv','txt','xlsx')) %>% 
  
  mutate(pipeline = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 1)}
  ) %>% unlist(),
  
  Accession_number = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 2)[2]}
  ) %>% unlist()
  )

#read clinical sample shiping manifest, get paired tumor samples
## batch 5 and 6 MANIFEST has no blood sample, delete
## BATCH 1-4 MANIFEST, only retain blood sample shipment
manifest <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/M20_431_and_M20_124_Personalis_Shipment_Summary_6Aug2024_yz_mj.xlsx', 
                               sheet = 4)%>% 
  filter(Batch_Type == 'Gene Expression') %>% ##retain blood samples
  mutate(Accession_number = Accession_Number) %>%
  mutate(Accession_number = ifelse(nchar(Accession_number)==12,
                                   str_sub(Accession_number, end = -3),
                                   Accession_number)) %>% 
  #filter(Cohort =='M20-431') %>% page 3 is M20-431 only
  #filter(Mosaic_ID != 'N/A') %>%
  mutate(Accession_Number = parse_number(Accession_number)) %>% 
  dplyr::select(-Annotation) %>% 
  dplyr::select(Batch_number, Batch_Type, Visit,Cohort,Patient_ID, Accession_number, Treatment,Mosaic_ID)

colnames(manifest) <- c('Batch','Batch_Type','Visit','Study','Subject_ID','Accession_number','Treatment','Mosaic_ID')

# use updated 2025 clinical data

colData_1 <- read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/PTPN2-Clinical Metadata_18JUN25_PN.xlsx',
                          sheet = 1) %>% mutate(Study = 'M20-124')
colData_2 <- read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/PTPN2-Clinical Metadata_18JUN25_PN.xlsx',
                        sheet = 2) %>% mutate(Study = 'M20-431')
setdiff(colnames(colData_2),colnames(colData_1))

colData_1_4 <- rbind(colData_1, colData_2)

colnames(colData_1_4)[1] <- 'Subject_ID'

colData_1_4 <- manifest %>% right_join(., colData_1_4 %>% mutate(Subject_ID = as.character(Subject_ID)) )

colData_1_4_total <- unique(colData_1_4)

write.csv(colData_1_4_total, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/coldata_1_4_total_bloodforgermline.csv', row.names = F)


#2. filter rna expressoin and transcript expression files
#filter report
final_list_edit <- allS3file_tumors[grepl(paste(c('rna_gene_expression_report.tsv','rna_transcript_expression_report.tsv'
                                                  ),collapse = '|'),
                                          allS3file_tumors$filetype),]  
##batchset
final_list_edit <- final_list_edit %>% mutate(
  batchset = str_extract(filepath, '[Bb]atch\\d(_\\w+)') %>% 
    lapply(.,function(x) {head(strsplit(x, split = '_7')[[1]],1)[1]}) %>%
    unlist(),
  batchdate = str_extract(filepath, '\\d{4}_\\d{4}'),
  batchtotal = paste(batchset,batchdate,sep = '_'),
  modality = str_extract_all(filetype, paste('gene','transcript',sep = '|'))
)

# remove repeated files
test <- final_list_edit %>% group_by(Accession_number,modality) %>% 
  reframe(occurrance = paste(sort(unique(batchtotal)),collapse = ';')) %>% 
  mutate(final_segment = str_extract(occurrance , '[^;]+$'))

final_list_edit <- final_list_edit %>% filter(batchtotal %in% test$final_segment)

test <- final_list_edit %>% group_by(Accession_number#,modality
                                     ) %>% 
  reframe(occurrance = paste(sort(unique(batchtotal)),collapse = '; '))

##3 add metadata

final_list <- final_list_edit %>% left_join(.,colData_1_4_total,by = 'Accession_number')  

final_list <- final_list %>% filter(!duplicated(filetype))

## full manifest doesn't have treatment info
final_list_edit <- final_list[order(final_list$Subject_ID
                                    #final_list$Treatment. #full manifest doesn't have treatment info
),] %>% filter(Batch_Type == 'Gene Expression')

final_list_edit <- apply(final_list_edit,2,as.character)

##save colData
write.csv(final_list_edit,'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/blood_batch1_4_forGermline_20250718.csv',row.names = F)

##4. download gene expression reports from s3 by print bash command lines and run command lines in terminal

for (i in 1: length(final_list_edit$filepath)) {
  
  s3_loc <- final_list_edit$filepath[i]
  filename <- paste(final_list_edit$batchset[i], final_list_edit$filetype[i],sep = '_')
  
  cmd <- paste('aws s3 cp s3://abv-arrayserver/', s3_loc, 
               ' --profile abbvie-omic-prod /homes/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_bloodRNA_for_germline/', 
               filename,sep = '') 
  ## /homes/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data is the location on aurora, not on magnus
  
  write(cmd,file = '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/bash_cp_cmd_bloodRNA_for_germline.sh', append = T)
  
}

##5. make expression mtrx for gene

files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_bloodRNA_for_germline/',
                    #pattern = 'somatic_dna_small_variant_report_preferred',
                    pattern = 'gene',
                    full.names = T)

names(files) <- stringr::str_split(basename(files), pattern = '_expression',simplify = T)[,1]

test <- data.frame(sample = names(files)) %>% 
  mutate(Accession_number = str_extract(sample, '\\d{10}'),
         batchset = str_split(sample, pattern = paste(c('_RNA','_DNA'), collapse = '|'), simplify = T)[,1]) 

##counts
counts <- purrr::map_df(files, .f = fread, .id = "sample") %>% select(1:4) %>%
  tidyr::pivot_wider(names_from = 1, values_from = 4 )

write.csv(counts, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/blood_batch1_4_counts_forgermline_250718.csv',
          row.names = F)
##tpm
tpm <- purrr::map_df(files, .f = fread, .id = "sample") %>% select(1:3,7) %>%
  tidyr::pivot_wider(names_from = 1, values_from = 4 )

write.csv(tpm, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/blood_batch1_4_TPM_forgermline_250718.csv',
          row.names = F)


##6. make expression mtrx for transcript

files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_bloodRNA_for_germline/',
                    #pattern = 'somatic_dna_small_variant_report_preferred',
                    pattern = 'transcript',
                    full.names = T)

names(files) <- stringr::str_split(basename(files), pattern = '_expression',simplify = T)[,1]

test <- data.frame(sample = names(files)) %>% 
  mutate(Accession_number = str_extract(sample, '\\d{10}'),
         batchset = str_split(sample, pattern = paste(c('_RNA','_DNA'), collapse = '|'), simplify = T)[,1]) 

##counts
counts <- purrr::map_df(files, .f = fread, .id = "sample") %>% select(1:4,7) %>%
  tidyr::pivot_wider(names_from = 1, values_from = 5 )

write.csv(counts, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/blood_batch1_4_Transcript_counts_forgermline_250718.csv',
          row.names = F)
##tpm
tpm <- purrr::map_df(files, .f = fread, .id = "sample") %>% select(1:4,8) %>%
  tidyr::pivot_wider(names_from = 1, values_from = 5 )

write.csv(tpm, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/blood_batch1_4_Transcript_TPM_forgermline_250718.csv',
          row.names = F)


##########################################################################################################
##### 7. tracking down the archival molecular data
##########################################################################################################

#1. filelsit

illumina124 <- read.table('~/PTPN2i/filenames_124_archives_illumina.txt',sep = '\t')
illumina431 <- read.table('~/PTPN2i/filenames_431_archives_illumina.txt',sep = '\t')

allilluminafile_tumors <- rbind(illumina124,illumina431) %>%
  
  separate(V1, into = c('v1','filepath'), sep = '000000_tmp_personalis') %>% 
  
  mutate(filepath = paste('/Resources/Archives/Illumina/Raw_Data/ILLUMINA_Data_Received/000000_tmp_personalis',filepath,sep = '')) %>%
  
  mutate(filetype = basename(filepath),
         
  suffix = lapply(filetype, function(x) {tail(strsplit(x,split = '\\.')[[1]], 1)}
  ) %>% unlist()) %>% 
  
  filter(suffix %in% c('tsv','txt','xlsx')) %>% 
  
  mutate( pipeline = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 1)}
  ) %>% unlist(),
  
  Patient_ID_mix = str_extract(filetype, '\\d{5}'),
  
  Mosaic_ID = str_extract(filetype, 'ML\\d+'),
  
  Accession_number_original = str_extract(filetype, '\\d{10}'),
  
  Accession_number = ifelse(nchar(Accession_number_original)==12,
                            str_sub(Accession_number_original, end = -3),
                            Accession_number_original) ,
  
  ) %>% 
  
  filter(pipeline %in% c('DNA','RNA'))

#read clinical sample shiping manifest, get paired tumor samples
## BATCH 1-4 MANIFEST
colData_1_4_total <- read_csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/coldata_1_4_total_bloodforgermline.csv')

#2. filter dna_statistics files

#filter report
final_list_edit <- allilluminafile_tumors[grepl(paste(c('rna_gene_expression_report.tsv',
                                                        'rna_transcript_expression_report.tsv'),
                                                      collapse = '|'),
                                          allilluminafile_tumors$filetype),]  

##batchset
final_list_edit <- final_list_edit %>% mutate(
  batchset = str_extract(filepath, '[Bb]atch\\d(_\\w+)') %>% 
    lapply(.,function(x) {head(strsplit(x, split = '_7')[[1]],1)[1]}) %>%
    unlist(),
  batchdate = str_extract(filepath, '\\d{4}_\\d{4}'),
  batchtotal = paste(batchset,batchdate,sep = '_'),
  modality = str_extract_all(filetype, paste('gene','transcript',sep = '|'))
)

# remove repeated files
test <- final_list_edit %>% group_by(Patient_ID_mix, Mosaic_ID, Accession_number,modality) %>% 
  reframe(occurrance = paste(sort(unique(batchtotal)),collapse = ';')) %>% 
  mutate(final_segment = str_extract(occurrance , '[^;]+$'))

final_list_edit <- final_list_edit %>% filter(batchtotal %in% test$final_segment)

test <- final_list_edit %>% group_by(Patient_ID_mix, Mosaic_ID, 
                                     Accession_number,modality) %>% 
  reframe(occurrance = paste(sort(unique(batchtotal)),collapse = '; '))

##3 add metadata
## only look ones having accession number
final_list_1 <- final_list_edit %>% filter(!(is.na(Accession_number))) %>% 
  left_join(.,colData_1_4_total %>% 
              mutate(Accession_number = as.character(Accession_number)),
            by = 'Accession_number')  

final_list_2 <- final_list_edit %>% filter(is.na(Accession_number)) %>% 
  mutate(Subject_ID = Patient_ID_mix) %>% select(-Accession_number)%>% 
  left_join(.,colData_1_4_total %>% 
              mutate(Subject_ID = as.character(Subject_ID)),
            by = 'Subject_ID')  

final_list <- rbind(final_list_1,final_list_2) %>% filter(!duplicated(filetype),Batch_Type == 'Gene Expression')

## full manifest doesn't have treatment info
final_list_edit <- final_list[order(final_list$Subject_ID
                                    #final_list$Treatment. #full manifest doesn't have treatment info
),]

final_list_edit <- apply(final_list_edit,2,as.character)

##save colData
write.csv(final_list_edit,'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/blood_illumina_forGermline_20250718.csv',row.names = F)

##4. download gene expression reports from s3 by print bash command lines and run command lines in terminal
## need to ssh to zhanyx3@ord-docker02 for illumina archival datta

for (i in 1: length(final_list_edit$filepath)) {
  s3_loc <- final_list_edit$filepath[i]
  filename <- paste(final_list_edit$batchset[i], final_list_edit$filetype[i],sep = '_')
  
  cmd <- paste(#'aws s3 
    'cp ', 
    s3_loc, 
    ' /homes/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_bloodRNA_for_germline_illumina/', 
    filename,sep = '') 
  
  
  write(cmd,file = '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/bash_cp_cmd_bloodRNA_for_germline_illumina.sh', append = T)
  
}

##5. make expression mtrx for gene

files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_bloodRNA_for_germline_illumina/',
                    #pattern = 'somatic_dna_small_variant_report_preferred',
                    pattern = 'gene',
                    full.names = T)

names(files) <- stringr::str_split(basename(files), pattern = '_expression',simplify = T)[,1]

test <- data.frame(sample = names(files)) %>% 
  mutate(Accession_number = str_extract(sample, '\\d{10}'),
         batchset = str_split(sample, pattern = paste(c('_RNA','_DNA'), collapse = '|'), simplify = T)[,1]) 

##counts
counts <- purrr::map_df(files, .f = fread, .id = "sample") %>% select(1:4) %>%
  tidyr::pivot_wider(names_from = 1, values_from = 4 )

write.csv(counts, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/blood_illumina_counts_forgermline_250718.csv',
          row.names = F)
##tpm
tpm <- purrr::map_df(files, .f = fread, .id = "sample") %>% select(1:3,7) %>%
  tidyr::pivot_wider(names_from = 1, values_from = 4 )

write.csv(tpm, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/blood_illumina_TPM_forgermline_250718.csv',
          row.names = F)

##6. make expression mtrx for transcript

files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_bloodRNA_for_germline_illumina/',
                    #pattern = 'somatic_dna_small_variant_report_preferred',
                    pattern = 'transcript',
                    full.names = T)

names(files) <- stringr::str_split(basename(files), pattern = '_expression',simplify = T)[,1]

test <- data.frame(sample = names(files)) %>% 
  mutate(Accession_number = str_extract(sample, '\\d{10}'),
         batchset = str_split(sample, pattern = paste(c('_RNA','_DNA'), collapse = '|'), simplify = T)[,1]) 

##counts
counts <- purrr::map_df(files, .f = fread, .id = "sample") %>% select(1:4,7) %>%
  tidyr::pivot_wider(names_from = 1, values_from = 5 )

write.csv(counts, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/blood_illumina_Transcript_counts_forgermline_250718.csv',
          row.names = F)
##tpm
tpm <- purrr::map_df(files, .f = fread, .id = "sample") %>% select(1:4,8) %>%
  tidyr::pivot_wider(names_from = 1, values_from = 5 )

write.csv(tpm, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/blood_illumina_Transcript_TPM_forgermline_250718.csv',
          row.names = F)

### 20250721
# check blood samples in 2 locations for overlapping

batch1_4 <- read_csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/blood_batch1_4_forGermline_20250718.csv') %>% 
  filter(modality == 'gene') 

illumina <- fread('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/blood_illumina_forGermline_20250718.csv') %>% 
  filter(modality == 'gene') 

## overlap, no overlapping samples
length(intersect(batch1_4$Accession_number, illumina$Accession_number))

table(batch1_4$Study)

SNP <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/250630_Ptpn2_germline_clinical_annotation_02_sw.csv')

batch1_4_snp <- SNP %>% mutate(Subject_ID = SampleID) %>% 
  left_join(.,batch1_4 %>% mutate(Subject_ID = as.character(Subject_ID))) %>%
  filter(!is.na(filetype))

table(batch1_4_snp$suffix)

write.csv(batch1_4_snp %>% select(1:9,12,22),'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/blood_exp_snps_metadata1.csv',row.names = F)

illumina_snp <- SNP %>% mutate(Subject_ID = SampleID) %>% 
  left_join(.,illumina %>% mutate(Subject_ID = as.character(Subject_ID))) %>% 
  filter(!is.na(filetype))

table(illumina_snp$suffix)

write.csv(illumina_snp %>% select(1:9,12,25),'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/blood_exp_snps_metadata2.csv',row.names = F)

## select EXP data from the pool of batch1_4 files

batch1_4_snp_exp <- fread('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/blood_batch1_4_TPM_forgermline_250718.csv')

keep <- paste(batch1_4_snp$batchset, 
              stringr::str_split(batch1_4_snp$filetype, pattern = '_expression',simplify = T)[,1],
              sep = '_')

batch1_4_snp_exp <- batch1_4_snp_exp %>% select(1:2, keep)

keep_name <- c(colnames(batch1_4_snp_exp)[1:2],str_extract(colnames(batch1_4_snp_exp)[-c(1:2)],'\\d{10}'))

colnames(batch1_4_snp_exp) <- keep_name

write.csv(batch1_4_snp_exp, 
          '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/blood_batch1_4_TPM_forgermlineStephen_250722.csv',row.names = F)

## select EXP data from the pool of illumina files

illumina_snp_exp <- fread('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/blood_illumina_TPM_forgermline_250718.csv')

keep <- paste(illumina_snp$batchset, 
              stringr::str_split(illumina_snp$filetype, pattern = '_expression',simplify = T)[,1],
              sep = '_')

illumina_snp_exp <- illumina_snp_exp %>% select(1:2, keep)

keep_name <- c(colnames(illumina_snp_exp)[1:2],str_extract(colnames(illumina_snp_exp)[-c(1:2)],'\\d{10}'))

colnames(illumina_snp_exp) <- keep_name

write.csv(illumina_snp_exp, 
          '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/blood_illumina_TPM_forgermlineStephen_250722.csv',row.names = F)



