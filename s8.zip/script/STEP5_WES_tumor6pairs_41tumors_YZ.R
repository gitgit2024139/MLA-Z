library(tidyverse)
library(dplyr)
library(readxl)
library(data.table)
library(Biobase)
library(genefilter)
library(Rtsne)
library(ggplot2)
library(gridExtra)
library(pheatmap)
library(gplots)
library(limma)
library(RColorBrewer)
library(reshape)
library(GSVA)
library(quantiseqr)
library(ComplexHeatmap)
library(lessR)

### filter to retain SetB and 0817_TN data when having overlaps for tumor analysis

#1. filelsit
allS3file_tumors <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/allS3files_0827.csv')

#read clinical sample shiping manifest, get paired tumor samples
manifest <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/M20_431_and_M20_124_Personalis_Shipment_Summary_6Aug2024_yz_mj.xlsx', 
                               sheet = 3)%>% 
  filter(Batch_Type != 'Gene Expression') %>% ##remove blood samples
  mutate(Accession_number = Accession_Number) %>%
  mutate(Accession_number = ifelse(nchar(Accession_number)==12,
                                   str_sub(Accession_number, end = -3),
                                   Accession_number)) %>% 
  #filter(Cohort =='M20-431') %>% page 3 is M20-431 only
  filter(Mosaic_ID != 'N/A') %>%
  mutate(Accession_Number = parse_number(Accession_number)) %>% 
  dplyr::select(-Annotation)

colData <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/PTPN2_Clinical_Metadata_08AUG24_Final.xlsx',
                              sheet = 2) 

colData <- manifest %>% left_join(., colData %>% dplyr::rename('Patient_ID' = 'Subject_ID'))

write.csv(colData, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch245_colData_0903.csv',row.names = F)

#2. filter wes files

matches_wes_report <- allS3file_tumors[grepl('somatic_dna_small_variant_report_preferred', 
                                             allS3file_tumors$filetype),] %>%
  filter(suffix == 'xlsx',pipeline == 'DNA')

##3 add metadata

final_list <- matches_wes_report %>% dplyr::select(filepath,filetype,Accession_number) %>% 
  merge(.,colData,by.x = 'Accession_number',by.y = 'Accession_number'  )  %>% 
  filter(Mosaic_ID != 'N/A')

final_list_edit <- final_list[order(final_list$Patient_ID, 
                                    final_list$Treatment),]

final_list_edit <- final_list_edit %>% mutate(
  batchset = str_extract(filepath, 'Batch\\d(_\\w+)') %>% 
    lapply(.,function(x) {head(strsplit(x, split = '_7')[[1]],1)[1]}) %>%
    unlist(),
  batchdate = str_extract(filepath, '\\d{4}_\\d{4}'),
  batchtotal = paste(batchset,batchdate,sep = '_')
)

test <- final_list_edit %>% group_by(Accession_number) %>% 
  reframe(occurrance = paste(sort(unique(batchtotal)),collapse = '; '))

final_list_edit <- final_list_edit[grepl(paste(c('Batch2_Set_A__0812_2024',
                                                 'Batch2_SetB_0807_2024',
                                                 'Batch2_SetB_0809_2024', 
                                                 'Batch4_0711_2024',
                                                 'Batch5_TN_0816_2024',
                                                 'Batch2_Set_A__0812_2024'),collapse = '|'), 
                                         final_list_edit$batchtotal),]

write.csv(final_list_edit,'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_inDNApipeline_ForImage_0903.csv')
##4. download gene expression reports from s3 by print bash command lines and run command lines in terminal

for (i in 1: length(final_list_edit$filepath)) {
  
  s3_loc <- final_list_edit$filepath[i]
  filename <- paste(final_list_edit$batchset[i], final_list_edit$filetype[i],sep = '_')
  
  cmd <- paste('aws s3 cp s3://abv-arrayserver/', s3_loc, 
               ' --profile arrayserver /ui/abv/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorDNAmut/', 
               filename,sep = '')
  
  write(cmd,file = '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/bash_cp_cmd_dna.sh', append = T)
  
}

##5. downlaod files from s3 to HPC from command line

# ##6. chekcing 7 accession number missing from final download s3 location
# ## personalis summary files
# 
# files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/Personalis_batchsummary',
#                     pattern = paste(c('Batch1','Batch3'),collapse = '|'),
#                     full.names = T)
# 
# names(files) <- stringr::str_split(basename(files), pattern = '_ProjectSummary',simplify = T)[,1]
# counts_13 <- purrr::map_df(files, function(x) {read_excel(x,col_names = LETTERS[1:9],skip = 1)}, .id = "sample")
# 
# ##counts
# files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/Personalis_batchsummary',
#                     pattern = paste(c('Batch2','Batch4','Batch5'),collapse = '|'),
#                     full.names = T)
# 
# names(files) <- stringr::str_split(basename(files), pattern = '_ProjectSummary',simplify = T)[,1]
# counts_245 <- purrr::map_df(files, .f = read_excel, .id = "sample")

# write.csv(counts, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_somaticSNV_0827.csv',
#           row.names = F)

##7. rbind snv files
files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorDNAmut',
                    pattern = 'xlsx',
                    full.names = T)

names(files) <- stringr::str_split(basename(files), pattern = '_somatic_dna',simplify = T)[,1]

counts <- purrr::map_df(files, .f = read_excel, .id = "sample")


write.csv(counts, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_tumorSNV_0827.csv',
          row.names = F)

###############################################################################################
#1. somatic mutation proportion
###############################################################################################
#tumorSNV, somaticSNV

#counts <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_tumorSNV_0827.csv')
counts_somatic <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_6pairs_tumorSNV_0827.csv')
colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch245_colData_0903.csv')

##Making diagnosis a little easier to work around from Kyle's code 20240912
colData$Diagnosis_edit <- colData$Diagnosis
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Breast Cancer (TNBC)", "Breast Cancer"))] <- "Breast"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("TNBC"))] <- "Breast"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Sigmoid colon cancer"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Adenocarcinoma of rectum", "Colon Cancer", "Colorectal Cancer"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Rectal Adenocarcinoma"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("MSI-H CRC"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("MSS CRC"))] <- "CRC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Malignant neoplasma of tonsil (HNSCC)"))] <- "HNSCC"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Pancreatic Cancer"))] <- "Pancreatic"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Malignant Melanoma", "Melanoma"))] <- "Melanoma"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Soft Tissue Sarcoma", "Anaplastic Soft Tissue Sarcoma",
                                                          "Sarcoma", "Retropertioneal Synovial Sarcoma", "Chondrosarcoma",
                                                          "Clear Cell Sarcoma", "Myxoid Liposarcoma"))] <- "Sarcoma"
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% c("Urethral", "Urothelial Carcinoma"))] <- "Urothelial"
otherTmrs <- names(which(table(colData$Diagnosis_edit) <= 2))
colData$Diagnosis_edit[ which(colData$Diagnosis_edit %in% otherTmrs)] <- "Other"

#working table
##somatic SNV

counts_somatic <- counts_somatic %>%
                     mutate(Accession_number = str_extract(sample,'\\d{10}') %>%
                              parse_number(.))

## all variants including intronic/synonymous
counts_somaticSNV_allVar <- left_join(counts_somatic,colData,by = 'Accession_number') %>% 
  #filter(Transcript.Biotype == 'protein-coding') %>%
  separate(col = Variant.Effect,into = c('Variant.Effect'),sep = '\\+',extra = 'drop')

##1. A Pie chart showing proportions and genomic localization of the identified variants after filtering 

# Compute the position of labels
#color brewer hex name
# display.brewer.all()
# col1 = brewer.pal(n = 8, name = "Dark2")
# col2 = brewer.pal(n=12,name = 'Paired')

# library(lessR) #donut chart
# data <- rd("Employee")
# PieChart(Dept, data = data,
#          main = NULL)
# pc(Dept, data = data,
#    main = NULL)

counts_somaticSNV_allVar <- counts_somaticSNV_allVar %>% 
  mutate(Variant.Effect = ifelse(Variant.Effect == '3_prime_UTR_variant','3_prime_UTR',Variant.Effect)) %>%
  mutate(Variant.Effect = ifelse(Variant.Effect %in% c('5_prime_UTR_variant','5_prime_UTR_premature_start_codon_gain_variant')
                                 ,'5_prime_UTR',Variant.Effect)) %>%
  mutate(Variant.Effect = ifelse(Variant.Effect == 'downstream_gene_variant','downstream',Variant.Effect)) %>%
  mutate(Variant.Effect = ifelse(Variant.Effect == 'upstream_gene_variant','upstream',Variant.Effect)) %>%
  mutate(Variant.Effect = ifelse(Variant.Effect == 'exon_variant','exonic',Variant.Effect)) %>%
  mutate(Variant.Effect = ifelse(Variant.Effect == 'intron_variant','intronic',Variant.Effect)) %>%
  mutate(Variant.Effect = ifelse(Variant.Effect == '3_prime_UTR_variant','3_prime_UTR',Variant.Effect)) %>%
  mutate(Variant.Effect = ifelse(Variant.Effect %in% c('splice_acceptor_variant','splice_donor_variant','splice_region_variant'),
                                  'splicing', Variant.Effect)) %>%
  mutate(Variant.Effect = ifelse(Variant.Effect == 'frameshift_variant','frameshift',Variant.Effect)) %>%
  mutate(Variant.Effect = ifelse(Variant.Effect == 'initiator_codon_variant','initiator codon',Variant.Effect)) %>%
  mutate(Variant.Effect = ifelse(Variant.Effect == 'synonymous_variant','synonymous',Variant.Effect)) %>%
  mutate(Variant.Effect = ifelse(Variant.Effect == 'missense_variant','missense',Variant.Effect)) %>%
  mutate(Variant.Effect = ifelse(Variant.Effect %in% c('inframe_deletion','inframe_insertion'),
                                 'inframe', Variant.Effect))
  
 #all 
pc(Variant.Effect, data = counts_somaticSNV_allVar, main = NULL)
 
#protein coding
counts_somaticSNV_protcode = counts_somaticSNV_allVar %>% 
  filter(Transcript.Biotype == 'protein-coding')

pc(Variant.Effect, data = counts_somaticSNV_protcode, main = NULL)


#2. Preparing the input for oncoPrint for hotspot top 50 mutations
# We will now create a gene by patient matrix whose entries will indicate whether a certain gene is mutated (“MUT” entry) in a sample or not (“” as entry). 
#As explained in their vignette, oncoPrint can visualize more than one type of alteration for each gene. 
#For simplicity, we will plot a heatmap that contains only one type of mutation. Further, there are two options to represent the 
#input for oncoPrint - have a look into the vignette and see which one is more intuitive for you.

########################################################################################################################################
## function to draw the oncoplot
draw_oncoprint <- function(f,number_of_genes = n, genelist = x) {
  
  unique_genes_sample <- f %>% 
    filter(!is.na(Transcript.Biotype))%>% 
    group_by(Gene.Symbol) %>%
    reframe(Variant.Type = paste(unique(Variant.Type) %>% sort, collapse = ';') , 
            occurrance = n(),
            nsample = length(unique(sample)))
  
  # select the top 10 most mutated genes
  
  if (!is.na(number_of_genes)) {
    
    n = number_of_genes
    
    top50genes_df <- unique_genes_sample %>% arrange(-occurrance) %>%
      slice_head(n = n)
    
    column_title = paste("Top ",n," hotspot Mutation heatmap for M20-431 tumors",sep = '')
    
  } else {
    
     x = genelist
     
    # select the top 10 most mutated genes
    top50genes_df <- unique_genes_sample %>% 
      filter(Gene.Symbol %in% x)
    
    n = length(top50genes_df$Gene.Symbol)
    
    column_title = paste("PTPN2-JAK-STAT pathway Mutation heatmap for M20-431 tumors",sep = '')
    
  }
   
  table(top50genes_df$Variant.Type) %>% sort()
  
  top50genes <- top50genes_df %>% pull(Gene.Symbol)
  top50genes
  # get the sample names
  sample_order = f %>% group_by(Diagnosis_edit,Patient_ID,Treatment) %>%
    reframe(sample = unique(sample),
            Accession_Number = unique(Accession_Number)) %>%
    mutate(name = paste(Patient_ID,Treatment,sep = '_')) 
  
  samplenames <- sample_order$sample
  samplenames
  # initialize a gene by sample matrix
  mat <- matrix("", 
                ncol=length(samplenames), 
                nrow=length(top50genes), 
                dimnames=list(top50genes, samplenames))
  
  # go through all genes and change the entry to "MUT" if a gene is mutated in a particular sample
  for(gene in top50genes){
    # get the samples that have a mutation in the gene
    mutated_samples <- df %>% 
      #select(sample,Gene.Symbol,Variant.Type)%>%
      filter(Gene.Symbol == gene)
    
    # set the entries in the matrix to "MUT"
    for (smp in mutated_samples$sample) {
      mat[gene, smp] <- as.character(paste(mutated_samples[mutated_samples[,"sample"] == smp, 
                                                           "Variant.Type"] %>%
                                             unique %>% sort, collapse = ';'))
    }
 }

  #change column name to better understandable name
  colnames(mat) == sample_order$sample
  colnames(mat) = sample_order$name
  
  # inspect
  table(top50genes_df$Variant.Type) %>% sort()
  

  alter_fun = list(
    background = function(x, y, w, h) 
      grid.rect(x, y, w*0.9, h*0.9, gp = gpar(fill = "#CCCCCC", col = NA)),
    
    #square
    SNV = function(x, y, w, h) 
      grid.rect(x, y, w*0.9, h*0.9, gp = gpar(fill = "#4DAC26", col = NA)),
    
    #half square
    INDEL = function(x, y, w, h) {
      grid.polygon(
        unit.c(x + 0.5*w, x + 0.5*w, x - 0.5*w), 
        unit.c(y + 0.5*h, y - 0.5*h, y + 0.5*h),
        gp = gpar(fill = '#D01C8B', col = "white"))
    },
    
    # dots
    MNV = function(x, y, w, h) 
      grid.points(x, y, pch = 16,
                  gp = gpar(fontsize = 8))
    #,
    # crossed lines
    # MNV = function(x, y, w, h) {
    #   grid.segments(x - w*0.4, y - h*0.4, x + w*0.4, y + h*0.4, 
    #                 gp = gpar(lwd = 2,col='black'))
    #   grid.segments(x + w*0.4, y - h*0.4, x - w*0.4, y + h*0.4, 
    #                 gp = gpar(lwd = 2,col='black'))
    # }
  )
  
  test_alter_fun(alter_fun)
  
  #column_title = paste("Top ",n," hotspot Mutation heatmap for M20-431 tumors",sep = '')
  heatmap_legend_param = list(title = "Alteration", 
                              at = c("INDEL", "SNV",
                                     "MNV"), 
                              labels = c("INDEL", "SNV",
                                         "MNV"),legend_direction = 'horizontal')
  
  TMB <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch245_TMB.csv') %>%
    filter(name =='SNVs') %>% 
    merge(.,sample_order, by.x = 'Accession_number',by.y = 'Accession_Number') %>%
    merge(.,colData)
  
  ##match second vector to first vector
  TMB <- TMB[match(sample_order$Accession_Number,TMB$Accession_number),]
  identical(TMB$Accession_number,sample_order$Accession_Number)
  
  draw(oncoPrint(mat,
                 alter_fun = alter_fun, col = c(SNV = "#4DAC26", INDEL = "#D01C8B",MNV='black'), 
                 remove_empty_columns = F, remove_empty_rows = F,
                 pct_side = "right", row_names_side = "left",
                 column_title = column_title, 
                 #show_heatmap_legend=F,
                 row_names_gp = gpar(fontsize = 8.5),
                 column_names_gp = gpar(fontsize = 8.5),
                 show_column_names = T,
                 column_order = TMB$name.y,
                 top_annotation = HeatmapAnnotation(
                   cbar = anno_oncoprint_barplot(),
                   TMB = anno_points(TMB$value),
                   Treatment = TMB$Treatment,
                   Diagnosis = TMB$Diagnosis_edit,
                   simple_anno_size = unit(3, "mm"),
                   col = list(Treatment = c("Archival Pre" = "grey40","Fresh Pre" = 'grey', 
                                            "On-Treatment" = "orange")),
                   annotation_name_gp= gpar(fontsize = 8)),
                 left_annotation =  rowAnnotation(
                   rbar = anno_oncoprint_barplot(
                     axis_param = list(direction = "reverse"))),
                 right_annotation = NULL
  ),
  heatmap_legend_side = "left"
  )
  
}
## end of function
########################################################################################################################

###################################################
##2 execute the function for mutational landscape
###################################################
##1) All variant

df <- counts_somaticSNV_allVar

draw_oncoprint(f = df, number_of_genes = 50)

##2) protein coding + filter SNVs in intronic and synonymous function
df <- counts_somaticSNV_protcode %>% filter(!(Variant.Effect %in% c('intronic','synonymouse')))

draw_oncoprint(f = df, number_of_genes = 50)
 
##3) filter to only contain clinical relevant -- 20240913
#somatic_dna_small_variant_cancer_clinical_research_report(AF≥0.02forclinicalgenes)
#• Population AF across pop. columns <1%
#• misssense only + low AF + effect moderate
#• cancer gene consensus == Y
#• gnomAD < 1%

df <- counts_somaticSNV_protcode %>% 
  filter(!(Variant.Effect %in% c('intronic','synonymous')))%>%
  filter(Cancer.Gene.Census == 'Y') %>%
  dplyr::filter(gnomAD.MAF < 0.01) %>%
  dplyr::filter(Variant.Effect.Impact %in% c('HIGH','MODERATE')) 

draw_oncoprint(f = df, number_of_genes = 30)

pc(Variant.Effect, data = df, main = NULL)

##4) top 20 mutated genes + mutations related to resistance to ICI

genes <- c('TP53','TTN','MUC16','CSMD3','PIK3CA','RYR2','SYNE1','LRP1B','FLG','USH2A','PCLO','ZFHX4',
           'OBSCN','DNAH5','DST','KMT2D','XIRP2','CSMD1','SPTA1','FAT4',
           'HLA-A','HLA-B','HLA-C','B2M','TAP1','TAP2','NLRC5')

df <- counts_somaticSNV_protcode

draw_oncoprint(f = df, genelist = genes,number_of_genes = NA)
pc(Variant.Effect, data = df, main = NULL)

##5) track top mutant genes and their clonality changes pre vs post treatment
df <- counts_somaticSNV_protcode %>% 
  filter(!(Variant.Effect %in% c('intronic','synonymous')))%>%
  filter(Cancer.Gene.Census == 'Y') %>%
  dplyr::filter(gnomAD.MAF < 0.01) %>%
  #dplyr::filter(Variant.Effect.Impact %in% c('HIGH','MODERATE')) %>%
  filter(Patient_ID %in% c( '2203','2204','2207','2209','2501','2801'))
  

unique_genes_sample <- df %>% 
  filter(!is.na(Transcript.Biotype))%>% 
  group_by(Gene.Symbol) %>%
  reframe(Variant.Type = paste(unique(Variant.Type) %>% sort, collapse = ';') , 
          occurrance = n(),
          nsample = length(unique(sample))) %>%
  arrange(-nsample) %>% filter(nsample > 1)

df_plt <- df %>% filter(Gene.Symbol %in% unique_genes_sample$Gene.Symbol) %>%
  group_by(Patient_ID,Gene.Symbol,Treatment,Days_on_Treatment) %>%
  reframe(Protein.Variant = Protein.Variant,
          VAF = Allelic.Fraction) %>%
  mutate(Days_on_Treatment = ifelse(Treatment == 'Fresh Pre','0',Days_on_Treatment)) %>%
  filter(!(is.na(Protein.Variant)))

library(ggalluvial)

ggplot(df_plt %>%  mutate(subject = Protein.Variant),
       aes(x = Treatment, y = VAF ,fill = Protein.Variant ,
           label = Protein.Variant,
           stratum = Protein.Variant,
           alluvium = Protein.Variant)) +
  geom_flow() +
  geom_stratum(alpha = .5) +
  theme_bw(base_line_size = 0,base_rect_size = 1) +
  theme(panel.spacing = unit(0.0, "cm"),
        axis.text.x = element_text(angle = 90),
        strip.background = element_rect(fill = 'white'),
        legend.position = 'none') +
  labs(x='')  +
  facet_wrap(~Patient_ID + Gene.Symbol,nrow = 1) +
  ggrepel::geom_label_repel(size=3)


##6) TMB

colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch245_colData_0903.csv')

TMB <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch245_TMB.csv') %>%
  merge(.,colData) %>%
  filter(Patient_ID %in% c( '2203','2204','2207','2209','2501','2801'))

ggplot(TMB, 
       aes(x = Treatment,y = value, fill = factor(Patient_ID))) +
  geom_bar(stat = 'identity',position = 'dodge',alpha = .7) +
  theme_bw(base_line_size = 0,base_rect_size = 1) +
  theme(panel.spacing = unit(0.0, "cm"),
        axis.text.x = element_text(angle = 90),
        strip.background = element_rect(fill = 'white'),
        legend.position = 'none') +
  labs(x='',fill='')  +
  facet_grid(scales = 'free',
             rows = vars(name),
             cols = vars(Patient_ID)) 


###################################################
## 3. PTPN2-JAK-STAT pathway mutation landscape
###################################################
genes <- c('JAK1', 'JAK2', 'JAK3','TYK2', #Jak family genes
           'STAT1', 'STAT2', 'STAT3', 'STAT4', 'STAT5A', 'STAT5B', 'STAT6', #Stat family genes
           'IFNAR1', 'IFNAR2', 'IL2RA','IL2RB','IFNGR1','IFNGR2','IFNLR1','IL10RB', 'IL6R','GHR',#Cytokine receptor genes
           'IFNA1', 'IFNA2', 'IFNA4', 'IFNA5', 'IFNA6', 'IFNA7', 'IFNA8', 'IFNA10', 
           'IFNA13', 'IFNA14', 'IFNA16', 'IFNA17', 'IFNA21',
           'IFNB',
           'IFNG',
           'IFNL1', 'IFNL2', 'IFNL3', 'IFNL4',
           'SOCS1', 'SOCS2', 'SOCS3', 'SOCS4', 'SOCS5', 'SOCS6', 'SOCS7', #Suppressor of cytokine signaling (SOCS) genes
           'IRF1', 'IRF2', 'IRF3', 'IRF4', 'IRF5', 'IRF6', 'IRF7', 'IRF8', 'IRF9', #Interferon regulatory factor (IRF) genes
           'PTPN2','PTPN1',
           'PDCD1','CD274','PDCD1LG2')


##1) All variant
df <- counts_somaticSNV_allVar

draw_oncoprint(f = df, genelist = genes,number_of_genes = NA)

##2) protein coding + filter SNVs in intronic and synonymous function
df <- counts_somaticSNV_protcode %>% 
  filter(!(Variant.Effect %in% c('intronic','synonymouse'))) %>%
  #filter(Cancer.Gene.Census == 'Y') %>%
  #dplyr::filter(gnomAD.MAF < 0.01) %>%
  filter(Patient_ID %in% c( '2203','2204','2207','2209','2501','2801')) %>%
  filter(Gene.Symbol %in% genes)

draw_oncoprint(f = df, genelist = genes,number_of_genes = NA)

### 4. pathway enrichment analysis for top mutated genes
# if unsuccess for install clusterProfiler, remote install ggtree then clusterprofiler biomanager install to fix problem
#remotes::install_github('YuLab-SMU/ggtree')
#BiocManager::install("clusterProfiler")

library(clusterProfiler)
library(org.Hs.eg.db)
library(msigdbr)
library(ReactomePA)

msigdbr_show_species()

df <- counts_somaticSNV_allVar
df <- counts_somaticSNV_protcode %>% filter(!(Variant.Effect %in% c('intronic','synonymouse')))

# over representation analysis

unique_genes_sample <- df %>% 
  filter(!is.na(Transcript.Biotype))%>% 
  group_by(Gene.Symbol) %>%
  reframe(Variant.Type = paste(unique(Variant.Type) %>% sort, collapse = ';') , 
          occurrance = n(),
          nsample = length(unique(sample))) %>%arrange(-occurrance) %>%
  slice_head(n=200)


gene.df <- bitr(unique_genes_sample$Gene.Symbol, fromType = "SYMBOL",
                toType = c(#"ENSEMBL", 
                           "ENTREZID"),
                OrgDb = org.Hs.eg.db) 

#GO ORA
ego <- enrichGO(gene          = gene.df$SYMBOL,
                universe      = df$Gene.Symbol%>%unique,
                OrgDb         = org.Hs.eg.db,
                ont           = "CC",
                pAdjustMethod = "BH",
                pvalueCutoff  = 0.01,
                qvalueCutoff  = 0.05,
                readable      = TRUE,
                keyType = 'SYMBOL')

head(ego)
dotplot(ego, showCategory=30) + ggtitle("GO pathway enrichment")

#KEGG ORA
kk <- enrichKEGG(gene         = gene.df$ENTREZID,
                 organism     = 'hsa',
                 pvalueCutoff = 0.05)
head(kk)
dotplot(kk, showCategory=30,font.size = 9) + ggtitle("KEGG pathway enrichment")

#WIKIPathway ORA
wp <- enrichWP(gene.df$ENTREZID, organism = "Homo sapiens") 
head(wp)
dotplot(wp, showCategory=30) + ggtitle("Wikipathway enrichment")

#Reactome ORA
x <- enrichPathway(gene=gene.df$ENTREZID, pvalueCutoff = 0.05, readable=TRUE)
head(x)
dotplot(x, showCategory=30) + ggtitle("Reactome pathway enrichment")


m_t2g <- msigdbr(species = "Homo sapiens", category = "C5",subcategory = 'MF') %>% 
  dplyr::select(gs_name, human_gene_symbol)

em <- enricher(unique_genes_sample$Gene.Symbol, TERM2GENE=m_t2g)
head(em)

dotplot(em, showCategory=30,font.size=9) + ggtitle("Gene Ontology molecular function pathway enrichment")

####5. TMB association with BOR
colData <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch245_colData_0903.csv')

TMB <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch245_TMB.csv') %>%
  filter(name =='SNVs') %>% 
  merge(.,colData, by.x = 'Accession_number',by.y = 'Accession_number') %>%
  filter(!is.na(BOR))

##TMB readout for Data Sciense team . Pre treatment tumor TMB

TMB_preTreatment <- TMB %>% filter(Treatment != 'On-Treatment') %>% 
  select(Accession_number,Patient_ID,Treatment,Diagnosis,value) %>% 
  dplyr::rename('TMB/Mb' = 'value')

write.csv(TMB_preTreatment, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/TMB_forDataScienceTeam.csv')


library(ggpubr)

ggboxplot(TMB, 
          x = 'BOR', y = 'value',color = 'BOR', add = 'jitter',
          add.params = list(size=.7,alpha = .2, color = 'black')) +
  #facet_wrap(~chain) +
  stat_compare_means(comparisons = list(c('PD','CR','SD','PR','NE')), method = 'wilcox.test',
                     label = 'p.signif') +
  #scale_color_brewer(palette = "Spectral") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_text(angle = 90),
        strip.background = element_rect(fill = 'white')) +
  labs(x='',y='Tumor Mutation Burden (/Mb)') 


ggboxplot(TMB, 
          x = 'BOR', y = 'value',color = 'Treatment', add = 'jitter',
          add.params = list(size=.7,alpha = .2, color = 'black')) +
  #facet_wrap(~chain) +
  stat_compare_means(comparisons = list(c('PD','CR','SD','PR','NE')), method = 'wilcox.test',
                     label = 'p.signif') +
  #scale_color_brewer(palette = "Spectral") +
  theme_bw(base_line_size = 0,base_rect_size = 1) + 
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_text(angle = 90),
        strip.background = element_rect(fill = 'white')) +
  labs(x='',y='Tumor Mutation Burden (/Mb)') 












