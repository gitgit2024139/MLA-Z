library(tidyverse)
library(dplyr)
library(readxl)
library(data.table)
library(Biobase)
library(genefilter)
library(Rtsne)
library(ggplot2)
library(gridExtra)
library(pheatmap)
library(gplots)
library(limma)
library(RColorBrewer)
library(reshape)
library(GSVA)
library(quantiseqr)
library(ComplexHeatmap)
library(lessR)

#1. filelsit

test124 <- read.table('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/filenames_124_250117.txt',sep = '\t')

test431 <- read.table('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/filenames_431_250117.txt',sep = '\t')

allS3file_tumors <- rbind(test124,test431) %>%
  separate(V1, into = c('v1','filepath'), sep = 'CloudDataRoot') %>% 
  mutate(filepath = paste('CloudDataRoot',filepath,sep = '')) %>%
  mutate(filetype = basename(filepath),
  suffix = lapply(filetype, function(x) {tail(strsplit(x,split = '\\.')[[1]], 1)}
  ) %>% unlist()) %>% 
  
  filter(suffix %in% c('tsv','txt','xlsx')) %>% 
  
  mutate(pipeline = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 1)}
  ) %>% unlist(),
  
  Accession_number = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 2)[2]}
  ) %>% unlist()
  )

#read clinical sample shiping manifest, get paired tumor samples
## batch 5 and 6 MANIFEST
manifest <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/Batch5_6_data_inventory_yz_2025.xlsx', 
                               sheet = 1)%>% 
  mutate(Patient_ID = parse_number(Patient_ID))

manifest$Treatment[9] = 'On-Treatment'
colnames(manifest)

colData_56 <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/PTPN2_Clinical_Metadata_08AUG24_Final.xlsx',
                              sheet = 2) 

colData_56 <- manifest %>% left_join(., colData_56 %>% dplyr::rename('Patient_ID' = 'Subject_ID')) %>% 
  mutate(Mosaic_ID = NA)

## BATCH 1-4 MANIFEST
manifest <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/M20_431_and_M20_124_Personalis_Shipment_Summary_6Aug2024_yz_mj.xlsx', 
                               sheet = 4)%>% 
  filter(Batch_Type != 'Gene Expression') %>% ##remove blood samples
  mutate(Accession_number = Accession_Number) %>%
  mutate(Accession_number = ifelse(nchar(Accession_number)==12,
                                   str_sub(Accession_number, end = -3),
                                   Accession_number)) %>% 
  #filter(Cohort =='M20-431') %>% page 3 is M20-431 only
  #filter(Mosaic_ID != 'N/A') %>%
  mutate(Accession_Number = parse_number(Accession_number)) %>% 
  dplyr::select(-Annotation) %>% 
  dplyr::select(Batch_number,Cohort,Patient_ID, Accession_number, Treatment,Mosaic_ID)

colnames(manifest) <- c('Batch','Study','Subject_ID','Accession_number','Treatment','Mosaic_ID')

colData_1_4 <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/allS3files_431_124_clinical_1105.csv',stringsAsFactors = F)
colData_1_4$Subject_ID <- as.character(colData_1_4$Subject_ID)
colData_1_4 <- manifest %>% left_join(., colData_1_4 )
colnames(colData_1_4)[3] <- 'Patient_ID'

##dissect to shared columns
colData_1_4 <- colData_1_4 %>% select(intersect(colnames(colData_1_4),colnames(colData_56)))
colData_56 <- colData_56 %>% select(intersect(colnames(colData_1_4),colnames(colData_56)))

## combine 1-6 batch coldata
colData_56$C1D1 <- as.character(colData_56$C1D1)
colData_56$Last_Day_on_Treatment <- as.character(colData_56$Last_Day_on_Treatment)
colData_56$Patient_ID <- as.character(colData_56$Patient_ID)

colData_1_6_total <- dplyr::bind_rows(colData_1_4,colData_56)

colData_1_6_total <- unique(colData_1_6_total)

write.csv(colData_1_6_total, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/coldata_1_6_total.csv', row.names = F)


#### AI consized version
library(dplyr)
library(readxl)

# Read filenames and combine them
allS3file_tumors <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/', 
                               pattern = "filenames_.*_250117\\.txt$", full.names = TRUE) %>%
  lapply(read.table, sep = '\t') %>%
  bind_rows() %>%
  separate(V1, into = c('v1', 'filepath'), sep = 'CloudDataRoot') %>%
  mutate(filepath = paste0('CloudDataRoot', filepath),
         filetype = basename(filepath),
         suffix = sub(".*\\.(.*)$", "\\1", filetype)) %>%
  filter(suffix %in% c('tsv', 'txt', 'xlsx')) %>%
  mutate(pipeline = sub("_.*", "", filetype),
         Accession_number = sub("^[^_]+_(^[^_]+)_.*$", "\\1", filetype))

# Common function for reading and processing batch manifests
read_manifest <- function(file_path, sheet, filter_exp = TRUE) {
  manifest <- read_excel(file_path, sheet = sheet) %>%
    mutate(Patient_ID = parse_number(Patient_ID)) %>%
    filter(filter_exp) %>%
    mutate(Accession_number = ifelse(nchar(Accession_number) == 12,
                                     substr(Accession_number, 1, nchar(Accession_number) - 3),
                                     Accession_number)) %>%
    mutate(Accession_number = parse_number(Accession_number)) %>%
    select(Batch_number = Batch, Cohort = Study, Patient_ID = Subject_ID, 
           Accession_number, Treatment, Mosaic_ID)
}

# Process batch 5 and 6 manifest
manifest_colData_56 <- read_manifest('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/Batch5_6_data_inventory_yz_2025.xlsx', 
                                     sheet = 1) %>%
  mutate(Mosaic_ID = NA)

# Process batch 1 to 4 manifest
manifest_colData_1_4 <- readxl::read_excel('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/M20_431_and_M20_124_Personalis_Shipment_Summary_6Aug2024_yz_mj.xlsx', 
                                           sheet = 4) %>%
  filter(Batch_Type != 'Gene Expression') %>% 
  select(Batch_number, Study, Patient_ID, Accession_number, Treatment, Mosaic_ID) %>%
  mutate(Mosaic_ID = NA) %>%
  rename(Batch = Batch_number, Study = Study, 
         Subject_ID = Patient_ID, Accession_number = Accession_number) %>%
  filter(Batch_Type != 'Gene Expression') %>%
  mutate(Mosaic_ID = NA)

# Read clinical data
colData_1_4 <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/allS3files_431_124_clinical_1105.csv',
                        stringsAsFactors = FALSE) %>%
  rename(Patient_ID = Subject_ID) %>%
  left_join(manifest_colData_1_4, by = "Patient_ID")

# Select shared columns
shared_columns <- intersect(names(colData_1_4), names(manifest_colData_56))
colData_1_4 <- colData_1_4[shared_columns]
manifest_colData_56 <- manifest_colData_56[shared_columns]

# Combine the batches
colData_1_6_total <- bind_rows(colData_1_4, manifest_colData_56) %>%
  mutate(across(C1D1:Last_Day_on_Treatment, as.character)) %>%
  distinct()

# Export combined data
write.csv(colData_1_6_total, '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/coldata_1_6_total.csv', row.names = FALSE)
######








#2. filter dna_statistics files

#filter report
final_list_edit <- allS3file_tumors[grepl(paste(c('dna_statistics.tsv'#,'rna_statistics.tsv'
                                                  ),collapse = '|'),
                                          allS3file_tumors$filetype),]  
##batchset
final_list_edit <- final_list_edit %>% mutate(
  batchset = str_extract(filepath, '[Bb]atch\\d(_\\w+)') %>% 
    lapply(.,function(x) {head(strsplit(x, split = '_7')[[1]],1)[1]}) %>%
    unlist(),
  batchdate = str_extract(filepath, '\\d{4}_\\d{4}'),
  batchtotal = paste(batchset,batchdate,sep = '_')
)

# remove repeated files
test <- final_list_edit %>% group_by(Accession_number) %>% 
  reframe(occurrance = paste(sort(unique(batchtotal)),collapse = ';')) %>% 
  mutate(final_segment = str_extract(occurrance , '[^;]+$'))

final_list_edit <- final_list_edit %>% filter(batchtotal %in% test$final_segment)

test <- final_list_edit %>% group_by(Accession_number) %>% 
  reframe(occurrance = paste(sort(unique(batchtotal)),collapse = '; '))

##3 add metadata

final_list <- final_list_edit %>% left_join(.,colData_1_6_total,by = 'Accession_number')  

final_list <- final_list %>% filter(!duplicated(filetype))

## full manifest doesn't have treatment info
final_list_edit <- final_list[order(final_list$Patient_ID
                                    #final_list$Treatment. #full manifest doesn't have treatment info
),]


##save colData
write.csv(final_list_edit,'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch1_6_forTMB_20250411.csv',row.names = F)

##4. download gene expression reports from s3 by print bash command lines and run command lines in terminal

for (i in 1: length(final_list_edit$filepath)) {
  
  s3_loc <- final_list_edit$filepath[i]
  filename <- paste(final_list_edit$batchset[i], final_list_edit$filetype[i],sep = '_')
  
  cmd <- paste('aws s3 cp s3://abv-arrayserver/', s3_loc, 
               ' --profile arrayserver /homes/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorQC_batch1_6_forTMB/', 
               filename,sep = '') 
  ## /homes/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data is the location on aurora, not on magnus
  
  write(cmd,file = '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/bash_cp_cmd_QC_total_forTMB.sh', append = T)
  
}

##5. qc files

files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorQC_batch1_6_forTMB/',
                    #pattern = 'somatic_dna_small_variant_report_preferred',
                    #pattern = '.tsv',
                    full.names = T)

names(files) <- stringr::str_split(basename(files), pattern = '_statistics',simplify = T)[,1]

test <- data.frame(sample = names(files)) %>% 
  mutate(Accession_number = str_extract(sample, '\\d{10}'),
         batchset = str_split(sample, pattern = paste(c('_RNA','_DNA'), collapse = '|'), simplify = T)[,1]) 

## compiling the master data frame
counts <- purrr::map_df(files, function(x) {
  read.delim(x, header = FALSE, 
             sep = "\t", quote = "\"",
             dec = ".", fill = TRUE, comment.char = "#", 
             col.names = c("V1","V2","V3","V4","V5"))
}, .id = "sample") %>%
  left_join(.,test) %>% 
  filter(!is.na(batchset))

# working table
counts_qc_df <- counts %>%
  filter(V1 %in% 
           c('Average base quality','Total reads','Percent contamination in Normal',
             'Percent contamination in Tumor','Average read depth',
             'Percent mapped reads','Somatic variants per Mb','Non-synonymous Somatic Variants per Mb',
             'Number of expressed genes')) %>% 
  mutate(pipeline = str_extract(sample, '[DR]NA'))

##6. Non-synonymous Somatic Variants per Mb

TMB <- counts_qc_df %>% 
  filter(V1 == 'Non-synonymous Somatic Variants per Mb', pipeline == 'DNA')%>% 
  pivot_longer(cols = c('V2','V3')) %>% 
  mutate(name = ifelse(name == 'V2','SNVs','Indels')) %>% 
  mutate(TMBvalue = parse_number(value)) %>%
  select(1:2,5:6,7:8,10)

#only tmb value

tmb <- TMB %>% filter(name == 'SNVs') %>% 
  left_join(., final_list_edit %>% select(-v1))

write.csv(tmb,'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch1_6_TMB.csv',row.names = F)

TMB <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batch1_6_TMB.csv')

TMB %>%
  ggplot(aes(x = BOR,y=TMBvalue, fill=BOR)) +
  geom_boxplot(alpha=.5) +
  scale_fill_brewer(palette = "Pastel1") +
  theme_bw(base_line_size = 0,base_rect_size = 1) +
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_blank(),
        strip.background = element_rect(fill = 'white'),
        legend.position = 'bottom') +
  labs(x='',fill = '', y = 'TMB (Number of Mutations/Mb)')


##########################################################################################################
##### 7. tracking down the archival molecular data
##########################################################################################################

#1. filelsit

illumina124 <- read.table('~/PTPN2i/filenames_124_archives_illumina.txt',sep = '\t')
illumina431 <- read.table('~/PTPN2i/filenames_431_archives_illumina.txt',sep = '\t')

allilluminafile_tumors <- rbind(illumina124,illumina431) %>%
  
  separate(V1, into = c('v1','filepath'), sep = '000000_tmp_personalis') %>% 
  
  mutate(filepath = paste('/Resources/Archives/Illumina/Raw_Data/ILLUMINA_Data_Received/000000_tmp_personalis',filepath,sep = '')) %>%
  
  mutate(filetype = basename(filepath),
         
  suffix = lapply(filetype, function(x) {tail(strsplit(x,split = '\\.')[[1]], 1)}
  ) %>% unlist()) %>% 
  
  filter(suffix %in% c('tsv','txt','xlsx')) %>% 
  
  mutate( pipeline = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 1)}
  ) %>% unlist(),
  
  Patient_ID = lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]], 2)[2]}
  ) %>% unlist(),
  
  Mosaic_ID = str_extract(filepath, 'ML\\d+'),
  
  Accession_number_original = ifelse(is.na(Mosaic_ID),
                                     lapply(filetype, function(x) {head(strsplit(x,split = '_')[[1]],3)[3]}
                                     ) %>% unlist(), NA),
  
  Accession_number = ifelse(nchar(Accession_number_original)==12,
                            str_sub(Accession_number_original, end = -3),
                            Accession_number_original) ,
  
  Accession_number = ifelse(Accession_number == 'rna',
                            Patient_ID,
                            Accession_number) ,
  
  ) %>% 
  
  filter(pipeline %in% c('DNA','RNA'))

#read clinical sample shiping manifest, get paired tumor samples
## batch 5 and 6 MANIFEST
## BATCH 1-4 MANIFEST
colData_1_6_total <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/coldata_1_6_total.csv')

#2. filter dna_statistics files

#filter report
final_list_edit <- allilluminafile_tumors[grepl(paste(c('dna_statistics.tsv'#,'rna_statistics.tsv'
                                                        ),collapse = '|'),
                                          allilluminafile_tumors$filetype),]  
##batchset
final_list_edit <- final_list_edit %>% mutate(
  batchset = str_extract(filepath, '[Bb]atch\\d(_\\w+)') %>% 
    lapply(.,function(x) {head(strsplit(x, split = '_7')[[1]],1)[1]}) %>%
    unlist(),
  batchdate = str_extract(filepath, '\\d{4}_\\d{4}'),
  batchtotal = paste(batchset,batchdate,sep = '_')
)

# remove repeated files
test <- final_list_edit %>% group_by(Patient_ID,Mosaic_ID) %>% 
  reframe(occurrance = paste(sort(unique(batchtotal)),collapse = ';')) %>% 
  mutate(final_segment = str_extract(occurrance,'[^;]+$'))

final_list_edit <- final_list_edit %>% filter(batchtotal %in% test$final_segment)

test <- final_list_edit %>% group_by(Patient_ID,Mosaic_ID) %>% 
  reframe(occurrance = paste(sort(unique(batchtotal)),collapse = '; '))

##3 add metadata
colData_1_6_total$Patient_ID <- as.character(colData_1_6_total$Patient_ID)

final_list <- final_list_edit %>% 
  left_join(.,colData_1_6_total,by = c('Patient_ID','Mosaic_ID'))

final_list <- final_list %>% filter(!duplicated(filetype))

## full manifest doesn't have treatment info
final_list_edit <- final_list[order(final_list$Patient_ID
                                    #final_list$Treatment. #full manifest doesn't have treatment info
),]

##save colData
write.csv(final_list_edit,'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_batchIlluminaArchive_forTMB_20250414.csv',row.names = F)

##4. download gene expression reports from s3 by print bash command lines and run command lines in terminal

## need to ssh to zhanyx3@ord-docker02 for illumina archival datta

for (i in 1: length(final_list_edit$filepath)) {
  
  s3_loc <- final_list_edit$filepath[i]
  filename <- paste(final_list_edit$batchset[i], final_list_edit$filetype[i],sep = '_')
  
  cmd <- paste(#'aws s3 
               'cp ', 
               s3_loc, 
               ' /homes/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorQC_illuminaArchive_forTMB/', 
               filename,sep = '') 
  ## /homes/zhanyx3/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data is the location on aurora, not on magnus
  
  write(cmd,file = '~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/bash_cp_cmd_QC_illuminarchive_forTMB.sh', append = T)
  
}

##5. qc files

files <- list.files('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/s3_download/s3_tumorQC_illuminaArchive_forTMB/',
                    #pattern = 'somatic_dna_small_variant_report_preferred',
                    #pattern = '.tsv',
                    full.names = T)

names(files) <- stringr::str_split(basename(files), pattern = '_statistics',simplify = T)[,1]

test <- data.frame(sample = names(files)) %>% 
  mutate(Mosaic_ID = str_extract(sample, 'ML\\d+'),
         batchset = str_split(sample, pattern = paste(c('_RNA','_DNA'), collapse = '|'), simplify = T)[,1]) 

## compiling the master data frame
counts <- purrr::map_df(files, function(x) {
  read.delim(x, header = FALSE, 
             sep = "\t", quote = "\"",
             dec = ".", fill = TRUE, comment.char = "#", 
             col.names = c("V1","V2","V3","V4","V5"))
}, .id = "sample") %>%
  left_join(.,test) %>% 
  filter(!is.na(batchset))

# working table
counts_qc_df <- counts %>%
  filter(V1 %in% 
           c('Average base quality','Total reads','Percent contamination in Normal',
             'Percent contamination in Tumor','Average read depth',
             'Percent mapped reads','Somatic variants per Mb','Non-synonymous Somatic Variants per Mb',
             'Number of expressed genes')) %>% 
  mutate(pipeline = str_extract(sample, '[DR]NA'))

##6. Non-synonymous Somatic Variants per Mb

TMB <- counts_qc_df %>% 
  filter(V1 == 'Non-synonymous Somatic Variants per Mb', pipeline == 'DNA')%>% 
  pivot_longer(cols = c('V2','V3')) %>% 
  mutate(name = ifelse(name == 'V2','SNVs','Indels')) %>% 
  mutate(TMBvalue = parse_number(value)) %>%
  select(1:2,5:6,7:8,10)

#only tmb value

tmb <- TMB %>% filter(name == 'SNVs') %>% 
  left_join(., final_list_edit %>% select(-v1))

write.csv(tmb,'~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_illuminarchive_TMB.csv',row.names = F)

TMB <- read.csv('~/PTPN2i/Proj1_Tumor_6pairs_Paul_2408/raw_data/tumor_illuminarchive_TMB.csv')

TMB %>%
  ggplot(aes(x = BOR,y=TMBvalue, fill=BOR)) +
  geom_boxplot(alpha=.5) +
  scale_fill_brewer(palette = "Pastel1") +
  theme_bw(base_line_size = 0,base_rect_size = 1) +
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_blank(),
        strip.background = element_rect(fill = 'white'),
        legend.position = 'bottom') +
  labs(x='',fill = '', y = 'TMB (Number of Mutations/Mb)')

TMB %>%
  ggplot(aes(x = Diagnosis,y=TMBvalue, fill=BOR)) +
  geom_boxplot(alpha=.5) +
  scale_fill_brewer(palette = "Pastel1") +
  theme_bw(base_line_size = 0,base_rect_size = 1) +
  theme(panel.spacing = unit(0.1, "cm"),
        axis.text.x = element_text(angle = 90),
        strip.background = element_rect(fill = 'white'),
        legend.position = 'right') +
  labs(x='',fill = '', y = 'TMB (Number of Mutations/Mb)')





